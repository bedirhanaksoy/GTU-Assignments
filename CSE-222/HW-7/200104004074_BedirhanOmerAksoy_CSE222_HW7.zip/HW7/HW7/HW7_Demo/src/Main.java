import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.List;

/**
 * Main class to handle stock operations and measure performance.
 */
public class Main {
    /**
     * Main method to read input from a file and execute stock operations.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        String inputFile = "./input.txt";
        StockDataManager manager = new StockDataManager();
        
        // Lists to store input sizes and running times for each command type
        List<Integer> addInputSizes = new ArrayList<>();
        List<Long> addRunningTimes = new ArrayList<>();
        List<Integer> updateInputSizes = new ArrayList<>();
        List<Long> updateRunningTimes = new ArrayList<>();
        List<Integer> searchInputSizes = new ArrayList<>();
        List<Long> searchRunningTimes = new ArrayList<>();
        List<Integer> removeInputSizes = new ArrayList<>();
        List<Long> removeRunningTimes = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" ");
                String command = parts[0];
                String symbol = parts[1];
                long startOperationTime = System.nanoTime(); // Record start time for AVL operation
                switch (command) {
                    case "ADD":
                        double price = Double.parseDouble(parts[2]);
                        long volume = Long.parseLong(parts[3]);
                        long marketCap = Long.parseLong(parts[4]);
                        manager.addOrUpdateStock(symbol, price, volume, marketCap);
                        addInputSizes.add(manager.getSize()); // Record input size for ADD operation
                        addRunningTimes.add(System.nanoTime() - startOperationTime); // Record running time for ADD operation
                        break;
                    case "REMOVE":
                        manager.removeStock(symbol);
                        removeInputSizes.add(manager.getSize()); // Record input size for REMOVE operation
                        removeRunningTimes.add(System.nanoTime() - startOperationTime); // Record running time for REMOVE operation
                        break;
                    case "SEARCH":
                        Stock stock = manager.searchStock(symbol);
                        System.out.println(stock != null ? stock : "Stock not found");
                        searchInputSizes.add(manager.getSize()); // Record input size for SEARCH operation
                        searchRunningTimes.add(System.nanoTime() - startOperationTime); // Record running time for SEARCH operation
                        break;
                    case "UPDATE":
                        String newSymbol = parts[2];
                        double newPrice = Double.parseDouble(parts[2]);
                        long newVolume = Long.parseLong(parts[3]);
                        long newMarketCap = Long.parseLong(parts[4]);
                        manager.updateStock(symbol, newSymbol, newPrice, newVolume, newMarketCap);
                        updateInputSizes.add(manager.getSize()); // Record input size for UPDATE operation
                        updateRunningTimes.add(System.nanoTime() - startOperationTime); // Record running time for UPDATE operation
                        break;
                    default:
                        System.out.println("Unknown command: " + command);
                        break;
                }
            }

            // After processing the input file, display the performance graphs for each command type
            SwingUtilities.invokeLater(() -> {
                // ADD operation
                GUIVisualization addGraph = new GUIVisualization("scatter", addInputSizes, addRunningTimes);
                addGraph.setTitle("ADD Operation Performance");
                addGraph.setVisible(true);
                
                // UPDATE operation
                GUIVisualization updateGraph = new GUIVisualization("scatter", updateInputSizes, updateRunningTimes);
                updateGraph.setTitle("UPDATE Operation Performance");
                updateGraph.setVisible(true);
                
                // SEARCH operation
                GUIVisualization searchGraph = new GUIVisualization("scatter", searchInputSizes, searchRunningTimes);
                searchGraph.setTitle("SEARCH Operation Performance");
                searchGraph.setVisible(true);
                
                // REMOVE operation
                GUIVisualization removeGraph = new GUIVisualization("scatter", removeInputSizes, removeRunningTimes);
                removeGraph.setTitle("REMOVE Operation Performance");
                removeGraph.setVisible(true);
            });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}