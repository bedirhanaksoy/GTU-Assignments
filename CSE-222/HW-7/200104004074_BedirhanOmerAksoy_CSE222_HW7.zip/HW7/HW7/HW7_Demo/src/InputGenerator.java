import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class InputGenerator {

    private static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final int SYMBOL_LENGTH = 5;
    private static final double MIN_PRICE = 1.0;
    private static final double MAX_PRICE = 1000.0;
    private static final long MIN_VOLUME = 1;
    private static final long MAX_VOLUME = 1000000;
    private static final long MIN_MARKETCAP = 1000000;
    private static final long MAX_MARKETCAP = 1000000000;

    public static void main(String[] args) {
        int numCommands = 1000; // Change this to 100 if you want 100 commands
        String filename = "input.txt";
        generateRandomCommands(numCommands, filename);
        System.out.println("Generated " + numCommands + " commands in " + filename);
    }

    private static void generateRandomCommands(int numCommands, String filename) {
        Random random = new Random();
        Set<String> uniqueSymbols = new HashSet<>();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (int i = 0; i < numCommands; i++) {
                String symbol = generateRandomSymbol(random, uniqueSymbols);
                uniqueSymbols.add(symbol);

                double price = MIN_PRICE + (MAX_PRICE - MIN_PRICE) * random.nextDouble();
                long volume = MIN_VOLUME + (long) ((MAX_VOLUME - MIN_VOLUME) * random.nextDouble());
                long marketCap = MIN_MARKETCAP + (long) ((MAX_MARKETCAP - MIN_MARKETCAP) * random.nextDouble());

                writer.write(String.format("ADD %s %.2f %d %d%n", symbol, price, volume, marketCap));
            }
            for (int i = 0; i < numCommands; i++) {
                String symbol = generateRandomSymbol(random, uniqueSymbols);
                uniqueSymbols.add(symbol);

                double price = MIN_PRICE + (MAX_PRICE - MIN_PRICE) * random.nextDouble();
                long volume = MIN_VOLUME + (long) ((MAX_VOLUME - MIN_VOLUME) * random.nextDouble());
                long marketCap = MIN_MARKETCAP + (long) ((MAX_MARKETCAP - MIN_MARKETCAP) * random.nextDouble());

                writer.write(String.format("UPDATE %s %.2f %d %d%n", symbol, price, volume, marketCap));
            }
            for (int i = 0; i < numCommands; i++) {
                String symbol = generateRandomSymbol(random, uniqueSymbols);
                uniqueSymbols.add(symbol);

                writer.write(String.format("SEARCH %s%n", symbol));
            }
            for (int i = 0; i < numCommands; i++) {
                String symbol = generateRandomSymbol(random, uniqueSymbols);
                uniqueSymbols.add(symbol);


                writer.write(String.format("REMOVE %s%n", symbol));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String generateRandomSymbol(Random random, Set<String> uniqueSymbols) {
        String symbol;
        do {
            StringBuilder sb = new StringBuilder(SYMBOL_LENGTH);
            for (int i = 0; i < SYMBOL_LENGTH; i++) {
                sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
            }
            symbol = sb.toString();
        } while (uniqueSymbols.contains(symbol));
        return symbol;
    }
}
