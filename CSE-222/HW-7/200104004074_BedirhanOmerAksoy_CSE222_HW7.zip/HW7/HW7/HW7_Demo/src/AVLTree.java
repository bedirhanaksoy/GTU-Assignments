/**
 * AVLTree is a self-balancing binary search tree where the difference between 
 * heights of left and right subtrees cannot be more than one for all nodes.
 */
public class AVLTree {

    /**
     * Node represents a node in the AVL tree.
     */
    private class Node {
        Stock stock;
        Node left, right;
        int height;

        /**
         * Constructs a new Node with the given stock.
         * 
         * @param stock The stock to be held by this node.
         */
        Node(Stock stock) {
            this.stock = stock;
            this.height = 1;
        }
    }

    private Node root;

    /**
     * Inserts a new stock into the AVL tree.
     * 
     * @param stock The stock to be inserted.
     */
    public void insert(Stock stock) {
        root = insert(root, stock);
    }

    /**
     * Recursively inserts a stock into the AVL tree.
     * 
     * @param node The root of the subtree where the stock will be inserted.
     * @param stock The stock to be inserted.
     * @return The new root of the subtree.
     */
    private Node insert(Node node, Stock stock) {
        if (node == null) {
            return new Node(stock); // Insert new node
        }

        if (stock.getSymbol().compareTo(node.stock.getSymbol()) < 0) {
            node.left = insert(node.left, stock); // Insert into left subtree
        } else if (stock.getSymbol().compareTo(node.stock.getSymbol()) > 0) {
            node.right = insert(node.right, stock); // Insert into right subtree
        } else {
            // Duplicate symbols are not allowed, but you can update the stock here
            node.stock = stock; // Update existing stock
            return node;
        }

        // Update height of this ancestor node
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Balance the node
        return balance(node);
    }

    /**
     * Deletes a stock from the AVL tree based on its symbol.
     * 
     * @param symbol The symbol of the stock to be deleted.
     */
    public void delete(String symbol) {
        root = delete(root, symbol);
    }

    /**
     * Recursively deletes a stock from the AVL tree.
     * 
     * @param node The root of the subtree where the stock will be deleted.
     * @param symbol The symbol of the stock to be deleted.
     * @return The new root of the subtree.
     */
    private Node delete(Node node, String symbol) {
        if (node == null) {
            return null;
        }

        if (symbol.compareTo(node.stock.getSymbol()) < 0) {
            node.left = delete(node.left, symbol);
        } else if (symbol.compareTo(node.stock.getSymbol()) > 0) {
            node.right = delete(node.right, symbol);
        } else {
            if (node.left == null || node.right == null) {
                Node temp = (node.left != null) ? node.left : node.right;
                if (temp == null) {
                    return null;
                } else {
                    node = temp;
                }
            } else {
                Node temp = getMinValueNode(node.right);
                node.stock = temp.stock;
                node.right = delete(node.right, temp.stock.getSymbol());
            }
        }

        node.height = 1 + Math.max(height(node.left), height(node.right));

        return balance(node);
    }

    /**
     * Searches for a stock in the AVL tree based on its symbol.
     * 
     * @param symbol The symbol of the stock to be searched for.
     * @return The stock if found, otherwise null.
     */
    public Stock search(String symbol) {
        Node result = search(root, symbol);
        return (result != null) ? result.stock : null;
    }

    /**
     * Recursively searches for a stock in the AVL tree.
     * 
     * @param node The root of the subtree where the stock will be searched.
     * @param symbol The symbol of the stock to be searched for.
     * @return The node containing the stock if found, otherwise null.
     */
    private Node search(Node node, String symbol) {
        if (node == null || node.stock.getSymbol().equals(symbol)) {
            return node;
        }

        if (symbol.compareTo(node.stock.getSymbol()) < 0) {
            return search(node.left, symbol); // Search in left subtree
        } else {
            return search(node.right, symbol); // Search in right subtree
        }
    }

    /**
     * Balances the AVL tree node.
     * 
     * @param node The node to be balanced.
     * @return The balanced node.
     */
    private Node balance(Node node) {
        int balanceFactor = getBalanceFactor(node);

        // Left Heavy
        if (balanceFactor > 1) {
            if (getBalanceFactor(node.left) < 0) {
                node.left = leftRotate(node.left); // Left-Right case
            }
            return rightRotate(node); // Left-Left case
        }

        // Right Heavy
        if (balanceFactor < -1) {
            if (getBalanceFactor(node.right) > 0) {
                node.right = rightRotate(node.right); // Right-Left case
            }
            return leftRotate(node); // Right-Right case
        }

        return node;
    }

    /**
     * Performs a left rotation on the subtree rooted at y.
     * 
     * @param y The root of the subtree to be rotated.
     * @return The new root of the rotated subtree.
     */
    private Node leftRotate(Node y) {
        Node x = y.right;
        Node T2 = x.left;

        // Perform rotation
        x.left = y;
        y.right = T2;

        // Update heights
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        // Return new root
        return x;
    }

    /**
     * Performs a right rotation on the subtree rooted at y.
     * 
     * @param y The root of the subtree to be rotated.
     * @return The new root of the rotated subtree.
     */
    private Node rightRotate(Node y) {
        Node x = y.left;
        Node T2 = x.right;

        // Perform rotation
        x.right = y;
        y.left = T2;

        // Update heights
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        // Return new root
        return x;
    }

    /**
     * Calculates the balance factor of a node.
     * 
     * @param node The node whose balance factor is to be calculated.
     * @return The balance factor of the node.
     */
    private int getBalanceFactor(Node node) {
        if (node == null) {
            return 0;
        }
        return height(node.left) - height(node.right);
    }

    /**
     * Calculates the height of a node.
     * 
     * @param node The node whose height is to be calculated.
     * @return The height of the node.
     */
    private int height(Node node) {
        return (node == null) ? 0 : node.height;
    }

    /**
     * Finds the node with the minimum value in a subtree.
     * 
     * @param node The root of the subtree.
     * @return The node with the minimum value.
     */
    private Node getMinValueNode(Node node) {
        if (node == null || node.left == null) {
            return node;
        }
        return getMinValueNode(node.left);
    }

    /**
     * Calculates the size of the AVL tree.
     * 
     * @return The number of nodes in the tree.
     */
    public int size() {
        return size(root);
    }

    /**
     * Recursively calculates the size of a subtree.
     * 
     * @param node The root of the subtree.
     * @return The number of nodes in the subtree.
     */
    private int size(Node node) {
        if (node == null) {
            return 0;
        } else {
            return 1 + size(node.left) + size(node.right);
        }
    }

    /**
     * Performs in-order traversal of the AVL tree.
     */
    public void inOrderTraversal() {
        inOrderTraversal(root);
    }

    /**
     * Recursively performs in-order traversal of a subtree.
     * 
     * @param node The root of the subtree.
     */
    private void inOrderTraversal(Node node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.println(node.stock);
            inOrderTraversal(node.right);
        }
    }

    /**
     * Performs pre-order traversal of the AVL tree.
     */
    public void preOrderTraversal() {
        preOrderTraversal(root);
    }

    /**
     * Recursively performs pre-order traversal of a subtree.
     * 
     * @param node The root of the subtree.
     */
    private void preOrderTraversal(Node node) {
        if (node != null) {
            System.out.println(node.stock);
            preOrderTraversal(node.left);
            preOrderTraversal(node.right);
        }
    }

    /**
     * Performs post-order traversal of the AVL tree.
     */
    public void postOrderTraversal() {
        postOrderTraversal(root);
    }

    /**
     * Recursively performs post-order traversal of a subtree.
     * 
     * @param node The root of the subtree.
     */
    private void postOrderTraversal(Node node) {
        if (node != null) {
            postOrderTraversal(node.left);
            postOrderTraversal(node.right);
            System.out.println(node.stock);
        }
    }
}
