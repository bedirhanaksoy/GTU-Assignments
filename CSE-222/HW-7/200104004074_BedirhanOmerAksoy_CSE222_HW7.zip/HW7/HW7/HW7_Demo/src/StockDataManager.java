/**
 * The StockDataManager class manages stock data using an AVL tree for efficient searching, 
 * insertion, and deletion operations. It provides methods to add, update, remove, and search 
 * for stocks, as well as to get the size of the AVL tree and clear it.
 * 
 * <p>This class utilizes an AVL tree (a self-balancing binary search tree) to maintain stock 
 * data, ensuring that operations are performed in logarithmic time.</p>
 */
public class StockDataManager {
    private AVLTree avlTree;

    /**
     * Constructs a new StockDataManager with an empty AVL tree.
     */
    public StockDataManager() {
        avlTree = new AVLTree();
    }

    /**
     * Adds a new stock or updates an existing stock in the AVL tree.
     * 
     * @param symbol the stock symbol
     * @param price the stock price
     * @param volume the stock volume
     * @param marketCap the market capitalization of the stock
     */
    public void addOrUpdateStock(String symbol, double price, long volume, long marketCap) {
        Stock existingStock = avlTree.search(symbol);
        if (existingStock != null) {
            existingStock.setPrice(price);
            existingStock.setVolume(volume);
            existingStock.setMarketCap(marketCap);
        } else {
            Stock newStock = new Stock(symbol, price, volume, marketCap);
            avlTree.insert(newStock);
        }
    }

    /**
     * Removes a stock from the AVL tree.
     * 
     * @param symbol the stock symbol to remove
     */
    public void removeStock(String symbol) {
        avlTree.delete(symbol);
    }

    /**
     * Searches for a stock in the AVL tree.
     * 
     * @param symbol the stock symbol to search for
     * @return the Stock object if found, otherwise null
     */
    public Stock searchStock(String symbol) {
        return avlTree.search(symbol);
    }

    /**
     * Updates the details of an existing stock in the AVL tree.
     * 
     * @param symbol the current stock symbol
     * @param newSymbol the new stock symbol
     * @param newPrice the new stock price
     * @param newVolume the new stock volume
     * @param newMarketCap the new market capitalization of the stock
     */
    public void updateStock(String symbol, String newSymbol, double newPrice, long newVolume, long newMarketCap) {
        Stock stock = avlTree.search(symbol);
        if (stock != null) {
            avlTree.delete(symbol);
            stock.setSymbol(newSymbol);
            stock.setPrice(newPrice);
            stock.setVolume(newVolume);
            stock.setMarketCap(newMarketCap);
            avlTree.insert(stock);
        }
    }

    /**
     * Gets the size of the AVL tree.
     * 
     * @return the number of stocks in the AVL tree
     */
    public int getSize() {
        return avlTree.size();
    }

    /**
     * Clears the AVL tree, removing all stocks.
     */
    public void clear() {
        avlTree = new AVLTree();
    }
}
