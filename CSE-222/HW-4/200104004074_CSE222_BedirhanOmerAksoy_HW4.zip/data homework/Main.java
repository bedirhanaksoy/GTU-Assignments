import java.sql.Timestamp;
import java.util.*;

/**
 * Abstract class representing a file system element.
 */
abstract class FileSystemElement {
    protected String name;
    protected Timestamp dateCreated;
    protected FileSystemElement parent;

    public FileSystemElement(String name, Timestamp dateCreated, FileSystemElement parent) {
        this.name = name;
        this.dateCreated = dateCreated;
        this.parent = parent;
    }

    public String getName() {
        return name;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public FileSystemElement getParent() {
        return parent;
    }

    /**
     * Display the file system element with a specific depth.
     *
     * @param depth the depth to display the element at
     */
    public abstract void display(int depth);
}

/**
 * Class representing a file in the file system.
 */

class File extends FileSystemElement {
    public File(String name, Timestamp dateCreated, FileSystemElement parent) {
        super(name, dateCreated, parent);
    }

    /**
     * Display the file with a specific depth.
     *
     * @param depth the depth to display the file at
     */
    @Override
    public void display(int depth) {
        for (int i = 0; i < depth; i++) {
            System.out.print("   ");
        }
        System.out.println(name);
    }
}

/**
 * Class representing a directory in the file system.
 */
class Directory extends FileSystemElement {
    private List<FileSystemElement> children;

    public Directory(String name, Timestamp dateCreated, FileSystemElement parent) {
        super(name, dateCreated, parent);
        this.children = new LinkedList<>();
    }

    public void addChild(FileSystemElement child) {
        children.add(child);
    }

    public void removeChild(FileSystemElement child) {
        children.remove(child);
    }

    public List<FileSystemElement> getChildren() {
        return children;
    }

    /**
     * Display the directory with a specific depth.
     *
     * @param depth the depth to display the directory at
     */
    @Override
    public void display(int depth) {
        for (int i = 0; i < depth; i++) {
            System.out.print("   ");
        }
        System.out.println("*" + name + "/");
        for (FileSystemElement child : children) {
            child.display(depth + 1);
        }
    }
}

/**
 * Class representing the file system.
 */
class FileSystem {
    private Directory root;
    private Directory currentDirectory;

    public FileSystem() {
        this.root = new Directory("root", new Timestamp(System.currentTimeMillis()), null);
        this.currentDirectory = root;
    }

    public Directory getCurrentDirectory() {
        return currentDirectory;
    }

    /**
     * Change the current directory.
     *
     * @param path the path to the new directory
     */
    public void changeDirectory(String path) {
        if ("..".equals(path)) {
            if (currentDirectory.getParent() != null) {
                currentDirectory = (Directory) currentDirectory.getParent();
                System.out.println("Directory changed to: " + currentDirectory.getName());
            } else {
                System.out.println("Already at the root directory.");
            }
            return;
        }
    
        Directory newDir = navigateToDirectory(path, currentDirectory);
        if (newDir != null) {
            currentDirectory = newDir;
            System.out.println("Directory changed to: " + currentDirectory.getName());
        } else {
            System.out.println("Directory not found: " + path);
        }
    }
    
    private Directory navigateToDirectory(String path, Directory startDir) {
        Directory currentDir = startDir;
    
        if (path.startsWith("/")) { // Absolute path
            currentDir = root;
            path = path.substring(1); // Remove leading '/'
        }
    
        if (path.isEmpty()) {
            return currentDir;
        }
    
        String[] parts = path.split("/");
    
        for (String part : parts) {
            boolean found = false;
            if (part.equals("..")) {
                if (currentDir.getParent() != null) {
                    currentDir = (Directory) currentDir.getParent();
                    found = true;
                } 
                else {
                    return null; // Cannot navigate above root
                }
            } 
            
            else {
                boolean dirFound = false;
                for (FileSystemElement element : currentDir.getChildren()) {
                    if (element instanceof Directory && element.getName().equals(part)) {
                        currentDir = (Directory) element;
                        dirFound = true;
                        break;
                    }
                }
                if (!dirFound) {
                    continue; // Directory not found
                }
            }
        }
    
        return currentDir;
    }
    
    /**
     * List the contents of the current directory.
     */       
    public void listDirectoryContents() {
        currentDirectory.display(0);
    }

    /**
     * Create a new file in the current directory.
     *
     * @param name the name of the new file
     */
    public void createFile(String name) {
        File newFile = new File(name, new Timestamp(System.currentTimeMillis()), currentDirectory);
        currentDirectory.addChild(newFile);
        System.out.println("File created: " + name);
    }

    /**
     * Create a new directory in the current directory.
     *
     * @param name the name of the new directory
     */
    public void createDirectory(String name) {
        Directory newDirectory = new Directory(name, new Timestamp(System.currentTimeMillis()), currentDirectory);
        currentDirectory.addChild(newDirectory);
        System.out.println("Directory created: " + name + "/");
    }

    /**
     * Delete a file or directory.
     *
     * @param element the file or directory to delete
     */
    public void delete(FileSystemElement element) {
        if (element instanceof Directory) {
            Directory dir = (Directory) element;
            for (FileSystemElement child : new ArrayList<>(dir.getChildren())) {
                delete(child);
            }
            if (dir.getParent() != null) {
                ((Directory) dir.getParent()).removeChild(dir); // Cast parent to Directory and call removeChild
            }
            System.out.println("Directory deleted: " + dir.getName());
        } 
        
        else if (element instanceof File) {
            if (element.getParent() != null) {
                ((Directory) element.getParent()).removeChild(element); // Cast parent to Directory and call removeChild
            }
            System.out.println("File deleted: " + element.getName());
        }
    }
    
    /**
     * Move a file or directory to a new parent directory.
     *
     * @param element  the file or directory to move
     * @param newParent the new parent directory
     */
    public void move(FileSystemElement element, Directory newParent) {
        if (element.getParent() != null) {
            ((Directory) element.getParent()).removeChild(element); // Cast parent to Directory and call removeChild
        }
        newParent.addChild(element);
        System.out.println((element instanceof File ? "File" : "Directory") + " moved to " + newParent.getName());
    }
    
    /**
     * Search for files or directories with a specific query.
     *
     * @param query     the search query
     * @param directory the directory to search in
     * @return a list of matching files or directories
     */
    public List<FileSystemElement> search(String query, Directory directory) {
        List<FileSystemElement> results = new ArrayList<>();
        for (FileSystemElement child : directory.getChildren()) {
            if (child.getName().contains(query)) {
                results.add(child);
            }
            if (child instanceof Directory) {
                results.addAll(search(query, (Directory) child));
            }
        }
        return results;
    }

    /**
     * Search for paths of files or directories with a specific query.
     *
     * @param query the search query
     * @param directory the directory to search in
     * @param path the current path
     * @return a list of matching paths
     */
    public List<String> searchForPath(String query, Directory directory, String path) {
        List<String> results = new ArrayList<>();
        
        for (FileSystemElement child : directory.getChildren()) {
            if (child.getName().contains(query)) {
                String fullPath = path.isEmpty() ? child.getName() : path + "/" + child.getName();
                results.add(fullPath);
            }
            
            if (child instanceof Directory) {
                String newPath = path.isEmpty() ? child.getName() : path + "/" + child.getName();
                results.addAll(searchForPath(query, (Directory) child, newPath));
            }
        }
        
        return results;
    }
    
    /**
     * Print the directory tree.
     */
    public void printTree() {
        System.out.println("Path to current directory from root:");
        root.display(0);
    }

    /**
     * Sort the contents of a directory by date created.
     *
     * @param directory the directory to sort
     */
    public void sortContentsByDateCreated(Directory directory) {
        List<FileSystemElement> allElements = new ArrayList<>();
        
        // Add all elements from the directory and its children recursively
        addElementsRecursively(allElements, directory);
        
        // Sort the list by date created
        allElements.sort(Comparator.comparing(FileSystemElement::getDateCreated));
        
        // Print the sorted list
        System.out.println("Sorted contents by date created:");
        for (FileSystemElement element : allElements) {
            if (element instanceof File) {
                System.out.println("File: " + element.getName() + " - Date Created: " + element.getDateCreated());
            } else if (element instanceof Directory) {
                System.out.println("Directory: " + element.getName() + "/ - Date Created: " + element.getDateCreated());
            }
        }
    }
    
    private void addElementsRecursively(List<FileSystemElement> list, FileSystemElement element) {
        if (element instanceof File || element instanceof Directory) {
            list.add(element);
        }
        
        if (element instanceof Directory) {
            for (FileSystemElement child : ((Directory) element).getChildren()) {
                addElementsRecursively(list, child);
            }
        }
    }
    }

public class Main {
    public static void main(String[] args) {
        FileSystem fs = new FileSystem();
        Scanner scanner = new Scanner(System.in);
    
        boolean running = true;
    
        while (running) {
            System.out.println("===== File System Management Menu =====");
            System.out.println("1. Change directory");
            System.out.println("2. List directory contents");
            System.out.println("3. Create file/directory");
            System.out.println("4. Delete file/directory");
            System.out.println("5. Move file/directory");
            System.out.println("6. Search file/directory");
            System.out.println("7. Print directory tree");
            System.out.println("8. Sort contents by date created");
            System.out.println("9. Exit");
            System.out.print("Please select an option: ");
    
            int choice = scanner.nextInt();
            scanner.nextLine();
    
            switch (choice) {
                case 1:
                    System.out.println("Enter new directory path: ");
                    String path = scanner.nextLine();
                    fs.changeDirectory(path);
                    break;
                case 2:
                    fs.listDirectoryContents();
                    break;
                case 3:
                    System.out.println("Create file or directory (f/d): ");
                    String fileType = scanner.nextLine();
                    System.out.println("Enter name: ");
                    String name = scanner.nextLine();
                    if ("f".equalsIgnoreCase(fileType)) {
                        fs.createFile(name);
                    } else if ("d".equalsIgnoreCase(fileType)) {
                        fs.createDirectory(name);
                    }
                    break;
                case 4:
                    System.out.println("Enter name of file/directory to delete: ");
                    String deleteName = scanner.nextLine();
                    List<FileSystemElement> deleteResults = fs.search(deleteName, fs.getCurrentDirectory());
                    if (!deleteResults.isEmpty()) {
                        fs.delete(deleteResults.get(0)); // Delete the first found element
                    } else {
                        System.out.println("File/directory not found.");
                    }
                    break;
                case 5:
                    System.out.println("Enter the name of file/directory to move: ");
                    String moveName = scanner.nextLine();
                    System.out.println("Enter new directory path: ");
                    String newPath = scanner.nextLine();
                    Directory newParent = (Directory) fs.search(newPath, fs.getCurrentDirectory()).get(0);
                    List<FileSystemElement> moveResults = fs.search(moveName, fs.getCurrentDirectory());
                    if (!moveResults.isEmpty()) {
                        fs.move(moveResults.get(0), newParent); // Move the first found element
                    } else {
                        System.out.println("File/directory not found.");
                    }
                    break;
                    case 6:
                    System.out.println("Search query: ");
                    String query = scanner.nextLine();
                    List<String> searchResults = fs.searchForPath(query, fs.getCurrentDirectory(), "");
                    
                    if (!searchResults.isEmpty()) {
                        System.out.println("Search results:");
                        for (String pathPart : searchResults) {
                            System.out.println(pathPart);
                        }
                    } else {
                        System.out.println("No matching files/directories found.");
                    }
                    break;
                                case 7:
                    fs.printTree();
                    break;
                case 8:
                    fs.sortContentsByDateCreated(fs.getCurrentDirectory());
                    break;
                case 9:
                    System.out.println("Exiting...");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    
        scanner.close();
    }
    }


