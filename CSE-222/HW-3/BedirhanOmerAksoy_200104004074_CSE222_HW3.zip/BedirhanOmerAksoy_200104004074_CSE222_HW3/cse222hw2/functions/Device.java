public interface Device {

    String getCategory();

    String getName();

    void setName(String name);

    double getPrice();

    void setPrice(double price);

    int getQuantity();

    void setQuantity(int quantity);
}