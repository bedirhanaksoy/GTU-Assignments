import java.util.Scanner;

public class App{
    public static void main(String[] args) {

        Inventory myInventory;
        myInventory = new Inventory();

        Scanner scanner = new Scanner(System.in);

        int choice;
        do {
            System.out.println();
            System.out.println("Welcome to the Electronics Inventory Management System!");
            System.out.println("Please select an option:");
            System.out.println();
            System.out.println("1. Add a new device");
            System.out.println("2. Remove a device");
            System.out.println("3. Update device details");
            System.out.println("4. List all devices");
            System.out.println("5. Find the cheapest device");
            System.out.println("6. Sort devices by price");
            System.out.println("7. Calculate total inventory value");
            System.out.println("8. Restock a device");
            System.out.println("9. Export inventory report");
            System.out.println("10. *List of categories (use these categories for adding a new device)");
            System.out.println("0. Exit");
            System.out.println();
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (choice) {
                case 1:
                    myInventory.addNewDevice(scanner);
                    break;                
                case 2:
                    myInventory.removeDevice(scanner);
                    break;
                case 3:
                    myInventory.updateDeviceInformation(scanner);
                    break;
                case 4:
                    myInventory.printInventory();
                    break;
                case 5:
                    myInventory.printCheapestDevice();
                    break;
                case 6:
                    myInventory.printDevicesSortedByPrice();
                    break;
                case 7:
                    myInventory.printTotalValue();
                    break;
                case 8:
                    myInventory.restockDevice(scanner);
                    break;
                case 9:
                    myInventory.inventoryReport();
                    break;
                case 10:
                    myInventory.printCategories();
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a number between 0 and 9.");
            }
        } 
        while (choice != 0);
        
        scanner.close();
    }
}