import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Inventory {
    private LinkedList<ArrayList<Device>> Inventory;

    public Inventory() {
        Inventory = new LinkedList<>();

        for (int i = 0; i < 5; i++) {
            Inventory.add(new ArrayList<>());
        }
    }

    /**
     * in this function, it searches categories for entered category to check if that category exists,
     * thus time complexity is O(n)
     * @param scanner scanner variable for taking variable from user without opening a new scanner
     */
    public void addNewDevice(Scanner scanner) {
        
        Device newDevice;

        System.out.print("Enter category name: ");
        String category = scanner.nextLine();

        if(categoryExists(category)){
            System.out.print("Enter device name: ");
            String name = scanner.nextLine();   
            
            System.out.print("Enter price: ");
            String priceInput = scanner.nextLine();  
            double price = Double.parseDouble(priceInput);

            System.out.print("Enter quantity: ");
            String quantityInput = scanner.nextLine();  
            int quantity = Integer.parseInt(quantityInput);

            switch (category) {
                case "Smartphone":
                    newDevice = new Smartphone(name, price, quantity);
                    Inventory.get(0).add(newDevice); 
                    System.out.println();
                    System.out.println(newDevice.getCategory() + ", " + newDevice.getName() + ", $" + newDevice.getPrice() + ", " + newDevice.getQuantity() + " amount added to inventory...");
                    break;
    
                case "Laptop":
                    newDevice = new Laptop(name, price, quantity);
                    Inventory.get(1).add(newDevice); 
                    System.out.println();
                    System.out.println(newDevice.getCategory() + ", " + newDevice.getName() + ", $" + newDevice.getPrice() + ", " + newDevice.getQuantity() + " amount added to inventory...");
                    break;
    
                case "SmartTV":
                    newDevice = new SmartTV(name, price, quantity);
                    Inventory.get(2).add(newDevice); 
                    System.out.println();
                    System.out.println(newDevice.getCategory() + ", " + newDevice.getName() + ", $" + newDevice.getPrice() + ", " + newDevice.getQuantity() + " amount added to inventory...");
                    break;
    
                case "Tablet":
                    newDevice = new Tablet(name, price, quantity);
                    Inventory.get(3).add(newDevice); 
                    System.out.println();
                    System.out.println(newDevice.getCategory() + ", " + newDevice.getName() + ", $" + newDevice.getPrice() + ", " + newDevice.getQuantity() + " amount added to inventory...");
                    break;
    
                case "Wearable":
                    newDevice = new Wearable(name, price, quantity);
                    Inventory.get(4).add(newDevice); 
                    System.out.println();
                    System.out.println(newDevice.getCategory() + ", " + newDevice.getName() + ", $" + newDevice.getPrice() + ", " + newDevice.getQuantity() + " amount added to inventory...");
                    break;
    
                default:
                    System.out.println("Invalid category: " + category);
            }
        }
        else {
            System.out.println("Category not found in the inventory...");
        }
    }

    /**
     * in this function, it searches categories for entered category to check if that category exists,
     * thus time complexity is O(n)
     * @param categoryName entered category name to check if it exists
     * @return
     */
    public boolean categoryExists(String categoryName) {

        String[] categories = {"Smartphone", "Laptop", "SmartTV", "Tablet", "Wearable"};
    
        for (String category : categories) {
            if (category.equalsIgnoreCase(categoryName)) {
                return true;
            }
        }
        return false; 
    }

   
    /**
     * function prints list of the devices in the inventory. it searches linkedlist and all the categories array lists,
     * thus, time complexity is O(n*m)
     */
    public void printInventory() {
        int itemIndex = 1;

        System.out.println("Device List:");
        System.out.println();

        if(isInventoryEmpty()){
            System.out.println("Inventory is empty...");
            System.out.println();
        }
        else{
            System.out.println(" No.    -    Category    -    Name    -    Price    -    Quantity");
            System.out.println("-----------------------------------------------------------------");

            for (ArrayList<Device> categoryList : Inventory) {
                if (!categoryList.isEmpty()) {
                    for (Device device : categoryList) {
                        System.out.println(" " + itemIndex + ".     - " + device.getCategory() + "  -  "+ device.getName() + "   -  $" + device.getPrice() + "   -  " + device.getQuantity());
                        itemIndex++;
                    }
                } 
            }
        }
    }

   
    /**
     * function searches linkedlists arraylist elements, only checks them for if arraylist is empty or not
     * thus, time complexity is O(n)
     */
    public boolean isInventoryEmpty() {
        for (ArrayList<Device> categoryList : Inventory) {
            if (!categoryList.isEmpty()) {
                return false; 
            }
        }
        return true; 
    }
    
    /**
     * function searches name of the devices in the inventory. it searches linkedlist and all the categories array lists,
     * thus, time complexity is O(n*m)
     * @param scanner scanner variable for taking variable from user without opening a new scanner
     */
    public void updateDeviceInformation(Scanner scanner) {

        System.out.print("Enter the name of the device to update: ");
        String deviceName = scanner.nextLine();

        boolean deviceFound = false;
        for (ArrayList<Device> categoryList : Inventory) {
            for (Device device : categoryList) {
                if (device.getName().equals(deviceName)) {

                    System.out.print("Enter new price (leave blank to keep current price): ");
                    String priceInput = scanner.nextLine();
                    double newPrice = priceInput.isEmpty() ? device.getPrice() : Double.parseDouble(priceInput);

                    System.out.print("Enter new quantity (leave blank to keep current quantity): ");
                    String quantityInput = scanner.nextLine();
                    int newQuantity = quantityInput.isEmpty() ? device.getQuantity() : Integer.parseInt(quantityInput);

                    device.setPrice(newPrice);
                    device.setQuantity(newQuantity);

                    System.out.println(deviceName + " details updated: Price - $" + newPrice + ", Quantity - " + newQuantity);
                    
                    deviceFound = true;
                    break; 
                }
            }
            if (deviceFound) {
                break; 
            }
        }

        if (!deviceFound) {
            System.out.println("Device not found in the inventory.");
        }
    }

    /**
     * function searches all category array lists and in every arraylists, it searches for all devices,
     * thus, time complexity is O(n*m).
     * @param scanner scanner variable for taking variable from user without opening a new scanner
     */
    public void removeDevice(Scanner scanner) {
        System.out.print("Enter the name of the device to remove from inventory: ");
        String deviceName = scanner.nextLine();
        
        boolean deviceFound = false;
        for (ArrayList<Device> categoryList : Inventory) {
            Iterator<Device> iterator = categoryList.iterator();
            while (iterator.hasNext()) {
                Device device = iterator.next();
                if (device.getName().equals(deviceName)) {
                    System.out.println(device.getName() + " has been removed from inventory.");
                    iterator.remove(); 
                    deviceFound = true;
                    break;
                }
            }
            if (deviceFound) {
                break;
            }
        }

        if (!deviceFound) {
            System.out.println("Device not found in the inventory.");
        }
    }

    /**
     * function prints the cheapest device with searches all category array lists and in every arraylists, it searches for all devices,
     * thus, time complexity is O(n*m).
     * @param scanner scanner variable for taking variable from user without opening a new scanner
     */
    public void printCheapestDevice() {
        Device cheapestDevice = null;
        double minPrice = Double.MAX_VALUE;
    
        for (ArrayList<Device> categoryList : Inventory) {
            for (Device device : categoryList) {
                if (device.getPrice() < minPrice) {
                    cheapestDevice = device;
                    minPrice = device.getPrice();
                }
            }
        }
    
        if (cheapestDevice != null) {
            System.out.println("Cheapest device in inventory:");
            System.out.println("Category: " + cheapestDevice.getCategory() + ", Name: " + cheapestDevice.getName() + ", Price: $" + cheapestDevice.getPrice() + ", Quantity: "+ cheapestDevice.getQuantity() );
        } 
        else {
            System.out.println("Inventory is empty...");
        }
    }

    /**
     * java util's collection sort has default O(n log n) time complexity. In function, loops searches for linkedlist elements and their time complexities are O(n),
     * O(n log n) is more dominant than O(n), thus, time complexity is O(n logn).
     */
    public void printDevicesSortedByPrice() {
        int itemIndex = 1;

        List<Device> allDevices = new ArrayList<>();

        for (ArrayList<Device> categoryList : Inventory) {
            allDevices.addAll(categoryList);
        }

        Collections.sort(allDevices, (device1, device2) -> Double.compare(device1.getPrice(), device2.getPrice()));

        
        if(isInventoryEmpty()){
            System.out.println("Inventory is empty...");
            System.out.println();
        }
        else{
            System.out.println("Devices sorted by price:");

            System.out.println(" No.    -    Category    -    Name    -    Price    -    Quantity");
            System.out.println("-----------------------------------------------------------------");

            for (Device device : allDevices) {
                System.out.println(" " + itemIndex + ".     - " + device.getCategory() + "  -  "+ device.getName() + "   -  $" + device.getPrice() + "   -  " + device.getQuantity());
                itemIndex++;
            }
        }
    }

    /**
     * function prints the total value with searching all category array lists and in every arraylists, it searches for all devices,
     * thus, time complexity is O(n*m).
     */
    public void printTotalValue() {
        
        double totalValue = 0;
        
        for (ArrayList<Device> categoryList : Inventory) {
            for (Device device : categoryList) {
                totalValue = totalValue + (device.getPrice() * device.getQuantity());
            }
        }
        System.out.println("Total inventory value: $" + totalValue);
    }  

    /**
     * this function prints the categories with iterating trough a set number of elements,
     * thus, time complexity is O(n).
     */
    public void printCategories() {
        String[] categories = {"Smartphone", "Laptop", "SmartTV", "Tablet", "Wearable"};
    
        System.out.println("List of Categories:");
        for (String category : categories) {
            System.out.println(category);
        }
    }
    
    /**
     * function returns the total value with searching all category array lists and in every arraylists, it searches for all devices,
     * thus, time complexity is O(n*m).
     */
    public double totalValue() {
        
        double totalValue = 0;
        
        for (ArrayList<Device> categoryList : Inventory) {
            for (Device device : categoryList) {
                totalValue = totalValue + (device.getPrice() * device.getQuantity());
            }
        }
        return totalValue;

    }  

    /**
     * function returns the total number of devices with searching all category array lists and in every arraylists, it searches for all devices,
     * thus, time complexity is O(n*m).
     */
    public int totalNumberOfDevices() {
        
        int deviceCount = 0;
        
        for (ArrayList<Device> categoryList : Inventory) {
            deviceCount = deviceCount + categoryList.size();
        }
        return deviceCount;

    }  

    /**
     * function iterates through the all linkedlists arraylist elements and every arraylists devide elements,
     * so the time complexity is O(n*m)
     * @param scanner scanner variable for taking variable from user without opening a new scanner
     */
    public void restockDevice(Scanner scanner) {

        System.out.print("Enter the name of the device to restock: ");
        String deviceName = scanner.nextLine();

        Device targetDevice = null;
        for (ArrayList<Device> categoryList : Inventory) {
            for (Device device : categoryList) {
                if (device.getName().equals(deviceName)) {
                    targetDevice = device;
                    break;
                }
            }
            if (targetDevice != null) {
                break;
            }
        }

        if (targetDevice == null) {
            System.out.println("Device not found in the inventory.");
            
            return;
        }


        System.out.print("Do you want to add or remove stock? (Add/Remove): ");
        String action = scanner.nextLine();


        if (action.equalsIgnoreCase("Add")) {

            System.out.print("Enter the quantity to add: ");
            int quantityToAdd = scanner.nextInt();
            targetDevice.setQuantity(targetDevice.getQuantity() + quantityToAdd);
            System.out.println(deviceName + " restocked. New quantity: " + targetDevice.getQuantity());

        } 
        else if (action.equalsIgnoreCase("Remove")) {

            System.out.print("Enter the quantity to remove: ");
            int quantityToRemove = scanner.nextInt();
            int currentQuantity = targetDevice.getQuantity();

            if (quantityToRemove > currentQuantity) {
                System.out.println("Cannot remove more than available quantity.");

            } 
            else {
                targetDevice.setQuantity(currentQuantity - quantityToRemove);
                System.out.println(deviceName + " stock reduced. New quantity: " + targetDevice.getQuantity());

            }
        } 
        else {
            System.out.println("Invalid action. Please enter either 'Add' or 'Remove'.");
        }
    }

    /**
     * in worst case, if every caterory is full of n elements, it searches for all linkedlist elements and every arraylists device elements,
     * thus, time complexity is O(n*m)
     */
    public void inventoryReport() {
        int itemIndex = 1;
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy_hh-mm-ss");
        String formattedDate = dateFormat.format(currentDate);
    
        String filename = "inventory_report_" + formattedDate + ".txt";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("Aksoy's Electronic Heaven Inventory Report\n");
            writer.write("Generated on: " + formattedDate + "\n\n");
            writer.write(" No.    -    Category    -    Name    -    Price    -    Quantity\n");
            writer.write("-----------------------------------------------------------------\n");

            for (ArrayList<Device> categoryList : Inventory) {
                if (!categoryList.isEmpty()) {
                    for (Device device : categoryList) {
                        writer.write(" " + itemIndex + "      - " + device.getCategory() + "  -  "+ device.getName() + "   -  $" + device.getPrice() + "   -  " + device.getQuantity() + "\n");
                        itemIndex++;
                    }
                } 
            }

            writer.write("\n\n");
            writer.write("Summary:\n\n");
            writer.write("- Total Number of Devices: " + totalNumberOfDevices() + "\n");
            writer.write("- Total Inventory Value: " + totalValue() + "\n\n");
            writer.write("End of Report");

            System.out.println("Report written to file: " + filename);
        } 
        catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }

    }

}