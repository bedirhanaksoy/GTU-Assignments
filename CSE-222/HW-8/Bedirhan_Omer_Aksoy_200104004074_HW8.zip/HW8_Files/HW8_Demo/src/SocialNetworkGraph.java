import java.util.*;

public class SocialNetworkGraph {
    private Map<String, Person> people = new HashMap<>();
    private Map<Person, List<Person>> graph = new HashMap<>();

    /**
     * This method add person to social network graph.
     * 
     * @param name   the name of the person
     * @param age    the age of the person
     * @param hobbies list of hobbies of the person
     */
    public void addPerson(String name, int age, List<String> hobbies) {
        Person person = new Person(name, age, hobbies);
        people.put(name, person);
        graph.put(person, new ArrayList<>());
        System.out.println("Person added: " + person + " (Timestamp: " + person.timestamp + ")");
    }

    /**
     * This method remove person from social network graph.
     * 
     * @param name the name of the person to remove
     */
    public void removePerson(String name) {
        Person person = people.remove(name);
        if (person != null) {
            graph.remove(person);
            for (List<Person> friends : graph.values()) {
                friends.remove(person);
            }
            System.out.println("Person removed: " + name);
        } else {
            System.out.println("Person not found.");
        }
    }

    /**
     * This method add friendship between two persons.
     * 
     * @param name1 the name of first person
     * @param name2 the name of second person
     */
    public void addFriendship(String name1, String name2) {
        Person person1 = people.get(name1);
        Person person2 = people.get(name2);
        if (person1 != null && person2 != null) {
            graph.get(person1).add(person2);
            graph.get(person2).add(person1);
            System.out.println("Friendship added between " + person1.name + " and " + person2.name);
        } else {
            System.out.println("One or both persons not found in the network.");
        }
    }

    /**
     * This method remove friendship between two persons.
     * 
     * @param name1 the name of first person
     * @param name2 the name of second person
     */
    public void removeFriendship(String name1, String name2) {
        Person person1 = people.get(name1);
        Person person2 = people.get(name2);
        if (person1 != null && person2 != null) {
            graph.get(person1).remove(person2);
            graph.get(person2).remove(person1);
            System.out.println("Friendship removed between " + person1.name + " and " + person2.name);
        } else {
            System.out.println("One or both persons not found in the network.");
        }
    }

    /**
     * This method find shortest path between two persons using BFS.
     * 
     * @param startName the name of start person
     * @param endName   the name of end person
     */
    public void findShortestPath(String startName, String endName) {
        Person start = people.get(startName);
        Person end = people.get(endName);
        if (start == null || end == null) {
            System.out.println("One or both persons not found in the network.");
            return;
        }

        Queue<Person> queue = new LinkedList<>();
        Map<Person, Person> prev = new HashMap<>();
        Set<Person> visited = new HashSet<>();

        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            Person current = queue.poll();
            if (current.equals(end)) {
                printPath(start, end, prev);
                return;
            }

            for (Person neighbor : graph.get(current)) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                    prev.put(neighbor, current);
                }
            }
        }
        System.out.println("No connection found between " + startName + " and " + endName);
    }

    private void printPath(Person start, Person end, Map<Person, Person> prev) {
        List<Person> path = new ArrayList<>();
        for (Person at = end; at != null; at = prev.get(at)) {
            path.add(at);
        }
        Collections.reverse(path);
        System.out.print("Shortest path: ");
        for (Person person : path) {
            System.out.print(person.name + " -> ");
        }
        System.out.println();
    }

    /**
     * This method suggest friends for person based on mutual friends and common hobbies.
     * 
     * @param name      the name of person
     * @param maxFriends maximum number of friends to suggest
     */
    public void suggestFriends(String name, int maxFriends) {
        Person person = people.get(name);
        if (person == null) {
            System.out.println("Person not found.");
            return;
        }

        Map<Person, Double> scores = new HashMap<>();
        Map<Person, Integer> mutualFriendsCount = new HashMap<>();
        Map<Person, Integer> commonHobbiesCount = new HashMap<>();

        for (Person candidate : people.values()) {
            if (candidate.equals(person) || graph.get(person).contains(candidate)) {
                continue;
            }
            int mutualFriends = 0;
            int commonHobbies = 0;

            for (Person friend : graph.get(person)) {
                if (graph.get(candidate).contains(friend)) {
                    mutualFriends++;
                }
            }

            for (String hobby : person.hobbies) {
                if (candidate.hobbies.contains(hobby)) {
                    commonHobbies++;
                }
            }

            double score = mutualFriends * 1.0 + commonHobbies * 0.5;
            scores.put(candidate, score);
            mutualFriendsCount.put(candidate, mutualFriends);
            commonHobbiesCount.put(candidate, commonHobbies);
        }

        scores.entrySet().stream()
                .sorted(Map.Entry.<Person, Double>comparingByValue().reversed())
                .limit(maxFriends)
                .forEach(entry -> {
                    Person p = entry.getKey();
                    double score = entry.getValue();
                    int mutualFriends = mutualFriendsCount.get(p);
                    int commonHobbies = commonHobbiesCount.get(p);
                    System.out.println(p.name + " (Score: " + score + ", " + mutualFriends + " mutual friends, " + commonHobbies + " common hobbies)");
                });
    }

    /**
     * This method count number of clusters in social network using BFS.
     */
    public void countClusters() {
        Set<Person> visited = new HashSet<>();
        int clusters = 0;

        for (Person person : graph.keySet()) {
            if (!visited.contains(person)) {
                clusters++;
                List<Person> cluster = new ArrayList<>();
                bfs(person, visited, cluster);
                System.out.println("Cluster " + clusters + ": " + cluster);
            }
        }
        System.out.println("Number of clusters found: " + clusters);
    }

    private void bfs(Person start, Set<Person> visited, List<Person> cluster) {
        Queue<Person> queue = new LinkedList<>();
        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            Person current = queue.poll();
            cluster.add(current);

            for (Person neighbor : graph.get(current)) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                }
            }
        }
    }
}
