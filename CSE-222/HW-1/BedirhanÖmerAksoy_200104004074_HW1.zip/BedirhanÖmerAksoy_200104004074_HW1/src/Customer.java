class Customer extends Person {
    int operator_ID;
    int orderCount;
    Order[] orders;

    public Customer(String name, String surname, String address, String phone, int ID, int operator_ID) {
        super(name, surname, address, phone, ID);
        this.operator_ID = operator_ID;
        this.orderCount = 0;
        this.orders = new Order[100]; 
    }
    
    // sets new order to a customer
    void define_orders(Order order) {
        orders[orderCount++] = order;
    }

    // prints all order objects
    void print_orders() {
        for (int i = 0; i < orderCount; i++) {
            orders[i].print_order(i);
        }
    }

    //prints customer informations
    void print_customer(int index) {

        if(index==-1){
            System.out.println("*** Customer Screen ***");
        }
        
        else {
            index++;
            System.out.println("Customer #" + index + "  (a retail customer)");
        }

        System.out.println("Name & Surname: " + name + " " + surname);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("ID: " + ID);
        System.out.println("Operator ID: " + operator_ID);
        print_orders();
        System.out.println("------------------------------");

    }
}

