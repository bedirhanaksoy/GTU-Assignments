class Person {
    String name;
    String surname;
    String address;
    String phone;
    int ID;

    public Person(String name, String surname, String address, String phone, int ID) {
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.phone = phone;
        this.ID = ID;
    }
}


