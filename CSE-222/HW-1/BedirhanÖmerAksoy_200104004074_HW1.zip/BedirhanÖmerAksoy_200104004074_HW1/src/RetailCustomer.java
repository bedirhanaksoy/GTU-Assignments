
class RetailCustomer extends Customer {
    public RetailCustomer(String name, String surname, String address, String phone, int ID, int operator_ID) {
        super(name, surname, address, phone, ID, operator_ID);
    }
}
