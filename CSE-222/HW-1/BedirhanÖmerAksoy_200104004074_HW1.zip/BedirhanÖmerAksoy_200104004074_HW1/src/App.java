
import java.io.File;
import java.util.Scanner;

public class App {
    // fixed array sizes 100
    static Operator[] operators = new Operator[100];
    static Customer[] customers = new Customer[100];
    static Order[] orders = new Order[100];

    static int orderIndex = 0;
    static int operatorIndex = 0;
    static int customerIndex = 0;


    public static void main(String[] args) {
        try {
            File file = new File("/home/aksoy/Desktop/project/content.txt");
            Scanner fileScanner = new Scanner(file);
            
            //reads line by line
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] data = line.split(";");

                if (data.length > 0) {
                    String dataType = data[0].trim();
                    // process data in order to its type
                    switch (dataType) {
                        case "operator":
                            processOperator(data);
                            break;
                        case "retail_customer":
                            processRetailCustomer(data);
                            break;
                        case "corporate_customer":
                            processCorporateCustomer(data);
                            break;
                        case "order":
                            processOrder(data);
                            break;
                        default:
                            break;
                    }
                }
            }
            fileScanner.close();
            // associates orders customers and operators end of the read operation
            associateOperatorsCustomersAndOrders();
        } 
        
        catch (Exception e) {
            System.out.println("Error reading the file: " + e.getMessage());
            return;
        }

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Please enter your ID... ");
            try {
                // checks for negative or too big int inputs
                int inputID = scanner.nextInt();
                if (inputID <= 0 || inputID > Integer.MAX_VALUE) {
                    throw new Exception("ID must be a positive integer and must be small enough for int type");
                }
                findAndPrintInformation(inputID);
            } 
            catch (Exception e) {
                System.out.println("Error reading input: " + e.getMessage());
            }
        }
    }

    private static void processOperator(String[] data) throws Exception {

        if (data.length != 7) {
            throw new Exception("Invalid number of columns for operator data");
        }

        try{
            // type casting to int in a try block to catch any type convertion error

            String name = data[1].trim();
            String surname = data[2].trim();
            String address = data[3].trim();
            String phone = data[4].trim();

            int ID = Integer.parseInt(data[5].trim());
            int wage = Integer.parseInt(data[6].trim()); 

            // checks if the id is unique
            if(checkIfPersonIDUnique(ID)==1){
                Operator operator = new Operator(name, surname, address, phone, ID, wage);
                operators[operatorIndex++] = operator;    
            }
        
        } 
        catch (Exception e) {
            throw new Exception("Error parsing ID or strings");
        }
    }

    private static void processRetailCustomer(String[] data) throws Exception {
        // same handlings done with processOperator
        try{
            String name = data[1].trim();
            String surname = data[2].trim();
            String address = data[3].trim();
            String phone = data[4].trim();
            int ID = Integer.parseInt(data[5].trim());
            int operator_ID = Integer.parseInt(data[6].trim());

            if(checkIfPersonIDUnique(ID)==1){
                RetailCustomer retailCustomer = new RetailCustomer(name, surname, address, phone, ID, operator_ID);
                customers[customerIndex++] = retailCustomer;
            }
        }
        catch (Exception e) {
            throw new Exception("Error parsing ID or strings");
        }
    }

    private static void processCorporateCustomer(String[] data) throws Exception{

        try{
            String name = data[1].trim();
            String surname = data[2].trim();
            String address = data[3].trim();
            String phone = data[4].trim();
            int ID = Integer.parseInt(data[5].trim());
            int operator_ID = Integer.parseInt(data[6].trim());
            String companyName = data[7].trim();

            if(checkIfPersonIDUnique(ID)==1){
                CorporateCustomer corporateCustomer = new CorporateCustomer(name, surname, address, phone, ID, operator_ID, companyName);
                customers[customerIndex++] = corporateCustomer;
            }
        }
        catch (Exception e) {
            throw new Exception("Error parsing ID or strings");
        }
        
    }

    private static void processOrder(String[] data) throws Exception{
        try{
            String productName = data[1].trim();
            int count = Integer.parseInt(data[2].trim());
            double totalPrice = Double.parseDouble(data[3].trim());
            int status = Integer.parseInt(data[4].trim());
            int customer_ID = Integer.parseInt(data[5].trim());

            Order order = new Order(productName, count, totalPrice, status, customer_ID);
            orders[orderIndex++] = order;
        }
        catch (Exception e) {
            throw new Exception("Error parsing ID or strings");
        }
    }

    private static void findAndPrintInformation(int inputID) {
        
        int found = 0;

        for(int i=0; i<operatorIndex; i++){
            if(inputID==operators[i].ID){
                operators[i].print_operator();
                operators[i].print_customers();
                found = 1;
            }
        }
        if(found==0){
            for(int i=0; i<customerIndex; i++){
                if(inputID==customers[i].ID){
                    customers[i].print_customer(-1);
                    found = 1;
                }
            }
        }

        if(found==0){
            System.out.println("No information found for ID " + inputID);
        }
    }

    // associates customers to operators and orders to customers
    private static void associateOperatorsCustomersAndOrders(){
        for(int i=0; i<operatorIndex; i++){
            for(int j=0;j<customerIndex; j++){
                if(operators[i].ID==customers[j].operator_ID){
                    operators[i].define_customers(customers[j]);
                }
            }
        }
        for(int i=0; i<customerIndex; i++){
            for(int j=0;j<orderIndex; j++){
                if(customers[i].ID==orders[j].customer_ID){
                    customers[i].define_orders(orders[j]);
                }
            }
        }
    }

    // checks if the ID is unique
    private static int checkIfPersonIDUnique(int id){
        for(int i =0; i<operatorIndex; i++){
            if(operators[i].ID==id){
                return 0;
            }
        }  
        for(int i=0; i<customerIndex; i++){
            if(customers[i].ID==id){
                return 0;
            }
        }
        return 1;
    }
}