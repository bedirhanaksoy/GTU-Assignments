class Order {
    String product_name;
    int count;
    double total_price;
    int status; 
    int customer_ID;

    public Order(String productName, int count, double totalPrice, int status, int customer_ID) {
        this.product_name = productName;
        this.count = count;
        this.total_price = totalPrice;
        this.status = status;
        this.customer_ID = customer_ID;
    }

    // prints the order details
    void print_order(int index) {
        index++;
        System.out.println("Order #" + index + " =>" + "Product: " + product_name + " - Count: " + count + " - Total Price: " + total_price + " - Status: " + getStatusString());
    }

    private String getStatusString() {
        switch (status) {
            case 0:
                return "Initialized";
            case 1:
                return "Processing";
            case 2:
                return "Completed";
            case 3:
                return "Cancelled";
            default:
                return "Unknown";
        }
    }
}
