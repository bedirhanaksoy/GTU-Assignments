class Operator extends Person {
    int wage;
    int customerCount;
    Customer[] customers;

    public Operator(String name, String surname, String address, String phone, int ID, int wage) {
        super(name, surname, address, phone, ID);
        this.wage = wage;
        this.customerCount = 0;
        this.customers = new Customer[100]; 
    }

    // sets new customer to an operator
    void define_customers(Customer customer) {
        customers[customerCount++] = customer;
    }

    void print_operator() {
        System.out.println("*** Operator Screen ***");
        System.out.println("------------------------------");
        System.out.println("Name & Surname: " + name + " " + surname);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("ID: " + ID);
        System.out.println("Wage: " + wage);
        System.out.println("------------------------------");
    }

    // prints customer objects
    void print_customers() {
        for (int i = 0; i < customerCount; i++) {
            customers[i].print_customer(i);
        }
    }
}
