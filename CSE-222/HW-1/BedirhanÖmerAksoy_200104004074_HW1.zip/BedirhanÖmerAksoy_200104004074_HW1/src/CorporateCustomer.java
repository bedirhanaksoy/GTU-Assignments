
class CorporateCustomer extends Customer {
    String companyName;

    public CorporateCustomer(String name, String surname, String address, String phone, int ID, int operator_ID, String companyName) {
        super(name, surname, address, phone, ID, operator_ID);
        this.companyName = companyName;
    }
    
    void print_customer(int index){
        if(index==-1){
            System.out.println("*** Customer Screen ***");
        }
        
        else {
            index++;
            System.out.println("Customer #" + index + " (a corporate customer)");
        }

        System.out.println("Name & Surname: " + name + " " + surname);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("ID: " + ID);
        System.out.println("Operator ID: " + operator_ID);
        System.out.println("Corporate Name: " + companyName);

        print_orders();
        System.out.println("------------------------------");

    }

}