import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Iterator;

public class alphabet {
    private Set<Character> english_alphabet = new LinkedHashSet<Character>();
    private Map<Character, Map<Character, Character>> map = new HashMap<Character,  Map<Character, Character>>();
    
    public alphabet() {
        fill_english_alphabet();
        fill_map();
    }
    
    private void fill_english_alphabet() {
        for(char c : "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray()) {
            english_alphabet.add(c);
        }
    }
    
    private void fill_map() {
        Iterator<Character> rowIterator = english_alphabet.iterator();
        Iterator<Character> columnIterator;

        while (rowIterator.hasNext()) {
            char rowIndicator = rowIterator.next();
            columnIterator = english_alphabet.iterator();
            Map<Character, Character> innerMap = new HashMap<>();

            while (columnIterator.hasNext()) {
                char columnIndicator = columnIterator.next();
                char cipherLetter = (char) ('A' + (columnIndicator + rowIndicator - 'A' * 2) % 26);
                innerMap.put(columnIndicator, cipherLetter);
            }

            map.put(rowIndicator, innerMap);
        }
    }

    public void print_map() {
        System.out.println("*** Vigenere Cipher ***\n\n");
        System.out.println("    " + english_alphabet);
        System.out.print("    ------------------------------------------------------------------------------");
        for(Character k: map.keySet()) {
            System.out.print("\n" + k + " | ");
            System.out.print(map.get(k).values());
        }
        System.out.println("\n");
    }

    public Map<Character, Map<Character, Character>> get_map() {
        return map;
    }
}
