import java.util.Map;
import java.util.Iterator;

public class decryptor {
    private Map<Character, Map<Character, Character>> map;
    private String key;
    private String keystream = "";
    private String plain_text = "";
    private String cipher_text;

    public decryptor(Map<Character, Map<Character, Character>> _map, String _key, String text) {
        map = _map;
        key = _key;
        cipher_text = text;
    }

    public void decrypt() {
        generate_keystream();
        generate_plain_text();
    }

    private void generate_keystream() {
        if (key.length() < cipher_text.length()) {
            int repeat = (int) Math.ceil((double) cipher_text.length() / key.length());
            keystream = key.repeat(repeat).substring(0, cipher_text.length());
        } 
        
        else if (key.length() > cipher_text.length()) {
            keystream = key.substring(0, cipher_text.length());
        } 
        
        else {
            keystream = key;
        }
    }

    private void generate_plain_text() {
        Iterator<Character> keystreamIterator = keystream.chars().mapToObj(e -> (char) e).iterator();
    
        for (char c : cipher_text.toCharArray()) {
            char keystreamChar = keystreamIterator.next();
            char plainChar = ' ';                                                               // Initialize with a placeholder character
            for (Map.Entry<Character, Map<Character, Character>> entry : map.entrySet()) {
                char encryptedChar = entry.getKey();
                Map<Character, Character> innerMap = entry.getValue();
                
                if (innerMap.containsKey(keystreamChar)) {                                      // Check if the keystream character is found in the current column

                    if (innerMap.get(keystreamChar) == c) {                                     // Check if the current row of the column contains the ciphertext character

                        plainChar = encryptedChar;
                        break;                                                                  // Exit the loop once the plaintext character is found
                    }
                }
            }
            plain_text += plainChar;
        }
    }
        
    public String get_keystream() {
        return keystream;
    }

    public String get_plain_text() {
        return plain_text;
    }
}
