import java.util.Iterator;
import java.util.Map;

public class encryptor {
    private Map<Character, Map<Character, Character>> map;
    private String key;
    private String keystream = "";
    private String plain_text;
    private String cipher_text = "";

    public encryptor(Map<Character, Map<Character, Character>> _map, String _key, String text) {
        map = _map;
        key = _key;
        plain_text = text;
    }

    public void encrypt() {
        generate_keystream();
        generate_cipher_text();
    }

    private void generate_keystream() {
        if (key.length() < plain_text.length()) {
            int repeat = (int) Math.ceil((double) plain_text.length() / key.length());
            keystream = key.repeat(repeat).substring(0, plain_text.length());
        } 
        
        else if (key.length() > plain_text.length()) {
            keystream = key.substring(0, plain_text.length());
        } 
        
        else {
            keystream = key;
        }
    }

    private void generate_cipher_text() {
        Iterator<Character> keystreamIterator = keystream.chars().mapToObj(e -> (char) e).iterator();

        for (char c : plain_text.toCharArray()) {
            char keystreamChar = keystreamIterator.next();
            cipher_text += map.get(c).get(keystreamChar);
        }
    }

    public String get_keystream() {
        return keystream;
    }

    public String get_cipher_text() {
        return cipher_text;
    }
}
