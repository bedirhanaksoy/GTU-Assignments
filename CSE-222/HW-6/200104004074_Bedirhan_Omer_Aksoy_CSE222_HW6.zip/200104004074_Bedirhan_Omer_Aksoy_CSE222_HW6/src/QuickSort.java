public class QuickSort extends SortAlgorithm {

    public QuickSort(int input_array[]) {
        super(input_array);
    }

    private int partition(int low, int high) {
        int pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            comparison_counter++;
            if (arr[j] < pivot) {
                i++;    // Incrementing index of smaller element
                swap(i, j);    // Swapping arr[i] and arr[j] to move smaller element to the left
            }
        }
        swap(i + 1, high);   // Swap arr[i + 1] and arr[high], placing pivot in correct position
        return i + 1;   // Return the slice index
    }

    private void sort(int low, int high) {
        if (low < high) {
            int si = partition(low, high);  // si is slice index, arr[si] is now at right place

            // Sort elements before slice and after slice recursively
            sort(low, si - 1);
            sort(si + 1, high);
        }
    }

    @Override
    public void sort() {
        sort(0, arr.length - 1);
    }

    @Override
    public void print() {
        System.out.print("Quick Sort\t=>\t");
        super.print();
    }
}
