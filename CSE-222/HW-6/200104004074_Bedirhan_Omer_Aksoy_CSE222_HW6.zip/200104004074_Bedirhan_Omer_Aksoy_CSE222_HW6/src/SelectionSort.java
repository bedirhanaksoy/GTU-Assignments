public class SelectionSort extends SortAlgorithm {

    public SelectionSort(int input_array[]) {
        super(input_array);
    }

    @Override
    public void sort() {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {    // Iterating through the array
            int min_idx = i;    // Find the minimum element in the unsorted part
            for (int j = i + 1; j < n; j++) {
                comparison_counter++;   // Counting comparisons
                if (arr[j] < arr[min_idx]) {
                    min_idx = j;    // Updateing the minimum element
                }
            }
            swap(min_idx, i);   // Swap minimum element with first element of unsorted part
        }
    }

    @Override
    public void print() {
        System.out.print("Selection Sort\t=>\t");
        super.print();
    }
}
