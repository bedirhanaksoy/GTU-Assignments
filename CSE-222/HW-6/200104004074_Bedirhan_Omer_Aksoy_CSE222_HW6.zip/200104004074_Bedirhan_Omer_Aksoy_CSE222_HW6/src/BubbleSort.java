public class BubbleSort extends SortAlgorithm {

    public BubbleSort(int input_array[]) {
        super(input_array);
    }

    @Override
    public void sort() {
        int n = arr.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {   // nested loop for implementing bubble sort algorithm
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                comparison_counter++;       // Increment comparison counter for each comparison
                if (arr[j] > arr[j + 1]) {
                    swap(j, j + 1);
                    swapped = true;
                }
            }
            // If two elements not swapped in the inner loop, the array is already sorted
            if (!swapped) {
                break;
            }
        }
    }

    @Override
    public void print() {
        System.out.print("Bubble Sort\t=>\t");
        super.print();
    }
}
