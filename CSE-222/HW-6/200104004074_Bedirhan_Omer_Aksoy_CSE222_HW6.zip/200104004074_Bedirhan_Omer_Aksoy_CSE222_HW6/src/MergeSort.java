public class MergeSort extends SortAlgorithm {

    public MergeSort(int input_array[]) {
        super(input_array);
    }

    private void merge(int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int L[] = new int[n1];  // Creating temporary arrays
        int R[] = new int[n2];

        for (int i = 0; i < n1; ++i)  // Copying data to these arrays
            L[i] = arr[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0;   // Merge the temporary arrays back to arr[l..r]
        int k = l;
        while (i < n1 && j < n2) {
            comparison_counter++;    // Counting comparisons
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {    // Copy the remaining elements of L[], if any
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {    // Copy the remaining elements of R[], if any
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    private void sort(int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            
            sort(l, m);   // Sort first and second halves
            sort(m + 1, r);
            
            merge(l, m, r);   // Merge the sorted halves
        }
    }

    @Override
    public void sort() {
        sort(0, arr.length - 1);
    }

    @Override
    public void print() {
        System.out.print("Merge Sort\t=>\t");
        super.print();
    }
}
