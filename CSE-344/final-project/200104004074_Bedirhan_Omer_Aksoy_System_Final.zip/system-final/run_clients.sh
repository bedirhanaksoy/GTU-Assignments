#!/bin/bash

# Server details
SERVER_IP="127.0.0.1"
PORT="8078"

# Create an array of 30 usernames
USERNAMES=()
for i in $(seq 1 30); do
  USERNAMES+=("user$i")
done

echo "Launching 30 clients..."

# Launch each client in a separate gnome-terminal window
for USER in "${USERNAMES[@]}"; do
  gnome-terminal -- bash -c "
    echo -e '$USER\n' | ./chatclient $SERVER_IP $PORT;
    exec bash
  "
  sleep 0.2
done

echo "Waiting for clients to log in..."
sleep 3

echo "Sending automated commands to some clients using xdotool..."

# Send commands using xdotool
# Group 1: Users 1-10 join room1 and broadcast messages
for i in $(seq 1 10); do
  WINDOW_ID=$(xdotool search --name "chatclient" | sed -n "${i}p")
  xdotool windowfocus "$WINDOW_ID"
  xdotool type "/join room1"
  xdotool key Return
  sleep 0.1
  xdotool type "/broadcast Hello from ${USERNAMES[$((i-1))]} in room1!"
  xdotool key Return
  sleep 0.1
done

# Group 2: Users 11-20 join room2 and broadcast messages
for i in $(seq 11 20); do
  idx=$((i-1))
  WINDOW_ID=$(xdotool search --name "chatclient" | sed -n "${i}p")
  xdotool windowfocus "$WINDOW_ID"
  xdotool type "/join room2"
  xdotool key Return
  sleep 0.1
  xdotool type "/broadcast Hello from ${USERNAMES[$idx]} in room2!"
  xdotool key Return
  sleep 0.1
done

# Group 3: Users 21-30 do not join any room, but send whispers to each other
for i in $(seq 21 30); do
  idx=$((i-1))
  target_idx=$(((i-1)%10 + 1))  # Whisper target user1-10
  target_user="user$target_idx"
  WINDOW_ID=$(xdotool search --name "chatclient" | sed -n "${i}p")
  xdotool windowfocus "$WINDOW_ID"
  xdotool type "/whisper $target_user Hi $target_user, I'm ${USERNAMES[$idx]}!"
  xdotool key Return
  sleep 0.1
done

echo "Automated testing complete!"
