#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <stdarg.h>

#define COLOR_RESET   "\033[0m"
#define COLOR_RED     "\033[0;31m"
#define COLOR_GREEN   "\033[0;32m"
#define COLOR_YELLOW  "\033[0;33m"
#define COLOR_BLUE    "\033[0;34m"
#define COLOR_CYAN    "\033[0;36m"
#define COLOR_WHITE   "\033[0;37m"

#define MAX_CLIENTS 30
#define MAX_USERNAME_LEN 16
#define MAX_MESSAGE_LEN 1024
#define MAX_ROOM_NAME_LEN 32
#define MAX_ROOMS 10
#define BUFFER_SIZE 2048

#define MAX_UPLOAD_QUEUE 5
#define MAX_FILENAME_LEN 256

// Message types
#define MSG_LOGIN 1
#define MSG_WHISPER 2
#define MSG_BROADCAST 3
#define MSG_USER_LIST 4
#define MSG_ERROR 5
#define MSG_SUCCESS 6
#define MSG_JOIN_ROOM 7
#define MSG_LEAVE_ROOM 8
#define MSG_ROOM_MESSAGE 9
#define MSG_FILE_SEND 10
#define MSG_FILE_RECEIVE 11
#define MSG_FILE_QUEUE_STATUS 12

// Room structure
typedef struct {
    char name[MAX_ROOM_NAME_LEN + 1];
    int client_sockets[MAX_CLIENTS];
    int client_count;
    int active;
} room_t;

// Client structure
typedef struct {
    int socket;
    char username[MAX_USERNAME_LEN + 1];
    char current_room[MAX_ROOM_NAME_LEN + 1];
    struct sockaddr_in address;
    pthread_t thread;
    int active;
} client_t;

// Message structure
typedef struct {
    int type;
    char sender[MAX_USERNAME_LEN + 1];
    char recipient[MAX_USERNAME_LEN + 1];
    char room_name[MAX_ROOM_NAME_LEN + 1];
    char content[MAX_MESSAGE_LEN];
    int length;
} message_t;

typedef struct {
    char filename[MAX_FILENAME_LEN];
    char sender[MAX_USERNAME_LEN + 1];
    char recipient[MAX_USERNAME_LEN + 1];
    long file_size;
    char file_type[16];
    time_t queue_time;
    int processed;
} file_queue_item_t;

typedef struct {
    file_queue_item_t items[MAX_UPLOAD_QUEUE];
    int front;
    int rear;
    int count;
    pthread_mutex_t mutex;
    pthread_cond_t not_full;
    pthread_cond_t not_empty;
} file_queue_t;

// Global variables
client_t *clients[MAX_CLIENTS];
room_t rooms[MAX_ROOMS];
pthread_mutex_t clients_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t rooms_mutex = PTHREAD_MUTEX_INITIALIZER;

int client_count = 0;
int room_count = 0;
int server_socket;
volatile int server_running = 1;

file_queue_t upload_queue;
pthread_t file_processor_thread;

// Function prototypes
void *client_handler(void *arg);
int add_client(client_t *client);
void remove_client(int socket);
client_t *find_client_by_username(const char *username);
client_t *find_client_by_socket(int socket);
int send_message(int socket, message_t *msg);
int receive_message(int socket, message_t *msg);
int is_valid_username(const char *username);
int is_valid_room_name(const char *room_name);
room_t *find_room_by_name(const char *room_name);
room_t *create_room(const char *room_name);
int join_room(client_t *client, const char *room_name);
void leave_room(client_t *client);
void broadcast_to_room(const char *room_name, message_t *msg, int sender_socket);
void broadcast_user_list();
void cleanup_server();
void signal_handler(int sig);
void init_file_queue();
void *file_processor(void *arg);
void log_event(const char *format, ...);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int port = atoi(argv[1]);
    if (port <= 0 || port > 65535) {
        fprintf(stderr, "Invalid port number\n");
        exit(EXIT_FAILURE);
    }

    // Set up signal handler for graceful shutdown
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // Initialize mutexes
    if (pthread_mutex_init(&clients_mutex, NULL) != 0) {
        perror("[SERVER ERROR] Failed to initialize clients_mutex");
        log_event("[SERVER ERROR] Failed to initialize clients_mutex");
        exit(EXIT_FAILURE);
    }

    if (pthread_mutex_init(&rooms_mutex, NULL) != 0) {
        perror("[SERVER ERROR] Failed to initialize rooms_mutex");
        log_event("[SERVER ERROR] Failed to initialize rooms_mutex");
        exit(EXIT_FAILURE);
    }
    pthread_mutex_lock(&rooms_mutex);
    pthread_mutex_unlock(&rooms_mutex);

    init_file_queue();

    if (pthread_create(&file_processor_thread, NULL, file_processor, NULL) != 0) {
        perror("[SERVER ERROR] Failed to create file processor thread");
        log_event("[SERVER ERROR] Failed to create file processor thread");
        exit(EXIT_FAILURE);
    }

    // Initialize clients array
    for (int i = 0; i < MAX_CLIENTS; i++) {
        clients[i] = NULL;
    }

    // Initialize rooms
    for (int i = 0; i < MAX_ROOMS; i++) {
        memset(&rooms[i], 0, sizeof(room_t));
        rooms[i].active = 0;
    }

    // Create server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("[SERVER ERROR]Socket creation failed");
        log_event("[SERVER ERROR] Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("[SERVER ERROR] Setsockopt failed");
        log_event("[SERVER ERROR] Setsockopt failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Configure server address
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    // Bind socket
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("[SERVER ERROR] Bind failed");
        log_event("[SERVER ERROR] Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, MAX_CLIENTS) < 0) {
        perror("[SERVER ERROR] Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }


    printf(COLOR_WHITE "[" COLOR_BLUE "INFO" COLOR_WHITE "]" COLOR_RESET " Chat server started on port " COLOR_GREEN "%d" COLOR_RESET "\n", port);
    log_event("[INFO] Chat server started on port %d", port);

    printf(COLOR_WHITE "[" COLOR_BLUE "INFO" COLOR_WHITE "]" COLOR_RESET " Waiting for clients... (Max: " COLOR_GREEN "%d" COLOR_RESET ")\n", MAX_CLIENTS);    
    log_event("[INFO] Waiting for clients... (Max: %d)", MAX_CLIENTS);

    // Accept client connections
    while (server_running) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        
        int client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
        if (client_socket < 0) {
            if (server_running) {
                perror("[SERVER ERROR]Accept failed");
                log_event("[SERVER ERROR] Accept failed");
            }
            continue;
        }

        // Check if server is full
        pthread_mutex_lock(&clients_mutex);
        if (client_count >= MAX_CLIENTS) {
            pthread_mutex_unlock(&clients_mutex);
            message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Server is full", 0};
            send_message(client_socket, &error_msg);
            printf(COLOR_WHITE "[" COLOR_BLUE "INFO" COLOR_WHITE "]" COLOR_RESET " " COLOR_RED "Server is full, rejecting new client" COLOR_RESET "\n");
            log_event("[INFO] Server is full, rejecting new client");
            close(client_socket);
            continue;
        }
        pthread_mutex_unlock(&clients_mutex);

        // Create new client
        client_t *new_client = malloc(sizeof(client_t));
        if (!new_client) {
            perror("[SERVER ERROR] Memory allocation failed");
            log_event("[SERVER ERROR] Memory allocation failed for new client");
            close(client_socket);
            continue;
        }

        new_client->socket = client_socket;
        new_client->address = client_addr;
        new_client->active = 1;
        memset(new_client->username, 0, sizeof(new_client->username));
        memset(new_client->current_room, 0, sizeof(new_client->current_room));

        // Create thread for client
        if (pthread_create(&new_client->thread, NULL, client_handler, new_client) != 0) {
            perror("[SERVER ERROR] Thread creation failed");
            log_event("[SERVER ERROR] Thread creation failed for new client");
            free(new_client);
            close(client_socket);
            continue;
        }

        pthread_detach(new_client->thread);
    }

    cleanup_server();
    return 0;
}

void *client_handler(void *arg) {
    client_t *client = (client_t*)arg;
    message_t msg;
    int logged_in = 0;

    printf(COLOR_WHITE "[" COLOR_BLUE "CONNECT" COLOR_WHITE "]" COLOR_RESET " New client connected from " COLOR_GREEN "%s:%d" COLOR_RESET "\n", 
        inet_ntoa(client->address.sin_addr), ntohs(client->address.sin_port));
    log_event("[CONNECT] New client connected from %s:%d", 
              inet_ntoa(client->address.sin_addr), 
              ntohs(client->address.sin_port));

    while (client->active && server_running) {
        int recv_result = receive_message(client->socket, &msg);
        if (recv_result <= 0) {
            if (recv_result == 0) {
                printf(COLOR_WHITE "[" COLOR_BLUE "DISCONNECT" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_GREEN "%s" COLOR_RESET " disconnected gracefully\n", 
                    strlen(client->username) > 0 ? client->username : "unknown");
                log_event("[DISCONNECT] Client %s disconnected gracefully", 
                          strlen(client->username) > 0 ? client->username : "unknown");
            }
            break;
        }

        switch (msg.type) {
            case MSG_LOGIN: {
                if (logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Already logged in", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[CLIENT] Client %s attempted to log in again", 
                              client->username);
                    break;
                }

                if (!is_valid_username(msg.sender)) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Invalid username", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[FAILED LOG IN] Client attempted to log in with invalid username: %s", 
                              msg.sender);
                    break;
                }

                pthread_mutex_lock(&clients_mutex);
                if (find_client_by_username(msg.sender)) {
                    pthread_mutex_unlock(&clients_mutex);
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Username already taken", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[CLIENT] Client attempted to log in with taken username: %s", 
                              msg.sender);
                    break;
                }

                strcpy(client->username, msg.sender);
                if (add_client(client)) {
                    pthread_mutex_unlock(&clients_mutex);
                    message_t success_msg = {MSG_SUCCESS, "", "", "", "[SERVER] Login successful", 0};
                    send_message(client->socket, &success_msg);
                    logged_in = 1;
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " user '" COLOR_GREEN "%s" COLOR_RESET "' connected from " COLOR_GREEN "%s" COLOR_RESET "\n", client->username, inet_ntoa(client->address.sin_addr));
                    log_event("[LOGIN] user '%s' connected from %s", client->username, inet_ntoa(client->address.sin_addr));
                    broadcast_user_list();
                } else {
                    pthread_mutex_unlock(&clients_mutex);
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Server full", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[SERVER FULL] Failed to add client %s, server full", 
                              client->username);
                }
                break;
            }

            case MSG_WHISPER: {
                if (!logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not logged in", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[UNAUTHORIZED] Client %s attempted to send whisper without logging in", 
                              client->username);
                    break;
                }

                pthread_mutex_lock(&clients_mutex);
                client_t *recipient = find_client_by_username(msg.recipient);
                if (recipient && recipient->active) {
                    strcpy(msg.sender, client->username);
                    send_message(recipient->socket, &msg);
                    message_t success_msg = {MSG_SUCCESS, "", "", "", "[SERVER] Message sent", 0};
                    send_message(client->socket, &success_msg);
                    log_event("[WHISPER] User '%s' sent whisper to '%s': %s", 
                              client->username, msg.recipient, msg.content);
                } else {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] User not found or offline", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[WHISPER] User '%s' attempted to whisper to non-existent user '%s'", 
                              client->username, msg.recipient);
                }
                pthread_mutex_unlock(&clients_mutex);
                break;
            }

            case MSG_USER_LIST: {
                if (!logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not logged in", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[UNAUTHORIZED] Client %s attempted to get user list without logging in", 
                              client->username);
                    break;
                }

                pthread_mutex_lock(&clients_mutex);
                char user_list[MAX_MESSAGE_LEN] = "[SERVER] Online users: ";
                for (int i = 0; i < MAX_CLIENTS; i++) {
                    if (clients[i] && clients[i]->active && strlen(clients[i]->username) > 0) {
                        strcat(user_list, clients[i]->username);
                        strcat(user_list, " ");
                    }
                }
                pthread_mutex_unlock(&clients_mutex);

                message_t list_msg = {MSG_USER_LIST, "", "", "", "", 0};
                strcpy(list_msg.content, user_list);
                send_message(client->socket, &list_msg);
                printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " User '" COLOR_GREEN "%s" COLOR_RESET "' requested user list\n", client->username);
                log_event("[USER_LIST] User '%s' requested user list", client->username);
                break;
            }
            
            case MSG_JOIN_ROOM: {
                if (!logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not logged in", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[UNAUTHORIZED] Client %s attempted to join room without logging in", 
                              client->username);
                    break;
                }

                printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Processing join request for room: " COLOR_GREEN "%s" COLOR_RESET "\n", msg.room_name);
                log_event("[JOIN] User '%s' requested to join room '%s'", 
                          client->username, msg.room_name);
                if (!is_valid_room_name(msg.room_name)) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[INFO] Invalid room name", 0};
                    send_message(client->socket, &error_msg);
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " User '" COLOR_GREEN "%s" COLOR_RESET "' attempted to join room with invalid name: " COLOR_GREEN "%s" COLOR_RESET "\n", 
                           client->username, msg.room_name);
                    log_event("[JOIN] User '%s' attempted to join room with invalid name: %s", 
                              client->username, msg.room_name);
                    break;
                }

                if (join_room(client, msg.room_name)) {
                    char success_msg_content[MAX_MESSAGE_LEN];
                    snprintf(success_msg_content, sizeof(success_msg_content), 
                            "[SERVER] Joined room '%s'", msg.room_name);

                    message_t success_msg = {MSG_SUCCESS, "", "", "", "", 0};
                    strcpy(success_msg.content, success_msg_content);
                    send_message(client->socket, &success_msg);
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " User '" COLOR_GREEN "%s" COLOR_RESET "' successfully joined room '" COLOR_GREEN "%s" COLOR_RESET "'\n", 
                           client->username, msg.room_name);
                    log_event("[JOIN] User '%s' successfully joined room '%s'", 
                              client->username, msg.room_name);

                    // Notify others in the room
                    char notification[MAX_MESSAGE_LEN];
                    snprintf(notification, sizeof(notification), 
                            "[SERVER] %s joined the room", client->username);

                    message_t room_msg = {MSG_ROOM_MESSAGE, "SYSTEM", "", "", "", 0};
                    strcpy(room_msg.room_name, msg.room_name);
                    strcpy(room_msg.content, notification);
                    log_event("[BROADCAST] Broadcasting to room '%s': %s", 
                              msg.room_name, notification);
                    broadcast_to_room(msg.room_name, &room_msg, client->socket);
                } else {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Failed to join room", 0};
                    send_message(client->socket, &error_msg);
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " User '" COLOR_GREEN "%s" COLOR_RESET "' failed to join room '" COLOR_GREEN "%s" COLOR_RESET "'\n", 
                           client->username, msg.room_name);
                    log_event("[JOIN] User '%s' failed to join room '%s'", 
                              client->username, msg.room_name);
                }
                break;
            }

            case MSG_LEAVE_ROOM: {
                if (!logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not logged in", 0};
                    send_message(client->socket, &error_msg);
                    break;
                }

                if (strlen(client->current_room) == 0) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not in any room", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[LEAVE] Client %s attempted to leave room without being in one", 
                              client->username);
                    break;
                }

                char room_name[MAX_ROOM_NAME_LEN + 1];
                strcpy(room_name, client->current_room);
                
                leave_room(client);
                
                char success_msg_content[MAX_MESSAGE_LEN];
                snprintf(success_msg_content, sizeof(success_msg_content), 
                         "[SERVER] Left room '%s'", room_name);
                message_t success_msg = {MSG_SUCCESS, "", "", "", "", 0};
                strcpy(success_msg.content, success_msg_content);
                send_message(client->socket, &success_msg);
                printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " User '" COLOR_GREEN "%s" COLOR_RESET "' left room '" COLOR_GREEN "%s" COLOR_RESET "'\n", 
                       client->username, room_name);
                log_event("[LEAVE_ROOM] User '%s' left room '%s'", 
                          client->username, room_name);
                
                // Notify others in the room
                char notification[MAX_MESSAGE_LEN];
                snprintf(notification, sizeof(notification), 
                         "[SERVER] %s left the room", client->username);
                message_t room_msg = {MSG_ROOM_MESSAGE, "SYSTEM", "", "", "", 0};
                strcpy(room_msg.room_name, room_name);
                strcpy(room_msg.content, notification);
                broadcast_to_room(room_name, &room_msg, -1);
                log_event("[BROADCAST] Broadcasting to room '%s': %s", 
                          room_name, notification);
                break;
            }

            case MSG_BROADCAST: {
                if (!logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not logged in", 0};
                    send_message(client->socket, &error_msg);
                    break;
                }

                if (strlen(client->current_room) == 0) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not in any room", 0};
                    send_message(client->socket, &error_msg);
                    printf(COLOR_WHITE "[" COLOR_BLUE "COMMAND" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_RED "%s" COLOR_RESET " attempted to broadcast without being in a room\n", 
                           client->username);
                    log_event("[ERROR] Client %s attempted to broadcast without being in a room", 
                              client->username);
                    break;
                }

                strcpy(msg.sender, client->username);
                strcpy(msg.room_name, client->current_room);
                msg.type = MSG_ROOM_MESSAGE;
                
                broadcast_to_room(client->current_room, &msg, client->socket);
                message_t success_msg = {MSG_SUCCESS, "", "", "", "[SERVER] Message broadcasted", 0};
                send_message(client->socket, &success_msg);
                printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " User '" COLOR_GREEN "%s" COLOR_RESET "' broadcasted message in room '" COLOR_GREEN "%s" COLOR_RESET "': %s\n", 
                       client->username, client->current_room, msg.content);
                log_event("[BROADCAST] User '%s' broadcasted message in room '%s': %s", 
                          client->username, client->current_room, msg.content);
                break;
            }

            case MSG_FILE_SEND: {
                if (!logged_in) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Not logged in", 0};
                    send_message(client->socket, &error_msg);
                    break;
                }

                // Parse file info from content (filename|size|type)
                char filename[MAX_FILENAME_LEN];
                long file_size;
                char file_type[16];
                
                if (sscanf(msg.content, "%255[^|]|%ld|%15s", filename, &file_size, file_type) != 3) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Invalid file transfer format", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[FILE_SEND] Client %s sent invalid file transfer format", 
                              client->username);
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Invalid file transfer format from user '" COLOR_GREEN "%s" COLOR_RESET "'.\n", client->username);
                    break;
                }
                
                // Validate file size
                if (file_size > 3 * 1024 * 1024) {
                    printf(COLOR_CYAN "[FILE_SEND]" COLOR_RESET " File '" COLOR_GREEN "%s" COLOR_RESET "' from user '" COLOR_GREEN "%s" COLOR_RESET "' exceeds size limit.\n", filename, client->username);
                    message_t error_msg = {MSG_ERROR, "", "", "", "File exceeds 3MB size limit", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[FILE_SEND] Client %s attempted to send file '%s' exceeding 3MB size limit (%ld bytes)", 
                              client->username, filename, file_size);
                    break;
                }
                
                // Validate file type
                if (strcmp(file_type, "txt") != 0 && strcmp(file_type, "pdf") != 0 && 
                    strcmp(file_type, "jpg") != 0 && strcmp(file_type, "png") != 0) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] File type not supported", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[FILE_SEND] Client %s attempted to send unsupported file type '%s'", 
                              client->username, file_type);
                    printf(COLOR_CYAN "[FILE_SEND]" COLOR_RESET " Unsupported file type '" COLOR_GREEN "%s" COLOR_RESET "' from user '" COLOR_GREEN "%s" COLOR_RESET "'.\n", file_type, client->username);
                    break;
                }
                
                // Check if recipient exists
                pthread_mutex_lock(&clients_mutex);
                client_t *recipient = find_client_by_username(msg.recipient);
                pthread_mutex_unlock(&clients_mutex);
                
                if (!recipient) {
                    message_t error_msg = {MSG_ERROR, "", "", "", "[SERVER] Recipient not found", 0};
                    send_message(client->socket, &error_msg);
                    log_event("[FILE_SEND] Client %s attempted to send file to non-existent user '%s'", 
                              client->username, msg.recipient);
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Recipient '" COLOR_GREEN "%s" COLOR_RESET "' not found for file '" COLOR_GREEN "%s" COLOR_RESET "' from user '" COLOR_GREEN "%s" COLOR_RESET "'.\n",
                           msg.recipient, filename, client->username);
                    break;
                }
                
                // Try to enqueue file transfer
                if (enqueue_file_transfer(filename, client->username, msg.recipient, file_size, file_type)) {
                    message_t queue_msg = {MSG_FILE_QUEUE_STATUS, "", "", "", 
                                        "[SERVER] File added to upload queue", 0};
                    send_message(client->socket, &queue_msg);
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Client '" COLOR_GREEN "%s" COLOR_RESET "' added file '" COLOR_GREEN "%s" COLOR_RESET "' to upload queue for user '" COLOR_GREEN "%s" COLOR_RESET "'\n", 
                           client->username, filename, msg.recipient);
                    log_event("[FILE_SEND] Client %s added file '%s' to upload queue for user '%s'", 
                              client->username, filename, msg.recipient);
                }
                // If enqueue fails, error message is sent by enqueue_file_transfer function
                
                break;
            }

            case MSG_ERROR: {
                // Check for logout signal
                if (strcmp(msg.content, "LOGOUT") == 0) {
                    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_GREEN "%s" COLOR_RESET " requested logout\n", client->username);
                    log_event("[LOGOUT] Client %s requested logout", client->username);
                    client->active = 0;
                }
                break;
            }
        }
    }

    // Client disconnected
    if (strlen(client->username) > 0) {
        printf(COLOR_WHITE "[" COLOR_CYAN "DISCONNECT" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_GREEN "%s" COLOR_RESET " disconnected\n", client->username);
        log_event("[DISCONNECT] Client %s disconnected", client->username);
        // Leave room if in one
        if (strlen(client->current_room) > 0) {
            leave_room(client);
        }
    } 
    else {
        printf(COLOR_WHITE "[" COLOR_CYAN "DISCONNECT" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_GREEN "unknown" COLOR_RESET " disconnected\n");
        log_event("[DISCONNECT] Unnamed client disconnected");
    }
    
    remove_client(client->socket);
    close(client->socket);
    free(client);
    
    if (logged_in) {
        broadcast_user_list();
    }
    
    return NULL;
}

int add_client(client_t *client) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (!clients[i]) {
            clients[i] = client;
            client_count++;
            return 1;
        }
    }
    return 0;
}

void remove_client(int socket) {
    pthread_mutex_lock(&clients_mutex);
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i] && clients[i]->socket == socket) {
            clients[i] = NULL;
            client_count--;
            break;
        }
    }
    pthread_mutex_unlock(&clients_mutex);
}

client_t *find_client_by_username(const char *username) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i] && clients[i]->active && 
            strcmp(clients[i]->username, username) == 0) {
            return clients[i];
        }
    }
    return NULL;
}

client_t *find_client_by_socket(int socket) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i] && clients[i]->socket == socket) {
            return clients[i];
        }
    }
    return NULL;
}

int send_message(int socket, message_t *msg) {
    return send(socket, msg, sizeof(message_t), 0);
}

int receive_message(int socket, message_t *msg) {
    return recv(socket, msg, sizeof(message_t), 0);
}

int is_valid_username(const char *username) {
    if (!username || strlen(username) == 0 || strlen(username) > MAX_USERNAME_LEN) {
        return 0;
    }
    
    for (int i = 0; username[i]; i++) {
        if (!isalnum(username[i])) {
            return 0;
        }
    }
    return 1;
}

int is_valid_room_name(const char *room_name) {
    if (!room_name || strlen(room_name) == 0 || strlen(room_name) > MAX_ROOM_NAME_LEN) {
        return 0;
    }
    
    for (int i = 0; room_name[i]; i++) {
        if (!isalnum(room_name[i]) && room_name[i] != '_' && room_name[i] != '-') {
            return 0;
        }
    }
    return 1;
}

room_t *find_room_by_name(const char *room_name) {
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (rooms[i].active && strcmp(rooms[i].name, room_name) == 0) {
            return &rooms[i];
        }
    }
    return NULL;
}

room_t *create_room(const char *room_name) {
    log_event("[CREATE_ROOM] Creating room: %s", room_name);
    
    // Check if room already exists
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (rooms[i].active && strcmp(rooms[i].name, room_name) == 0) {
            log_event("[CREATE_ROOM] Room '%s' already exists", rooms[i].name);
            return &rooms[i]; // Already exists
        }
    }
    log_event("[CREATE_ROOM] Room '%s' does not exist, creating new room", room_name);
    
    // Create new room in first available slot
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (!rooms[i].active) {
            log_event("[CREATE_ROOM] Found empty slot for new room at index %d", i);
            strncpy(rooms[i].name, room_name, MAX_ROOM_NAME_LEN);
            log_event("[CREATE_ROOM] Room name set to: %s", rooms[i].name);
            rooms[i].name[MAX_ROOM_NAME_LEN] = '\0';
            rooms[i].client_count = 0;
            log_event("[CREATE_ROOM] Client count initialized to 0");
            memset(rooms[i].client_sockets, 0, sizeof(rooms[i].client_sockets));
            log_event("[CREATE_ROOM] Client sockets initialized to 0");
            rooms[i].active = 1;
            room_count++;

            log_event("[CREATE_ROOM] Room '%s' created", rooms[i].name);
            return &rooms[i];
        }
    }

    return NULL; // No space to create new room
}
int join_room(client_t *client, const char *room_name) {
    // Leave current room if in one
    if (strlen(client->current_room) > 0) {
        leave_room(client);
    }
    
    pthread_mutex_lock(&rooms_mutex);
    
    room_t *room = find_room_by_name(room_name);
    if (!room) {
        log_event("[JOIN_ROOM] Room cannot found... creating new room: %s", room_name);
        room = create_room(room_name); // create_room no longer locks mutex
        if (!room) {
            printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Failed to create room '" COLOR_GREEN "%s" COLOR_RESET "'\n", room_name);
            log_event("[JOIN_ROOM] Failed to create room '%s'", room_name);
            pthread_mutex_unlock(&rooms_mutex);
            return 0; // Failed to create room
        }
        printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Room '" COLOR_GREEN "%s" COLOR_RESET "' created for client " COLOR_GREEN "%s" COLOR_RESET "\n", room_name, client->username);
        log_event("[JOIN_ROOM] Room '%s' created for client %s", room_name, client->username);
    }
    
    // Add client to room
    if (room->client_count < MAX_CLIENTS) {
        room->client_sockets[room->client_count] = client->socket;
        room->client_count++;
        strcpy(client->current_room, room_name);
        printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_GREEN "%s" COLOR_RESET " joined room '" COLOR_GREEN "%s" COLOR_RESET "'\n", client->username, room_name);
        log_event("[JOIN_ROOM] Client %s joined room '%s'", client->username, room_name);
        pthread_mutex_unlock(&rooms_mutex);
        return 1;
    }
    
    pthread_mutex_unlock(&rooms_mutex);
    return 0; // Room full
}
void leave_room(client_t *client) {
    if (strlen(client->current_room) == 0) {
        return;
    }
    
    pthread_mutex_lock(&rooms_mutex);
    
    room_t *room = find_room_by_name(client->current_room);
    if (room) {
        // Remove client from room
        for (int i = 0; i < room->client_count; i++) {
            if (room->client_sockets[i] == client->socket) {
                // Shift remaining clients
                for (int j = i; j < room->client_count - 1; j++) {
                    room->client_sockets[j] = room->client_sockets[j + 1];
                }
                room->client_count--;
                break;
            }
        }
        
        printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Client " COLOR_GREEN "%s" COLOR_RESET " left room '" COLOR_GREEN "%s" COLOR_RESET "'\n", client->username, client->current_room);
        log_event("[LEAVE_ROOM] Client %s left room '%s'", 
                  client->username, client->current_room);
        // Delete room if empty
        if (room->client_count == 0) {
            log_event("[DELETE_ROOM] Room '%s' deleted (empty)", room->name);
            room->active = 0;
            memset(room->name, 0, sizeof(room->name));
            room_count--;
        }
    }
    
    memset(client->current_room, 0, sizeof(client->current_room));
    pthread_mutex_unlock(&rooms_mutex);
}

void broadcast_to_room(const char *room_name, message_t *msg, int sender_socket) {
    pthread_mutex_lock(&rooms_mutex);
    
    room_t *room = find_room_by_name(room_name);
    if (room) {
        for (int i = 0; i < room->client_count; i++) {
            if (room->client_sockets[i] != sender_socket) { // Don't send to sender
                send_message(room->client_sockets[i], msg);
            }
        }
    }
    
    pthread_mutex_unlock(&rooms_mutex);
}

void broadcast_user_list() {
    char user_list[MAX_MESSAGE_LEN] = "Online users: ";
    
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i] && clients[i]->active && strlen(clients[i]->username) > 0) {
            strcat(user_list, clients[i]->username);
            strcat(user_list, " ");
        }
    }
    
    message_t list_msg = {MSG_USER_LIST, "", "", "", "", 0};
    strcpy(list_msg.content, user_list);
    
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i] && clients[i]->active && strlen(clients[i]->username) > 0) {
            send_message(clients[i]->socket, &list_msg);
        }
    }
}

void init_file_queue() {
    upload_queue.front = 0;
    upload_queue.rear = 0;
    upload_queue.count = 0;
    
    if (pthread_mutex_init(&upload_queue.mutex, NULL) != 0) {
        perror("[ERROR] Failed to initialize file queue mutex");
        log_event("[ERROR] Failed to initialize file queue mutex");
        exit(EXIT_FAILURE);
    }
    
    if (pthread_cond_init(&upload_queue.not_full, NULL) != 0) {
        perror("[ERROR] Failed to initialize file queue condition variable");
        log_event("[ERROR] Failed to initialize file queue condition variable");
        exit(EXIT_FAILURE);
    }
    
    if (pthread_cond_init(&upload_queue.not_empty, NULL) != 0) {
        perror("[ERROR] Failed to initialize file queue condition variable");
        log_event("[ERROR] Failed to initialize file queue condition variable");
        exit(EXIT_FAILURE);
    }
    
    for (int i = 0; i < MAX_UPLOAD_QUEUE; i++) {
        upload_queue.items[i].processed = 1; // Mark as processed initially
    }
}

int check_filename_conflict(const char *filename, const char *recipient) {
    static char used_files[MAX_UPLOAD_QUEUE][MAX_FILENAME_LEN];
    static int file_count = 0;
    
    for (int i = 0; i < file_count && i < MAX_UPLOAD_QUEUE; i++) {
        if (strcmp(used_files[i], filename) == 0) {
            return 1; // Conflict found
        }
    }
    
    // Add to used files list
    if (file_count < MAX_UPLOAD_QUEUE) {
        strcpy(used_files[file_count], filename);
        file_count++;
    }
    
    return 0; // No conflict
}

void generate_unique_filename(char *original_filename, char *new_filename, int counter) {
    char *ext = strrchr(original_filename, '.');
    if (ext) {
        int base_len = ext - original_filename;
        snprintf(new_filename, MAX_FILENAME_LEN, "%.*s_%d%s", 
                base_len, original_filename, counter, ext);
    } else {
        snprintf(new_filename, MAX_FILENAME_LEN, "%s_%d", original_filename, counter);
    }
}

// Fixed enqueue_file_transfer function
int enqueue_file_transfer(const char *filename, const char *sender, 
                         const char *recipient, long file_size, const char *file_type) {
    pthread_mutex_lock(&upload_queue.mutex);
    
    // Check if queue is full
    if (upload_queue.count >= MAX_UPLOAD_QUEUE) {
        pthread_mutex_unlock(&upload_queue.mutex);  // Unlock before sending message
        
        // Notify sender about queue being full
        pthread_mutex_lock(&clients_mutex);
        client_t *sender_client = find_client_by_username(sender);
        if (sender_client) {
            message_t queue_msg = {MSG_FILE_QUEUE_STATUS, "", "", "", 
                                  "[SERVER] File upload queue is full. Please try again later.", 0};
            send_message(sender_client->socket, &queue_msg);
            printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Queue full for user '" COLOR_GREEN "%s" COLOR_RESET "', file '" COLOR_GREEN "%s" COLOR_RESET "' not added\n", 
                   sender, filename);
            log_event("[FILE] Queue full for user '%s', file '%s' not added", 
                      sender, filename);
        }
        pthread_mutex_unlock(&clients_mutex);
        
        return 0; // Queue full
    }
    
    // Add item to queue (mutex already locked)
    file_queue_item_t *item = &upload_queue.items[upload_queue.rear];
    strcpy(item->filename, filename);
    strcpy(item->sender, sender);
    strcpy(item->recipient, recipient);
    item->file_size = file_size;
    strcpy(item->file_type, file_type);
    item->queue_time = time(NULL);
    item->processed = 0;
    
    upload_queue.rear = (upload_queue.rear + 1) % MAX_UPLOAD_QUEUE;
    upload_queue.count++;
    
    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Enqueued file '" COLOR_GREEN "%s" COLOR_RESET "' from " COLOR_GREEN "%s" COLOR_RESET " to " COLOR_GREEN "%s" COLOR_RESET " (queue size: " COLOR_GREEN "%d" COLOR_RESET ")\n", 
           filename, sender, recipient, upload_queue.count);
    log_event("[FILE] Enqueued file '%s' from %s to %s (queue size: %d)", 
              filename, sender, recipient, upload_queue.count);
    
    pthread_cond_signal(&upload_queue.not_empty);
    pthread_mutex_unlock(&upload_queue.mutex);
    
    return 1; // Success
}

void *file_processor(void *arg) {
    while (server_running) {
        pthread_mutex_lock(&upload_queue.mutex);
        
        // Wait while queue is empty
        while (upload_queue.count == 0 && server_running) {
            pthread_cond_wait(&upload_queue.not_empty, &upload_queue.mutex);
        }
        
        if (!server_running) {
            pthread_mutex_unlock(&upload_queue.mutex);
            break;
        }

        // Process item from front of queue

        // Random wait time between 1 to 5 seconds before processing the file
        int rand_wait = (rand() % 5) + 1;
        sleep(rand_wait);

        file_queue_item_t *item = &upload_queue.items[upload_queue.front];
                // Calculate wait time
        
        time_t current_time = time(NULL);
        int wait_seconds = (int)(current_time - item->queue_time);
        
        printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Processing file '" COLOR_GREEN "%s" COLOR_RESET "' from " COLOR_GREEN "%s" COLOR_RESET " to " COLOR_GREEN "%s" COLOR_RESET " (waited " COLOR_GREEN "%d" COLOR_RESET " seconds)\n", 
               item->filename, item->sender, item->recipient, wait_seconds);
        log_event("[FILE] Processing file '%s' from %s to %s (waited %d seconds)", 
                  item->filename, item->sender, item->recipient, wait_seconds);
        
        // Check for filename conflicts
        char final_filename[MAX_FILENAME_LEN];
        strcpy(final_filename, item->filename);
        
        if (check_filename_conflict(item->filename, item->recipient)) {
            generate_unique_filename(item->filename, final_filename, 1);
            printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Conflict: '" COLOR_GREEN "%s" COLOR_RESET "' renamed to '" COLOR_GREEN "%s" COLOR_RESET "'\n", item->filename, final_filename);
            log_event("[FILE] Conflict: '%s' renamed to '%s'", item->filename, final_filename);
        }
        
        // Mark item as being processed before releasing queue mutex
        file_queue_item_t current_item = *item; // Copy the item data
        
        // Remove item from queue first
        item->processed = 1;
        upload_queue.front = (upload_queue.front + 1) % MAX_UPLOAD_QUEUE;
        upload_queue.count--;
        
        pthread_cond_signal(&upload_queue.not_full);
        pthread_mutex_unlock(&upload_queue.mutex);
        
        // Simulate file processing delay (now outside the queue mutex)
        usleep(500000); // 0.5 second processing time
        
        // Send notification to recipient
        pthread_mutex_lock(&clients_mutex);
        client_t *recipient_client = find_client_by_username(current_item.recipient);
        if (recipient_client && recipient_client->active) {
            message_t file_msg = {MSG_FILE_RECEIVE, "", "", "", "", 0};
            strcpy(file_msg.sender, current_item.sender);
            strcpy(file_msg.content, final_filename);
            
            log_event("[FILE] Sending MSG_FILE_RECEIVE to %s (socket %d)", 
                      current_item.recipient, recipient_client->socket);
            
            int send_result = send_message(recipient_client->socket, &file_msg);
            if (send_result > 0) {
                log_event("[FILE] File '%s' notification sent to %s successfully", 
                          final_filename, current_item.recipient);
            } else {
                printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Failed to send file notification to " COLOR_GREEN "%s" COLOR_RESET "\n", current_item.recipient);
                log_event("[FILE] Failed to send file notification to %s", current_item.recipient);
            }
        } else {
            printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " Recipient " COLOR_GREEN "%s" COLOR_RESET " not found or offline\n", current_item.recipient);
            log_event("[FILE] Recipient %s not found or offline", current_item.recipient);
        }
        pthread_mutex_unlock(&clients_mutex);
        
        // Send confirmation to sender
        pthread_mutex_lock(&clients_mutex);
        client_t *sender_client = find_client_by_username(current_item.sender);
        if (sender_client && sender_client->active) {
            char status_msg[MAX_MESSAGE_LEN];
            if (recipient_client && recipient_client->active) {
                snprintf(status_msg, sizeof(status_msg), 
                        "[SERVER] File '%s' successfully sent to %s", final_filename, current_item.recipient);
            } 
            else {
                snprintf(status_msg, sizeof(status_msg), 
                        "[SERVER] File '%s' queued (recipient %s offline)", final_filename, current_item.recipient);
            }
            
            message_t success_msg = {MSG_SUCCESS, "", "", "", "", 0};
            strcpy(success_msg.content, status_msg);
            send_message(sender_client->socket, &success_msg);
            log_event("[FILE] Sent success message to %s: %s", 
                      current_item.sender, status_msg);
        }
        pthread_mutex_unlock(&clients_mutex);
    }
    
    return NULL;
}

void cleanup_server() {
    printf(COLOR_WHITE "[" COLOR_CYAN "COMMAND" COLOR_WHITE "]" COLOR_RESET " " COLOR_GREEN "[SHUTDOWN]" COLOR_RESET " Shutting down server...\n");
    log_event("[SHUTDOWN] Shutting down server");
    server_running = 0;
    
    // Signal file processor thread to stop
    pthread_cond_signal(&upload_queue.not_empty);
    pthread_join(file_processor_thread, NULL);
    
    // Cleanup file queue
    pthread_mutex_destroy(&upload_queue.mutex);
    pthread_cond_destroy(&upload_queue.not_full);
    pthread_cond_destroy(&upload_queue.not_empty);
    
    pthread_mutex_lock(&clients_mutex);
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i]) {
            clients[i]->active = 0;
            close(clients[i]->socket);
        }
    }
    pthread_mutex_unlock(&clients_mutex);
    
    close(server_socket);
    pthread_mutex_destroy(&clients_mutex);
    pthread_mutex_destroy(&rooms_mutex);
}
void signal_handler(int sig) {
    cleanup_server();
    exit(0);
}

void log_event(const char *format, ...) {
    FILE *log_file = fopen("server.log", "a");
    if (!log_file) return;

    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    char timestamp[20]; // "YYYY-MM-DD HH:MM:SS"
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", tm_info);

    fprintf(log_file, "%s - ", timestamp);

    va_list args;
    va_start(args, format);
    vfprintf(log_file, format, args);
    va_end(args);

    fprintf(log_file, "\n");
    fclose(log_file);
}
