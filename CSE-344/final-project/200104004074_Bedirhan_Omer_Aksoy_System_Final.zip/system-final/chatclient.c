#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/select.h>

#define COLOR_RESET   "\033[0m"
#define COLOR_RED     "\033[0;31m"
#define COLOR_GREEN   "\033[0;32m"
#define COLOR_YELLOW  "\033[0;33m"
#define COLOR_BLUE    "\033[0;34m"
#define COLOR_CYAN    "\033[0;36m"
#define COLOR_WHITE   "\033[0;37m"

#define MAX_USERNAME_LEN 16
#define MAX_MESSAGE_LEN 1024
#define MAX_ROOM_NAME_LEN 32
#define BUFFER_SIZE 2048
#define MSG_FILE_SEND 10
#define MSG_FILE_RECEIVE 11
#define MSG_FILE_QUEUE_STATUS 12

// Message types
#define MSG_LOGIN 1
#define MSG_WHISPER 2
#define MSG_BROADCAST 3
#define MSG_USER_LIST 4
#define MSG_ERROR 5
#define MSG_SUCCESS 6
#define MSG_JOIN_ROOM 7
#define MSG_LEAVE_ROOM 8
#define MSG_ROOM_MESSAGE 9

// Message structure
typedef struct {
    int type;
    char sender[MAX_USERNAME_LEN + 1];
    char recipient[MAX_USERNAME_LEN + 1];
    char room_name[MAX_ROOM_NAME_LEN + 1];
    char content[MAX_MESSAGE_LEN];
    int length;
} message_t;

typedef struct {
    char filename[256];
    char sender[MAX_USERNAME_LEN + 1];
    char recipient[MAX_USERNAME_LEN + 1];
    long file_size;
    char file_type[16];
} file_transfer_t;

// Global variables
int client_socket = -1;
volatile int client_running = 1;
char username[MAX_USERNAME_LEN + 1];
char current_room[MAX_ROOM_NAME_LEN + 1];
int logged_in = 0;
pthread_mutex_t output_mutex = PTHREAD_MUTEX_INITIALIZER;

// Function prototypes
void *message_receiver(void *arg);
int send_message(message_t *msg);
int receive_message(message_t *msg);
void print_menu();
void handle_whisper_command(char *input);
void handle_join_command(char *input);
void handle_broadcast_command(char *input);
void handle_sendfile_command(char *input);
void cleanup_client();
void signal_handler(int sig);

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <server_ip> <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *server_ip = argv[1];
    int port = atoi(argv[2]);
    
    if (port <= 0 || port > 65535) {
        fprintf(stderr, "Invalid port number\n");
        exit(EXIT_FAILURE);
    }

    // Set up signal handler
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // Create socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    
    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    // Connect to server
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server %s:%d\n", server_ip, port);

    // Initialize current room
    memset(current_room, 0, sizeof(current_room));

    // Get username from user
    printf("Enter username (max %d chars, alphanumeric only): ", MAX_USERNAME_LEN);
    fflush(stdout);
    
    if (!fgets(username, sizeof(username), stdin)) {
        fprintf(stderr, "Failed to read username\n");
        cleanup_client();
        exit(EXIT_FAILURE);
    }
    
    // Remove newline
    username[strcspn(username, "\n")] = 0;

    // Send login message
    message_t login_msg = {MSG_LOGIN, "", "", "", "", 0};
    strcpy(login_msg.sender, username);
    
    if (send_message(&login_msg) <= 0) {
        fprintf(stderr, COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Failed to send login message\n");
        cleanup_client();
        exit(EXIT_FAILURE);
    }

    // Wait for login response
    message_t response;
    if (receive_message(&response) <= 0) {
        fprintf(stderr, "[CLIENT]: Failed to receive login response\n");
        cleanup_client();
        exit(EXIT_FAILURE);
    }

    if (response.type == MSG_ERROR) {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": Login failed: " COLOR_GREEN "%s" COLOR_WHITE "\n", response.content);
        cleanup_client();
        exit(EXIT_FAILURE);
    } else if (response.type == MSG_SUCCESS) {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": Login successful! Welcome, " COLOR_GREEN "%s" COLOR_WHITE "\n", username);
        logged_in = 1;
    }

    // Create receiver thread
    pthread_t receiver_thread;
    if (pthread_create(&receiver_thread, NULL, message_receiver, NULL) != 0) {
        perror("[CLIENT]: Failed to create receiver thread");
        cleanup_client();
        exit(EXIT_FAILURE);
    }

    // Main command loop
    print_menu();
    char input[BUFFER_SIZE];
    
    while (client_running && logged_in) {
        printf("\n> ");
        fflush(stdout);
        
        if (!fgets(input, sizeof(input), stdin)) {
            break;
        }
        
        // Remove newline
        input[strcspn(input, "\n")] = 0;
        
        if (strlen(input) == 0) {
            continue;
        }
        
        if (strcmp(input, "/quit") == 0 || strcmp(input, "/exit") == 0) {
            printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Disconnecting...\n");
            break;
        } else if (strcmp(input, "/help") == 0) {
            print_menu();
        } else if (strcmp(input, "/users") == 0) {
            message_t list_msg = {MSG_USER_LIST, "", "", "", "", 0};
            send_message(&list_msg);
        } else if (strncmp(input, "/whisper ", 9) == 0) {
            handle_whisper_command(input);
        } else if (strncmp(input, "/join ", 6) == 0) {
            handle_join_command(input);
        } else if (strcmp(input, "/leave") == 0) {
            message_t leave_msg = {MSG_LEAVE_ROOM, "", "", "", "", 0};
            strcpy(leave_msg.sender, username);
            send_message(&leave_msg);
        } else if (strncmp(input, "/broadcast ", 11) == 0) {
            handle_broadcast_command(input);
        } else if (strncmp(input, "/sendfile ", 10) == 0) {
            handle_sendfile_command(input);
        } else {
            printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Unknown command. Type /help for available commands.\n");
        }
    }

    client_running = 0;
    
    // Send a logout message to server (optional)
    message_t logout_msg = {MSG_ERROR, "", "", "", "LOGOUT", 0}; 
    strcpy(logout_msg.sender, username);
    send_message(&logout_msg);
    
    // Give receiver thread a moment to finish
    usleep(100000); // 100ms
    
    pthread_join(receiver_thread, NULL);
    cleanup_client();
    
    return 0;
}

void *message_receiver(void *arg) {
    message_t msg;
    fd_set readfds;
    struct timeval timeout;
    
    while (client_running) {
        // Use select with timeout to avoid blocking indefinitely
        FD_ZERO(&readfds);
        FD_SET(client_socket, &readfds);
        
        timeout.tv_sec = 1;  // 1 second timeout
        timeout.tv_usec = 0;
        
        int activity = select(client_socket + 1, &readfds, NULL, NULL, &timeout);
        
        if (activity < 0 && errno != EINTR) {
            if (client_running) {
                pthread_mutex_lock(&output_mutex);
                printf("\n" COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Select error\n");
                pthread_mutex_unlock(&output_mutex);
            }
            break;
        }
        
        if (activity == 0) {
            // Timeout - check if we should continue running
            continue;
        }
        
        if (FD_ISSET(client_socket, &readfds)) {
            int result = receive_message(&msg);
            if (result <= 0) {
                if (client_running) {
                    pthread_mutex_lock(&output_mutex);
                    if (result == 0) {
                        printf("\n" COLOR_GREEN "[SERVER]" COLOR_WHITE ": Server disconnected\n");
                    } else {
                        printf("\n" COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Connection lost to server\n");
                    }
                    pthread_mutex_unlock(&output_mutex);
                }
                break;
            }
            
            pthread_mutex_lock(&output_mutex);
            
            switch (msg.type) {
                case MSG_WHISPER:
                    printf("\n" COLOR_WHITE "[" COLOR_CYAN "SERVER" COLOR_WHITE "]:" COLOR_WHITE "[" COLOR_CYAN "whisper from %s" COLOR_WHITE "]: %s\n> ", msg.sender, msg.content);
                    break;
                    
                case MSG_ROOM_MESSAGE:
                    if (strcmp(msg.sender, "SYSTEM") == 0) {
                        printf("\n" COLOR_RED "[%s] %s" COLOR_WHITE "\n> ", msg.room_name, msg.content); // System room messages
                    } else {
                        printf("\n" COLOR_RED "[%s] %s: %s" COLOR_WHITE "\n> ", msg.room_name, msg.sender, msg.content); // User room messages
                    }
                    break;
                    
                case MSG_USER_LIST:
                    printf("\n%s\n> ", msg.content);
                    break;
                    
                case MSG_ERROR:
                    printf("\n" COLOR_GREEN "[SERVER]" COLOR_WHITE ": Error: %s\n> ", msg.content);
                    break;
                                    
                case MSG_SUCCESS:
                    printf("\n%s\n> ", msg.content);


                    // Update current room if joining
                    if (strncmp(msg.content, "[SERVER] Joined room '", 13) == 0) {
                        char *room_start = msg.content + 22;
                        char *room_end = strchr(room_start, '\'');
                        if (room_end) {
                            int room_len = room_end - room_start;
                            if (room_len <= MAX_ROOM_NAME_LEN) {
                                strncpy(current_room, room_start, room_len);
                                current_room[room_len] = '\0';
                            }
                        } 
                        else {
                            printf("[CLIENT]: Invalid room name format in success message\n");
                        }
                    } else if (strncmp(msg.content, "Left room '", 11) == 0) {
                        memset(current_room, 0, sizeof(current_room));
                    }
                    break;
                case MSG_FILE_RECEIVE:
                    printf("\n" COLOR_WHITE "[" COLOR_CYAN "FILE" COLOR_WHITE "] Received file '" COLOR_GREEN "%s" COLOR_WHITE "' from " COLOR_GREEN "%s\n> ", msg.content, msg.sender);
                    break;
                    
                case MSG_FILE_QUEUE_STATUS:
                    printf("\n" COLOR_WHITE "[" COLOR_CYAN "QUEUE" COLOR_WHITE "] %s\n> ", msg.content);
                    break;
                    
                default:
                    printf("\nReceived unknown message type\n> ");
                    break;
            }
            
            fflush(stdout);
            pthread_mutex_unlock(&output_mutex);
        }
    }
    
    return NULL;
}

int send_message(message_t *msg) {
    return send(client_socket, msg, sizeof(message_t), 0);
}

int receive_message(message_t *msg) {
    return recv(client_socket, msg, sizeof(message_t), 0);
}

void print_menu() {
    printf("\n" COLOR_YELLOW "=== Chat Client Commands ===\n");
    printf("/whisper <username> <message> - Send private message\n");
    printf("/join <room_name>             - Join or create a room\n");
    printf("/leave                        - Leave current room\n");
    printf("/broadcast <message>          - Send message to everyone in current room\n");
    printf("/sendfile <filename> <username> - Send file to user\n");
    printf("/users                        - List online users\n");
    printf("/help                         - Show this menu\n");
    printf("/quit or /exit                - Quit the client" COLOR_WHITE "\n");
    if (strlen(current_room) > 0) {
        printf("Current room: %s\n", current_room);
    } else {
        printf("Current room: (none)\n");
    }
    printf("=============================\n");
}

void handle_whisper_command(char *input) {
    char *token = strtok(input + 9, " "); // Skip "/whisper "
    if (!token) {
        printf("Usage: /whisper <username> <message>\n");
        return;
    }
    
    char recipient[MAX_USERNAME_LEN + 1];
    strncpy(recipient, token, MAX_USERNAME_LEN);
    recipient[MAX_USERNAME_LEN] = '\0';
    
    char *message_content = strtok(NULL, "");
    if (!message_content) {
        printf("Usage: /whisper <username> <message>\n");
        return;
    }
    
    // Skip leading spaces
    while (*message_content == ' ') {
        message_content++;
    }
    
    if (strlen(message_content) == 0) {
        printf("Message cannot be empty\n");
        return;
    }
    
    message_t whisper_msg = {MSG_WHISPER, "", "", "", "", 0};
    strcpy(whisper_msg.sender, username);
    strcpy(whisper_msg.recipient, recipient);
    strncpy(whisper_msg.content, message_content, MAX_MESSAGE_LEN - 1);
    whisper_msg.content[MAX_MESSAGE_LEN - 1] = '\0';
    
    if (send_message(&whisper_msg) <= 0) {
        printf("Failed to send message\n");
    }
}

void handle_join_command(char *input) {
    char *room_name = input + 6; // Skip "/join "
    
    // Skip leading spaces
    while (*room_name == ' ') {
        room_name++;
    }
    
    if (strlen(room_name) == 0) {
        printf("Usage: /join <room_name>\n");
        return;
    }
    
    // Remove trailing spaces
    char *end = room_name + strlen(room_name) - 1;
    while (end > room_name && *end == ' ') {
        *end = '\0';
        end--;
    }
    
    if (strlen(room_name) > MAX_ROOM_NAME_LEN) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Room name too long (max %d characters)\n", MAX_ROOM_NAME_LEN);
        return;
    }
    
    message_t join_msg = {MSG_JOIN_ROOM, "", "", "", "", 0};
    strcpy(join_msg.sender, username);
    strcpy(join_msg.room_name, room_name);
    
    if (send_message(&join_msg) <= 0) {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": Failed to send join request\n");
    }
}

void handle_broadcast_command(char *input) {
    if (strlen(current_room) == 0) {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": You must join a room first to broadcast messages\n");
        return;
    }
    
    char *message_content = input + 11; // Skip "/broadcast "
    
    // Skip leading spaces
    while (*message_content == ' ') {
        message_content++;
    }
    
    if (strlen(message_content) == 0) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Usage: /broadcast <message>\n");
        return;
    }
    
    message_t broadcast_msg = {MSG_BROADCAST, "", "", "", "", 0};
    strcpy(broadcast_msg.sender, username);
    strcpy(broadcast_msg.room_name, current_room);
    strncpy(broadcast_msg.content, message_content, MAX_MESSAGE_LEN - 1);
    broadcast_msg.content[MAX_MESSAGE_LEN - 1] = '\0';
    
    if (send_message(&broadcast_msg) <= 0) {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": Failed to send broadcast message\n");
    }
}


// New function to handle sendfile command
void handle_sendfile_command(char *input) {
    char *token = strtok(input + 10, " "); // Skip "/sendfile "
    if (!token) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Usage: /sendfile <filename> <username>\n");
        return;
    }
    char filename[256];
    strncpy(filename, token, sizeof(filename) - 1);
    filename[sizeof(filename) - 1] = '\0';
    
    char *recipient = strtok(NULL, " ");
    if (!recipient) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": Usage: /sendfile <filename> <username>\n");
        return;
    }
    
    // Check if file exists and get its size
    FILE *file = fopen(filename, "rb");
    if (!file) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": File '" COLOR_GREEN "%s" COLOR_WHITE "' not found\n", filename);
        return;
    }
    
    // Get file size
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fclose(file);
    
    // Check file size limit (3MB)
    if (file_size > 3 * 1024 * 1024) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": File '" COLOR_GREEN "%s" COLOR_WHITE "' exceeds 3MB size limit (" COLOR_GREEN "%ld" COLOR_WHITE " bytes)\n", filename, file_size);
        return;
    }
    
    // Check file extension
    char *ext = strrchr(filename, '.');
    if (!ext || (strcmp(ext, ".txt") != 0 && strcmp(ext, ".pdf") != 0 && 
                 strcmp(ext, ".jpg") != 0 && strcmp(ext, ".png") != 0)) {
        printf(COLOR_BLUE "[CLIENT]" COLOR_WHITE ": File type not supported. Allowed types: " COLOR_CYAN ".txt, .pdf, .jpg, .png\n");
        return;
    }
    
    // Create file transfer message
    message_t file_msg = {MSG_FILE_SEND, "", "", "", "", 0};
    strcpy(file_msg.sender, username);
    strcpy(file_msg.recipient, recipient);

    // Pack file info into content
    snprintf(file_msg.content, sizeof(file_msg.content), "%s|%ld|%s", 
             filename, file_size, ext + 1);
    
    if (send_message(&file_msg) <= 0) {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": Failed to send file transfer request\n");
    } 
    else {
        printf(COLOR_GREEN "[SERVER]" COLOR_WHITE ": Sending file '" COLOR_GREEN "%s" COLOR_WHITE "' (" COLOR_GREEN "%ld" COLOR_WHITE " bytes) to " COLOR_GREEN "%s" COLOR_WHITE "...\n", filename, file_size, recipient);
    }
}
void cleanup_client() {
    client_running = 0;
    if (client_socket != -1) {
        shutdown(client_socket, SHUT_RDWR);
        close(client_socket);
        client_socket = -1;
    }
    pthread_mutex_destroy(&output_mutex);
}

void signal_handler(int sig) {
    printf("\n[SHUTDOWN] Shutting down client...\n");
    client_running = 0;
    cleanup_client();
    exit(0);
}