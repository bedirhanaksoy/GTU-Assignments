/* teller.c */
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "utils.h"

void teller_function(void *arg) {
    ClientRequest req = *(ClientRequest*)arg;
    SharedMemory *shm = get_shared_memory();
    sem_t *sem = get_semaphore();
    sem_t *sem_request = get_request_semaphore();

    sem_wait(sem_request);

    sem_wait(sem);
    shm->request = req;
    shm->request_ready = 1;
    sem_post(sem);

    exit(0);
}
