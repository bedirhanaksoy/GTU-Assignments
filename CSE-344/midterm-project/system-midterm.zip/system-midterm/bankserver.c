#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include "utils.h"

#define SERVER_FIFO "/tmp/ServerFIFO"

volatile sig_atomic_t keep_running = 1;

#define MAX_LOG_ENTRIES 100
LogEntry log_entries[MAX_LOG_ENTRIES];
int num_logs = 0;

void sigint_handler(int sig) {
    keep_running = 0;
}

void load_existing_accounts(BankDatabase *db) {
    FILE *fp = fopen("AdaBank.bankLog", "r");
    if (!fp) {
        printf("No previous logs.. Creating the bank database\n");
        return;
    }
    printf("Found existing AdaBank.bankLog. Loading accounts...\n");
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        if (line[0] == '#' && line[1] == ' ') {
            BankAccount acc;
            char ops[1000];
            int balance;
            sscanf(line, "# %s %[D W0-9] %d", acc.bank_id, ops, &balance);
            acc.balance = balance;
            db->accounts[db->num_accounts++] = acc;
        }
    }
    fclose(fp);
}

void add_log_operation(const char* bank_id, const char* op, int amount, int balance) {
    for (int i = 0; i < num_logs; i++) {
        if (strcmp(log_entries[i].bank_id, bank_id) == 0) {
            char entry[50];
            sprintf(entry, "%s %d ", op, amount);
            strcat(log_entries[i].operations, entry);
            log_entries[i].last_balance = balance;
            return;
        }
    }
    strcpy(log_entries[num_logs].bank_id, bank_id);
    sprintf(log_entries[num_logs].operations, "%s %d ", op, amount);
    log_entries[num_logs].last_balance = balance;
    num_logs++;
}

void write_log_file() {
    FILE *fp = fopen("AdaBank.bankLog", "w");
    if (!fp) {
        perror("log fopen");
        return;
    }
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    fprintf(fp, "# Adabank Log file updated @%02d:%02d %s %d %d\n\n",
            t->tm_hour, t->tm_min,
            (t->tm_mon == 3) ? "April" : "Month", t->tm_mday, 1900 + t->tm_year);

    for (int i = 0; i < num_logs; i++) {
        fprintf(fp, "# %s %s %d\n",
                log_entries[i].bank_id,
                log_entries[i].operations,
                log_entries[i].last_balance);
    }
    fprintf(fp, "\n## end of log.\n");
    fclose(fp);
}

int main() {
    int server_fd;
    SharedMemory *shm;
    sem_t *sem;
    sem_t *sem_request;
    BankDatabase *db;

    signal(SIGINT, sigint_handler);

    printf("> BankServer AdaBank #%s\n", SERVER_FIFO);
    unlink(SERVER_FIFO);
    mkfifo(SERVER_FIFO, 0666);

    shm_unlink("/bank_shm");
    sem_unlink("/bank_sem");
    sem_unlink("/bank_request_sem");

    shm = init_shared_memory();
    sem = init_semaphore();
    sem_request = init_request_semaphore();
    db = init_database();

    load_existing_accounts(db);

    server_fd = open(SERVER_FIFO, O_RDONLY);

    printf("Adabank is active…\nWaiting for clients @%s…\n", SERVER_FIFO);

    while (keep_running) {
        ClientRequest req;
        if (read(server_fd, &req, sizeof(req)) > 0) {
            printf("- Received client from %s\n", req.client_fifo);

            pid_t pid = Teller((void*)teller_function, (void*)&req);
            printf("-- Teller %d is active serving %s…\n", pid, req.client_fifo);
            waitTeller(pid, NULL);

            while (shm->request_ready == 0)
                usleep(1000);

            sem_wait(sem);
            int result = 0;
            if (strcmp(shm->request.operation, "deposit") == 0) {
                result = deposit(shm->request.bank_id, shm->request.amount);
                if (result == 2) {
                    add_log_operation(db->accounts[db->num_accounts - 1].bank_id, "D", shm->request.amount, db->accounts[db->num_accounts - 1].balance);
                    printf("%s deposited %d credits… updating log\n", shm->request.bank_id, shm->request.amount);
                } else if (result == 1) {
                    printf("%s deposited %d credits updating log\n", shm->request.bank_id, shm->request.amount);
                }
            } else if (strcmp(shm->request.operation, "withdraw") == 0) {
                result = withdraw(shm->request.bank_id, shm->request.amount);
                if (result == 1) {
                    printf("%s withdraws %d credits… updating log\n", shm->request.bank_id, shm->request.amount);
                } else {
                    printf("%s withdraws %d credits.. operation not permitted.\n", shm->request.bank_id, shm->request.amount);
                }
            }
            sem_post(sem);

            int client_fd = open(shm->request.client_fifo, O_WRONLY);
            if (client_fd != -1) {
                char response[256];
                if (result == 2) {
                    sprintf(response, "Deposit successful BankID_%02d", db->num_accounts - 1);
                } else if (result == 1) {
                    sprintf(response, "%s successful", shm->request.operation);
                } else {
                    sprintf(response, "%s failed", shm->request.operation);
                }
                write(client_fd, response, strlen(response) + 1);
                close(client_fd);
            }

            shm->request_ready = 0;
            sem_post(sem_request);
        }
    }

    printf("Signal received closing active Tellers\n");
    printf("Removing ServerFIFO… Updating log file…\n");
    write_log_file();
    printf("Adabank says “Bye”…\n");

    close(server_fd);
    unlink(SERVER_FIFO);
    cleanup_resources();
    return 0;
}
