/* utils.c */
#include "utils.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/wait.h>

static SharedMemory *shm = NULL;
static sem_t *sem = NULL;
static sem_t *sem_request = NULL;

BankDatabase* init_database() {
    return &(get_shared_memory()->db);
}

SharedMemory* init_shared_memory() {
    int fd = shm_open("/bank_shm", O_CREAT | O_RDWR, 0666);
    ftruncate(fd, sizeof(SharedMemory));
    shm = mmap(0, sizeof(SharedMemory), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    memset(shm, 0, sizeof(SharedMemory));
    return shm;
}

SharedMemory* get_shared_memory() {
    return shm;
}

sem_t* init_semaphore() {
    sem = sem_open("/bank_sem", O_CREAT, 0666, 1);
    return sem;
}

sem_t* get_semaphore() {
    return sem;
}

sem_t* init_request_semaphore() {
    sem_request = sem_open("/bank_request_sem", O_CREAT, 0666, 1);
    return sem_request;
}

sem_t* get_request_semaphore() {
    return sem_request;
}

void cleanup_resources() {
    shm_unlink("/bank_shm");
    sem_unlink("/bank_sem");
    sem_unlink("/bank_request_sem");
}

int deposit(const char* bank_id, int amount) {
    SharedMemory *shm = get_shared_memory();
    BankDatabase *db = &(shm->db);

    // Case 1: New client
    if (strcmp(bank_id, "N") == 0 || strcmp(bank_id, "BankID_None") == 0) {
        sprintf(db->accounts[db->num_accounts].bank_id, "BankID_%02d", db->num_accounts);
        db->accounts[db->num_accounts].balance = amount;
        db->num_accounts++;
        return 2; // New account created
    } 
    // Case 2: Existing client
    else {
        for (int i = 0; i < db->num_accounts; i++) {
            if (strcmp(db->accounts[i].bank_id, bank_id) == 0) {
                db->accounts[i].balance += amount;
                return 1; // Deposit successful
            }
        }
        // If bank_id not found, return failure
        return 0;
    }
}

int withdraw(const char* bank_id, int amount) {
    SharedMemory *shm = get_shared_memory();
    BankDatabase *db = &(shm->db);

    for (int i = 0; i < db->num_accounts; i++) {
        if (strcmp(db->accounts[i].bank_id, bank_id) == 0) {
            if (db->accounts[i].balance >= amount) {
                db->accounts[i].balance -= amount;
                if (db->accounts[i].balance == 0) {
                    // Remove the account (shift others to fill gap)
                    for (int j = i; j < db->num_accounts - 1; j++) {
                        db->accounts[j] = db->accounts[j + 1];
                    }
                    db->num_accounts--; // Decrease account count
                }
                return 1; // Withdraw successful
            } else {
                return 0; // Insufficient balance
            }
        }
    }
    return 0; // BankID not found
}

pid_t Teller(void* func, void* arg_func) {
    pid_t pid = fork();
    if (pid == 0) {
        ((void (*)(void *))func)(arg_func);
        exit(0);
    }
    return pid;
}

int waitTeller(pid_t pid, int* status) {
    return waitpid(pid, status, 0);
}
