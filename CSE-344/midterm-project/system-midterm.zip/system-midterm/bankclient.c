#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "utils.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <client_file> <ServerFIFO>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    printf("> BankClient <%s> #%s\n", argv[1], argv[2]);

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }

    int server_fd = open(argv[2], O_WRONLY);
    if (server_fd == -1) {
        printf("Cannot connect %s...\nexiting..\n", argv[2]);
        exit(EXIT_FAILURE);
    }

    printf("Reading %s..\n", argv[1]);

    char line[256];
    char current_bank_id[50] = "N";
    int client_number = 1;

    while (fgets(line, sizeof(line), fp)) {
        ClientRequest req;
        char bank_id_from_file[50], operation[20];
        int amount;

        sscanf(line, "%s %s %d", bank_id_from_file, operation, &amount);

        if (strcmp(bank_id_from_file, "N") == 0 || strcmp(bank_id_from_file, "BankID_None") == 0) {
            strcpy(current_bank_id, "N");
        } else if (strncmp(bank_id_from_file, "BankID_", 7) == 0) {
            strcpy(current_bank_id, bank_id_from_file);
        } else {
            sprintf(current_bank_id, "BankID_%s", bank_id_from_file);
        }

        strcpy(req.bank_id, current_bank_id);
        strcpy(req.operation, operation);
        req.amount = amount;
        sprintf(req.client_fifo, "/tmp/ClientFIFO_%d", getpid());
        mkfifo(req.client_fifo, 0666);

        printf("Client%02d connected..%s %d credits\n", client_number, 
            (strcmp(operation, "deposit") == 0) ? "depositing" : "withdrawing", amount);

        write(server_fd, &req, sizeof(req));

        int client_fd = open(req.client_fifo, O_RDONLY);
        char response[256];
        read(client_fd, response, sizeof(response));

        if (strstr(response, "BankID_") != NULL) {
            printf("Client%02d operation successful.. %s\n", client_number, strstr(response, "BankID_"));
            sscanf(response, "Deposit successful BankID_%s", current_bank_id + 7);
            sprintf(current_bank_id, "BankID_%s", current_bank_id + 7);
        } else if (strstr(response, "successful") != NULL) {
            printf("Client%02d operation successful\n", client_number);
        } else {
            printf("Client%02d operation failed...\n", client_number);
        }

        close(client_fd);
        unlink(req.client_fifo);

        client_number++;
    }

    fclose(fp);
    close(server_fd);

    printf("exiting..\n");
    return 0;
}
