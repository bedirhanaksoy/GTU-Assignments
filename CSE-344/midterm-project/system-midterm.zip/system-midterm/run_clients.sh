#!/bin/bash

# run_clients.sh
# This script runs clients one after another

echo "=== Running Client01 ==="
./bankclient Client01.file /tmp/ServerFIFO
sleep 1

echo "=== Running Client02 ==="
./bankclient Client02.file /tmp/ServerFIFO
sleep 1

echo "=== Running Client03 ==="
./bankclient Client03.file /tmp/ServerFIFO
sleep 1

echo "=== All Clients Finished ==="
