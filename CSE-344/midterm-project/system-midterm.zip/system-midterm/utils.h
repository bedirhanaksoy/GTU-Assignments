/* utils.h */
#ifndef UTILS_H
#define UTILS_H

#include <semaphore.h>
#include <sys/types.h>

typedef struct {
    char bank_id[20];
    char operation[20];
    int amount;
    char client_fifo[256];
} ClientRequest;

typedef struct {
    int balance;
    char bank_id[20];
} BankAccount;

typedef struct {
    BankAccount accounts[100];
    int num_accounts;
} BankDatabase;

typedef struct {
    BankDatabase db;
    ClientRequest request;
    int request_ready;
} SharedMemory;

typedef struct {
    char bank_id[20];
    char operations[1000]; // example: D 300 W 100 D 500
    int last_balance;
} LogEntry;

BankDatabase* init_database();
SharedMemory* init_shared_memory();
SharedMemory* get_shared_memory();

sem_t* init_semaphore();
sem_t* get_semaphore();
sem_t* init_request_semaphore();
sem_t* get_request_semaphore();

void cleanup_resources();

int deposit(const char* bank_id, int amount);
int withdraw(const char* bank_id, int amount);

pid_t Teller(void* func, void* arg_func);
int waitTeller(pid_t pid, int* status);

void teller_function(void *arg);

#endif
