#!/bin/bash

# run_server.sh
# This script starts the BankServer

echo "=== Starting BankServer ==="

rm -f /tmp/ServerFIFO
rm -f /tmp/ClientFIFO_*

make

./bankserver

echo "=== BankServer exited ==="
