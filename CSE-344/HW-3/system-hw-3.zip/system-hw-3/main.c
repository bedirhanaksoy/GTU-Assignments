#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>

#define NUM_SATELLITES 5
#define NUM_ENGINEERS 3
#define MAX_TIMEOUT 2

typedef struct {
    int satellite_id;
    int priority;
} Request;

typedef struct Node {
    Request request;
    struct Node* next;
} Node;

int availableEngineers = NUM_ENGINEERS;
Node* requestQueue = NULL;
pthread_mutex_t engineerMutex;
sem_t newRequest;
sem_t requestHandled[NUM_SATELLITES];
int activeSatellites = NUM_SATELLITES;

void insertRequest(Request req) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }
    newNode->request = req;
    newNode->next = NULL;

    pthread_mutex_lock(&engineerMutex);
    // insert at head if queue is empty OR new req has lower number (higher priority)
    if (requestQueue == NULL || req.priority < requestQueue->request.priority) {
        newNode->next = requestQueue;
        requestQueue = newNode;
    } else {
        Node* current = requestQueue;
        // traverse until finding node with greater or equal priority
        while (current->next != NULL && current->next->request.priority <= req.priority) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
    pthread_mutex_unlock(&engineerMutex);
}

int popRequest(Request* req) {
    // assume engineerMutex is already locked by caller
    if (requestQueue == NULL) {
        return 0;
    }
    Node* temp = requestQueue;
    *req = temp->request;
    requestQueue = temp->next;
    free(temp);
    return 1;
}

// function to remove a request from the queue by satellite_id
void removeRequest(int satellite_id) {
    pthread_mutex_lock(&engineerMutex);
    Node* current = requestQueue;
    Node* prev = NULL;

    // traverse the queue to find the request
    while (current != NULL) {
        if (current->request.satellite_id == satellite_id) {
            // found the node to remove
            if (prev == NULL) {
                // removing the head
                requestQueue = current->next;
            } 
            else {
                // removing a non-head node
                prev->next = current->next;
            }
            free(current);
            pthread_mutex_unlock(&engineerMutex);
            return;
        }
        prev = current;
        current = current->next;
    }
    // request not found
    pthread_mutex_unlock(&engineerMutex);
}

void* satellite(void* arg) {
    int id = *(int*)arg;
    srand(time(NULL) ^ id);
    int priority = (rand() % 5) + 1;
    Request req = {id, priority};

    printf("[SATELLITE %d] requesting (priority %d)\n", id, priority);

    insertRequest(req);
    sem_post(&newRequest);

    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += MAX_TIMEOUT;
    if (sem_timedwait(&requestHandled[id], &ts) == -1) {
        printf("[TIMEOUT] Satellite %d timeout %d second.\n", id, MAX_TIMEOUT);
        // remove the request from the queue upon timeout
        removeRequest(id);
    }

    pthread_mutex_lock(&engineerMutex);
    activeSatellites--;
    pthread_mutex_unlock(&engineerMutex);

    return NULL;
}

void* engineer(void* arg) {
    int id = *(int*)arg;

    while (1) {
        sem_wait(&newRequest);

        // check if we should exit
        pthread_mutex_lock(&engineerMutex);
        if (activeSatellites == 0 && requestQueue == NULL) {
            pthread_mutex_unlock(&engineerMutex);
            break;
        }
        pthread_mutex_unlock(&engineerMutex);

        Request req;
        int gotRequest = 0;

        // try to process a request
        pthread_mutex_lock(&engineerMutex);
        if (availableEngineers > 0 && popRequest(&req)) {
            availableEngineers--;
            gotRequest = 1;
        }
        pthread_mutex_unlock(&engineerMutex);

        if (gotRequest) {
            // first post requestHandled[satellite_id] to prevent timeout for currently handled request
            sem_post(&requestHandled[req.satellite_id]);
            // then simulate handling the request
            printf("[ENGINEER %d] Handling Satellite %d (Priority %d)\n", id, req.satellite_id, req.priority);
            sleep((rand() % 10) + 1);
            printf("[ENGINEER %d] Finished Satellite %d\n", id, req.satellite_id);

            // update available engineers
            pthread_mutex_lock(&engineerMutex);
            availableEngineers++;
            if (requestQueue != NULL) {
                sem_post(&newRequest);
            }
            pthread_mutex_unlock(&engineerMutex);
        } 
        else {
            // repost newRequest to allow other engineers to try
            sem_post(&newRequest);
        }
    }

    printf("[ENGINEER %d] Exiting...\n", id);
    return NULL;
}

int main() {
    pthread_t satellite_threads[NUM_SATELLITES];
    pthread_t engineer_threads[NUM_ENGINEERS];
    int satellite_ids[NUM_SATELLITES];
    int engineer_ids[NUM_ENGINEERS];

    pthread_mutex_init(&engineerMutex, NULL);
    sem_init(&newRequest, 0, 0);
    for (int i = 0; i < NUM_SATELLITES; i++) {
        sem_init(&requestHandled[i], 0, 0);
    }

    for (int i = 0; i < NUM_ENGINEERS; i++) {
        engineer_ids[i] = i;
        pthread_create(&engineer_threads[i], NULL, engineer, &engineer_ids[i]);
    }

    for (int i = 0; i < NUM_SATELLITES; i++) {
        satellite_ids[i] = i;
        pthread_create(&satellite_threads[i], NULL, satellite, &satellite_ids[i]);
        usleep(100000);
    }

    for (int i = 0; i < NUM_SATELLITES; i++) {
        pthread_join(satellite_threads[i], NULL);
    }

    // wake engineers to check exit condition
    pthread_mutex_lock(&engineerMutex);
    if (activeSatellites == 0 && requestQueue == NULL) {
        for (int i = 0; i < NUM_ENGINEERS; i++) {
            sem_post(&newRequest);
        }
    }
    pthread_mutex_unlock(&engineerMutex);

    // join engineer threads
    for (int i = 0; i < NUM_ENGINEERS; i++) {
        pthread_join(engineer_threads[i], NULL);
    }

    pthread_mutex_destroy(&engineerMutex);
    sem_destroy(&newRequest);
    for (int i = 0; i < NUM_SATELLITES; i++) {
        sem_destroy(&requestHandled[i]);
    }

    while (requestQueue != NULL) {
        Node* temp = requestQueue;
        requestQueue = requestQueue->next;
        free(temp);
    }

    return 0;
}