#ifndef BUFFER_H
#define BUFFER_H

typedef struct buffer buffer_t;

buffer_t *buffer_init(int size);
void buffer_put(buffer_t *buffer, char *line);
char *buffer_get(buffer_t *buffer);
void buffer_signal_all(buffer_t *buffer);
void buffer_destroy(buffer_t *buffer);

#endif
