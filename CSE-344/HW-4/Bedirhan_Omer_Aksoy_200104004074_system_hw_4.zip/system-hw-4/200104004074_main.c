#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include "buffer.h"

#define MAX_LINE 1024

typedef struct {
    int id;
    char *search_term;
    int match_count;
} worker_arg_t;

buffer_t *shared_buffer;
int num_workers;
pthread_barrier_t barrier;
volatile sig_atomic_t stop = 0;

void sigint_handler(int sig) {
    (void)sig;
    stop = 1;
    buffer_signal_all(shared_buffer);
}

void *manager_thread(void *arg) {
    FILE *fp = (FILE *)arg;
    char line[MAX_LINE];

    while (!stop && fgets(line, MAX_LINE, fp)) {
        buffer_put(shared_buffer, strdup(line));
    }
    for (int i = 0; i < num_workers; i++)
        buffer_put(shared_buffer, NULL);  // EOF marker for each worker
    fclose(fp);
    return NULL;
}

void *worker_thread(void *arg) {
    worker_arg_t *warg = (worker_arg_t *)arg;
    char *line;

    while ((line = buffer_get(shared_buffer)) != NULL) {
        if (strstr(line, warg->search_term))
            warg->match_count++;
        free(line);
    }

    pthread_barrier_wait(&barrier);
    printf("Worker %d found %d matches\n", warg->id, warg->match_count);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        fprintf(stderr, "Usage: ./LogAnalyzer <buffer_size> <num_workers> <log_file> <search_term>\n");
        return EXIT_FAILURE;
    }

    int buffer_size = atoi(argv[1]);
    num_workers = atoi(argv[2]);
    char *filename = argv[3];
    char *search_term = argv[4];

    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Failed to open file");
        return EXIT_FAILURE;
    }

    signal(SIGINT, sigint_handler);
    shared_buffer = buffer_init(buffer_size);
    pthread_barrier_init(&barrier, NULL, num_workers);

    pthread_t manager;
    pthread_create(&manager, NULL, manager_thread, fp);

    pthread_t workers[num_workers];
    worker_arg_t args[num_workers];
    for (int i = 0; i < num_workers; i++) {
        args[i].id = i;
        args[i].search_term = search_term;
        args[i].match_count = 0;
        pthread_create(&workers[i], NULL, worker_thread, &args[i]);
    }

    pthread_join(manager, NULL);
    for (int i = 0; i < num_workers; i++)
        pthread_join(workers[i], NULL);

    int total = 0;
    for (int i = 0; i < num_workers; i++)
        total += args[i].match_count;

    printf("Total matches: %d\n", total);

    buffer_destroy(shared_buffer);
    pthread_barrier_destroy(&barrier);
    return EXIT_SUCCESS;
}
