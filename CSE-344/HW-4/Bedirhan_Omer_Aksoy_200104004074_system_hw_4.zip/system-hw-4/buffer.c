#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "buffer.h"

typedef struct buffer {
    char **data;
    int capacity;
    int count;
    int head;
    int tail;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} buffer_t;

buffer_t *buffer_init(int size) {
    buffer_t *buf = malloc(sizeof(buffer_t));
    buf->data = malloc(sizeof(char *) * size);
    buf->capacity = size;
    buf->count = 0;
    buf->head = 0;
    buf->tail = 0;
    pthread_mutex_init(&buf->mutex, NULL);
    pthread_cond_init(&buf->not_empty, NULL);
    pthread_cond_init(&buf->not_full, NULL);
    return buf;
}

void buffer_put(buffer_t *buf, char *line) {
    pthread_mutex_lock(&buf->mutex);
    while (buf->count == buf->capacity)
        pthread_cond_wait(&buf->not_full, &buf->mutex);

    buf->data[buf->tail] = line;
    buf->tail = (buf->tail + 1) % buf->capacity;
    buf->count++;

    pthread_cond_signal(&buf->not_empty);
    pthread_mutex_unlock(&buf->mutex);
}

char *buffer_get(buffer_t *buf) {
    pthread_mutex_lock(&buf->mutex);
    while (buf->count == 0)
        pthread_cond_wait(&buf->not_empty, &buf->mutex);

    char *line = buf->data[buf->head];
    buf->head = (buf->head + 1) % buf->capacity;
    buf->count--;

    pthread_cond_signal(&buf->not_full);
    pthread_mutex_unlock(&buf->mutex);
    return line;
}

void buffer_signal_all(buffer_t *buf) {
    pthread_mutex_lock(&buf->mutex);
    pthread_cond_broadcast(&buf->not_empty);
    pthread_cond_broadcast(&buf->not_full);
    pthread_mutex_unlock(&buf->mutex);
}

void buffer_destroy(buffer_t *buf) {
    pthread_mutex_destroy(&buf->mutex);
    pthread_cond_destroy(&buf->not_empty);
    pthread_cond_destroy(&buf->not_full);
    free(buf->data);
    free(buf);
}
