#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <dirent.h>
#include <time.h>

#define BUFFER_SIZE 1024
#define TIMESTAMP_SIZE 32

char globalOutputBuffer[BUFFER_SIZE];
char globalLogBuffer[BUFFER_SIZE];
char logFilePath[BUFFER_SIZE];  // To store the log file path

int is_space(char c) {
    return (c == ' ' || c == '\t' || c == '\n' || c == '\r');
}

void initializeLogFilePath() {
    if (getcwd(logFilePath, sizeof(logFilePath)) != NULL) {
        strcat(logFilePath, "/log.txt");  // Append /log.txt to current directory
    } else {
        write(2, "Error getting current directory\n", 32);  // Print error to stderr
    }
}

char** tokenizeString(const char* str, int* tokenCount) {
    int length = strlen(str);
    int maxTokens = 10;  // Initial size for the token array
    int tokenIndex = 0;
    char** tokens = (char**)malloc(maxTokens * sizeof(char*));
    
    int i = 0;
    while (i < length) {
        // Skip leading spaces
        while (i < length && is_space(str[i])) {
            i++;
        }

        // If we reach the end of the string, break
        if (i >= length) {
            break;
        }

        // If it's a quote, start a quoted token
        if (str[i] == '"') {
            i++;  // Skip the opening quote
            int start = i;
            // Find the closing quote
            while (i < length && str[i] != '"') {
                i++;
            }
            if (i < length) {
                // Include the quote in the token
                int tokenLength = i - start;
                tokens[tokenIndex] = (char*)malloc((tokenLength + 1) * sizeof(char));
                strncpy(tokens[tokenIndex], str + start, tokenLength);
                tokens[tokenIndex][tokenLength] = '\0';  // Null-terminate the string
                tokenIndex++;
                i++; // Skip the closing quote
            }
        } 
        else {
            // Otherwise, find the next space to separate tokens
            int start = i;
            while (i < length && !is_space(str[i]) && str[i] != '"') {
                i++;
            }
            int tokenLength = i - start;
            if (tokenIndex >= maxTokens) {
                maxTokens *= 2;  // Double the size if needed
                tokens = (char**)realloc(tokens, maxTokens * sizeof(char*));
            }
            tokens[tokenIndex] = (char*)malloc((tokenLength + 1) * sizeof(char));
            strncpy(tokens[tokenIndex], str + start, tokenLength);
            tokens[tokenIndex][tokenLength] = '\0';  // Null-terminate the string
            tokenIndex++;
        }
    }

    *tokenCount = tokenIndex;
    return tokens;
}

void getTimestamp(char* buffer, size_t buffer_size) {
    // Get the current time
    time_t now = time(NULL);
    
    // Check if time retrieval was successful
    if (now == (time_t)(-1)) {
        write(2, "Error getting time\n", 19);  // Print error to stderr
        return;
    }

    struct tm *tm_info;
    tm_info = localtime(&now);  // Convert time_t to tm struct

    // Format the time as [YYYY-MM-DD HH:MM:SS]
    strftime(buffer, buffer_size, "[%Y-%m-%d %H:%M:%S]", tm_info);
}

void writeLogEvent(const char *message) {
    memset(globalLogBuffer, 0, BUFFER_SIZE);

    char timestamp[32];
    getTimestamp(timestamp, sizeof(timestamp));

    // Copy timestamp into the globalOutputBuffer
    size_t timestamp_len = strlen(timestamp);
    if (timestamp_len < BUFFER_SIZE) {
        strncpy(globalLogBuffer, timestamp, timestamp_len);
    }

    // Append a space after the timestamp
    size_t buffer_len = strlen(globalLogBuffer);
    if (buffer_len + 1 < BUFFER_SIZE) {
        strcat(globalLogBuffer, " ");  // Add space
    }

    // Append the log message to the buffer
    size_t message_len = strlen(message);
    if (buffer_len + message_len + 1 < BUFFER_SIZE) {
        strncat(globalLogBuffer, message, message_len);
    }

    // Append newline
    buffer_len = strlen(globalLogBuffer);
    if (buffer_len + 1 < BUFFER_SIZE) {
        strcat(globalLogBuffer, "\n");
    }

    // Open the log file at the dynamically determined location
    int fd = open(logFilePath, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd < 0) return;  // Fail silently if unable to open log file

    write(fd, globalLogBuffer, strlen(globalLogBuffer));
    close(fd);
}

void writeStdout(int fd, const char *message) {
    write(fd, message, strlen(message));                            // Write to console (fd = 1) or file
}
void createFile(char* filename) {
    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    if (access(filename, F_OK) == 0) {
        strcpy(globalOutputBuffer, "File ");
        strcat(globalOutputBuffer, filename);
        strcat(globalOutputBuffer, " already exists.\n");
    } 
    else {
        int fd = open(filename, O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (fd != -1) {
            close(fd);
            strcpy(globalOutputBuffer, "File ");
            strcat(globalOutputBuffer, filename);
            strcat(globalOutputBuffer, " created successfully.\n");
        }
        else {
            strcpy(globalOutputBuffer, "Failed to create file ");
            strcat(globalOutputBuffer, filename);
            strcat(globalOutputBuffer, ".\n");
        }
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void createDir(char* directoryName) {
    struct stat stat_buf;

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    // Check if the directory exists and is a directory
    if (stat(directoryName, &stat_buf) == 0 && S_ISDIR(stat_buf.st_mode)) {
        strcpy(globalOutputBuffer, "Directory ");
        strcat(globalOutputBuffer, directoryName);
        strcat(globalOutputBuffer, " already exists.\n");
    } 
    else {
        if (mkdir(directoryName, 0777) == 0) {
            strcpy(globalOutputBuffer, "Directory ");
            strcat(globalOutputBuffer, directoryName);
            strcat(globalOutputBuffer, " created successfully.\n");
        }
        else {
            strcpy(globalOutputBuffer, "Error creating directory ");
            strcat(globalOutputBuffer, directoryName);
            strcat(globalOutputBuffer, ".\n");
        }
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void listDir(char* directoryName) {
    DIR *dir = opendir(directoryName);

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    if (dir == NULL) {
        strcpy(globalOutputBuffer, "Directory ");
        strcat(globalOutputBuffer, directoryName);
        strcat(globalOutputBuffer, " not found.\n");
    }
    else {
        struct dirent *entry;

        // Start listing the files
        strcpy(globalOutputBuffer, "Files in directory '");
        strcat(globalOutputBuffer, directoryName);
        strcat(globalOutputBuffer, "':\n");

        while ((entry = readdir(dir)) != NULL) {
            // Skip the "." and ".." entries
            if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                strcat(globalOutputBuffer, entry->d_name);
                strcat(globalOutputBuffer, "\n");
            }
        }

        // Close the directory
        closedir(dir);
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}


int has_extension(const char *filename, const char *extension) {
    size_t len_filename = strlen(filename);
    size_t len_extension = strlen(extension);

    if (len_filename >= len_extension && strcmp(filename + (len_filename - len_extension), extension) == 0) {
        return 1; // Match found
    }
    return 0;
}

void listFilesByExtension(char* directoryName, char* extension) {
    DIR *dir = opendir(directoryName);
    int isFound = 0;

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    if (dir == NULL) {
        strcpy(globalOutputBuffer, "Directory ");
        strcat(globalOutputBuffer, directoryName);
        strcat(globalOutputBuffer, " not found.\n");
    }
    else {
        struct dirent *entry;

        // Start listing the files
        strcpy(globalOutputBuffer, "Files in directory '");
        strcat(globalOutputBuffer, directoryName);
        strcat(globalOutputBuffer, "' with extension '");
        strcat(globalOutputBuffer, extension);
        strcat(globalOutputBuffer, "':\n");

        while ((entry = readdir(dir)) != NULL) {
            // Skip the "." and ".." entries
            if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                if (has_extension(entry->d_name, extension)) {
                    strcat(globalOutputBuffer, entry->d_name);
                    strcat(globalOutputBuffer, "\n");
                    isFound = 1;
                }
            }
        }

        if (!isFound) {
            strcpy(globalOutputBuffer, "No files with extension '");
            strcat(globalOutputBuffer, extension);
            strcat(globalOutputBuffer, "' found in ");
            strcat(globalOutputBuffer, directoryName);
            strcat(globalOutputBuffer, ".\n");
        }

        // Close the directory
        closedir(dir);
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void changeDirectory(char* newDirectoryName) {
    char currentWorkingDirectory[100];

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    if (getcwd(currentWorkingDirectory, sizeof(currentWorkingDirectory)) != NULL) {
        if (chdir(newDirectoryName) == 0) {
            strcpy(globalOutputBuffer, "Successfully changed directory to: ");
            strcat(globalOutputBuffer, newDirectoryName);
            strcat(globalOutputBuffer, "\n");
        } 
        else {
            strcpy(globalOutputBuffer, "Couldn't change the directory to ");
            strcat(globalOutputBuffer, newDirectoryName);
            strcat(globalOutputBuffer, ".\n");
        }
    } 
    else {
        strcpy(globalOutputBuffer, "Couldn't get current working directory or change the directory to ");
        strcat(globalOutputBuffer, newDirectoryName);
        strcat(globalOutputBuffer, ".\n");
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void readFile(char* filename) {
    int fd;
    char buffer[BUFFER_SIZE];
    ssize_t bytesRead;

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    fd = open(filename, O_RDONLY);

    if (fd == -1) {
        strcpy(globalOutputBuffer, "Error opening file ");
        strcat(globalOutputBuffer, filename);
        strcat(globalOutputBuffer, "\n");
    }
    else {
        // Read from the file and store in globalOutputBuffer
        while ((bytesRead = read(fd, buffer, BUFFER_SIZE)) > 0) {
            strncat(globalOutputBuffer, buffer, bytesRead);
        }

        strcat(globalOutputBuffer, "\n");
        // Close the file
        close(fd);
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void appendToFile(char* filename, char* dataToAppend) {
    int fd = open(filename, O_WRONLY | O_APPEND | O_CREAT, 0644);

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    if (fd == -1) {
        strcpy(globalOutputBuffer, "Cannot write to ");
        strcat(globalOutputBuffer, filename);
        strcat(globalOutputBuffer, ". File is locked or read-only.\n");
    }
    else {
        // Lock the file (Exclusive Lock - blocks others)
        if (flock(fd, LOCK_EX) == -1) {
            strcpy(globalOutputBuffer, "Error locking file ");
            strcat(globalOutputBuffer, filename);
            strcat(globalOutputBuffer, "\n");
            close(fd);
        }
        else {
            // Write data to file
            write(fd, dataToAppend, strlen(dataToAppend));

            // Unlock the file
            flock(fd, LOCK_UN);

            strcpy(globalOutputBuffer, "Data successfully appended to ");
            strcat(globalOutputBuffer, filename);
            strcat(globalOutputBuffer, ".\n");

            close(fd);
        }
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void deleteFile(char* filename) {
    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    if (access(filename, F_OK) == 0) {
        if (unlink(filename) == 0) {
            strcpy(globalOutputBuffer, "File ");
            strcat(globalOutputBuffer, filename);
            strcat(globalOutputBuffer, " deleted successfully.\n");
        }
        else {
            strcpy(globalOutputBuffer, "Failed to delete file ");
            strcat(globalOutputBuffer, filename);
            strcat(globalOutputBuffer, "...\n");
        }
    } 
    else {
        strcpy(globalOutputBuffer, "File ");
        strcat(globalOutputBuffer, filename);
        strcat(globalOutputBuffer, " not found.\n");
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void deleteDir(char* directoryName){
    struct stat stat_buf;

    // Clear global buffer before use
    memset(globalOutputBuffer, 0, BUFFER_SIZE);

    // check if the directory exists
    if (stat(directoryName, &stat_buf) == 0 && S_ISDIR(stat_buf.st_mode)) {
        // if directory exists, try to remove the directory
        if (rmdir(directoryName) == 0) {
            strcpy(globalOutputBuffer, "Directory ");
            strcat(globalOutputBuffer, directoryName);
            strcat(globalOutputBuffer, " deleted successfully.\n\n");
        }
        // if rmdir fails, it means that directory is not empty
        else{
            strcpy(globalOutputBuffer, "Directory ");
            strcat(globalOutputBuffer, directoryName);
            strcat(globalOutputBuffer, " is not empty.\n");
        }
    }
    else{
        strcpy(globalOutputBuffer, "No such directory called ");
        strcat(globalOutputBuffer, directoryName);
        strcat(globalOutputBuffer, " has been found...\n\n");
    }

    writeStdout(1, globalOutputBuffer);
    writeLogEvent(globalOutputBuffer);

    memset(globalOutputBuffer, 0, BUFFER_SIZE);
}

void executeCommand(char** commandTokens, int tokenCount){
    if(strcmp(commandTokens[0], "changeDir") == 0){
        changeDirectory(commandTokens[1]);
    }
    else{
        pid_t pid = fork();

        if (pid<0){
            memset(globalOutputBuffer, 0, BUFFER_SIZE);
            strcpy(globalOutputBuffer, "Fork failed...\n");
            writeStdout(1,globalOutputBuffer);
            memset(globalOutputBuffer, 0, BUFFER_SIZE);
            exit(0);
        }
        else if(pid == 0){
            // child process

            if(strcmp(commandTokens[0], "createFile") == 0){
                createFile(commandTokens[1]);
            }
            else if(strcmp(commandTokens[0], "createDir") == 0){
                createDir(commandTokens[1]);
            }
            else if(strcmp(commandTokens[0], "listDir") == 0){
                listDir(commandTokens[1]);
            }
            else if(strcmp(commandTokens[0], "listFilesByExtension") == 0){
                listFilesByExtension(commandTokens[1], commandTokens[2]);
            }
            else if(strcmp(commandTokens[0], "readFile") == 0){
                readFile(commandTokens[1]);
            }
            else if(strcmp(commandTokens[0], "appendToFile") == 0){
                appendToFile(commandTokens[1], commandTokens[2]);
            }
            else if(strcmp(commandTokens[0], "deleteFile") == 0){
                deleteFile(commandTokens[1]);
            }
            else if(strcmp(commandTokens[0], "deleteDir") == 0){
                deleteDir(commandTokens[1]);
            }
            else if(strcmp(commandTokens[0], "showLogs") == 0){
                readFile(logFilePath);
            }
            exit(0);
        }
        else{                                                                           // parent process
            waitpid(pid, NULL, 0);                                                      // wait for child to complete
        }

        // free the each command token char pointers that user entered
        for(int i=0; i<tokenCount; i++){
            free(commandTokens[i]);
        }
        // free the char pointer pointer
        free(commandTokens);
    }
}

int main(){

    char input[BUFFER_SIZE];                                                         // The user input command
    ssize_t bytesRead;
    char timestamp[TIMESTAMP_SIZE];                                                               // Buffer for the timestamp string
    char** inputTokens;                                                             // Tokens of the user input
    int inputTokenCount = 0;                                                        // The count of the tokens to operate with its indexes

    writeStdout(1, "\nUsage: <command> [arguments]\n\n");
    writeStdout(1, "Commands:\n");
    writeStdout(1, "createDir \"folderName\"                    -Create a new directory\n");
    writeStdout(1, "createFile \"fileName\"                     -Create a new file\n");
    writeStdout(1, "listDir \"folderName\"                      -List all files in a directory\n");
    writeStdout(1, "listFilesByExtension \"folderName\"         -List files with specific extension\n");
    writeStdout(1, "readFile \"fileName\"                       -Read a file's content\n");
    writeStdout(1, "appendToFile \"fileName\" \"new content\"     -Append content to a file\n");
    writeStdout(1, "deleteFile \"fileName\"                     -Delete a file\n");
    writeStdout(1, "deleteDir \"folderName\"                    -Delete an empty directory\n");
    writeStdout(1, "changeDir \"folderName\"                    -Changes program's working directory\n");
    writeStdout(1, "showLogs                                  -Display operation logs\n\n\n");

    while(1){
        initializeLogFilePath();

        memset(input, 0, BUFFER_SIZE);
        bytesRead = read(0, input, BUFFER_SIZE - 1);  // 0 = stdin
        input[bytesRead] = '\0';  // Null-terminate
        inputTokens = tokenizeString(input, &inputTokenCount);                 // Tokenize the user input
        if(strcmp(inputTokens[0],"exit") == 0) return 0;
        executeCommand(inputTokens, inputTokenCount);
    }

    return 0;
}