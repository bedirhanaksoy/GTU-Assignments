#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <map>
#include <stack>
#include <stdexcept>
#include <iomanip>
#include <termios.h> // For Windows getch(), use <termios.h> for Linux

class GTUC312CPU {
private:
    static const int MEMORY_SIZE = 20000;
    static const int USER_MODE_START = 1000;
    static const int KERNEL_AREA_END = 1000;
    static const int RESERVED_REGISTERS_START = 0;
    static const int RESERVED_REGISTERS_END = 20;
    
    // Memory and execution state
    std::vector<long> memory;
    std::vector<std::string> instructions;
    std::stack<long> callStack;
    bool halted;
    bool kernelMode;
    long blockedUntil; // For SYSCALL PRN blocking
    
    // Special memory locations (registers)
    enum Registers {
        PC = 0,           // Program Counter
        SP = 1,           // Stack Pointer
        SYSCALL_RESULT = 2, // System call result
        INST_COUNT = 3    // Number of instructions executed
        // Registers 4-20 are reserved for other uses
    };

public:
    GTUC312CPU() : memory(MEMORY_SIZE, 0), halted(false), kernelMode(true), blockedUntil(0) {
        // Initialize stack pointer to a safe location
        memory[SP] = MEMORY_SIZE - 1;
    }
    
    // Load program from file
    bool loadProgram(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error: Cannot open file " << filename << std::endl;
            return false;
        }
        
        std::string line;
        bool inDataSection = false;
        bool inInstructionSection = false;
        
        while (std::getline(file, line)) {
            // Remove comments
            size_t commentPos = line.find('#');
            if (commentPos != std::string::npos) {
                line = line.substr(0, commentPos);
            }
            
            // Trim whitespace
            line.erase(0, line.find_first_not_of(" \t\r\n"));
            line.erase(line.find_last_not_of(" \t\r\n") + 1);
            
            if (line.empty()) continue;
            
            if (line == "Begin Data Section") {
                inDataSection = true;
                continue;
            } else if (line == "End Data Section") {
                inDataSection = false;
                continue;
            } else if (line == "Begin Instruction Section") {
                inInstructionSection = true;
                continue;
            } else if (line == "End Instruction Section") {
                inInstructionSection = false;
                continue;
            }
            
            if (inDataSection) {
                std::istringstream iss(line);
                int address;
                long value;
                if (iss >> address >> value) {
                    if (address >= 0 && address < MEMORY_SIZE) {
                        memory[address] = value;
                    }
                }
            } else if (inInstructionSection) {
                std::istringstream iss(line);
                int index;
                if (iss >> index) {
                    // Remove the index from the line and store the rest as instruction
                    size_t spacePos = line.find(' ');
                    if (spacePos != std::string::npos) {
                        std::string instruction = line.substr(spacePos + 1);
                        // Ensure instructions vector is large enough
                        if (index >= instructions.size()) {
                            instructions.resize(index + 1);
                        }
                        instructions[index] = instruction;
                    }
                }
            }
        }
        
        file.close();
        return true;
    }
    
    // Execute one instruction
    bool execute() {
        if (halted) return false;
        
        // Check if thread is blocked
        if (blockedUntil > memory[INST_COUNT]) {
            memory[INST_COUNT]++;
            return true;
        }
        
        long pc = memory[PC];
        if (pc < 0 || pc >= instructions.size()) {
            std::cerr << "Error: Invalid program counter: " << pc << std::endl;
            halted = true;
            return false;
        }
        
        std::string instruction = instructions[pc];
        if (instruction.empty()) {
            std::cerr << "Error: Empty instruction at PC " << pc << std::endl;
            halted = true;
            return false;
        }
        
        bool result = executeInstruction(instruction);
        
        // Increment instruction count
        memory[INST_COUNT]++;
        
        return result;
    }
    
    // Check if CPU is halted
    bool isHalted() const {
        return halted;
    }
    
    // Get current memory state
    const std::vector<long>& getMemory() const {
        return memory;
    }
    
    // Get current instruction count
    long getInstructionCount() const {
        return memory[INST_COUNT];
    }
    
    // Get current PC
    long getPC() const {
        return memory[PC];
    }
    
    // Print memory contents to stderr
    void printMemory() const {
        for (int i = 0; i < MEMORY_SIZE; i++) {
            if (memory[i] != 0) { // Print non-zero values or first 256 addresses
                std::cerr << "Memory[" << std::setw(5) << i << "] = " 
                         << std::setw(10) << memory[i] << std::endl;
            }
        }
        std::cerr << std::endl;
    }
    
    // Print current state
    void printState() const {
        std::cerr << "CPU State:" << std::endl;
        std::cerr << "PC: " << memory[PC] << ", SP: " << memory[SP] 
                 << ", Instructions: " << memory[INST_COUNT] 
                 << ", Mode: " << (kernelMode ? "KERNEL" : "USER") << std::endl;
        if (memory[PC] >= 0 && memory[PC] < instructions.size()) {
            std::cerr << "Current Instruction: " << instructions[memory[PC]] << std::endl;
        }
        std::cerr << std::endl;
    }

private:
    // Check memory access permissions based on kernel/user mode
    bool checkMemoryAccess(long address, bool write) {
        if (address < 0 || address >= MEMORY_SIZE) {
            std::cerr << "Error: Memory address out of bounds: " << address << std::endl;
            halted = true;
            return false;
        }
        
        // In user mode, can only access addresses >= 1000
        if (!kernelMode && address < USER_MODE_START) {
            // Allow access to some reserved registers even in user mode
            if (address > RESERVED_REGISTERS_END) {
                std::cerr << "Error: User mode access violation at address " << address << std::endl;
                halted = true;
                return false;
            }
            // For reserved registers 0-20, allow limited access
            else if (write && (address == PC || address == INST_COUNT)) {
                std::cerr << "Error: User mode cannot write to protected register " << address << std::endl;
                halted = true;
                return false;
            }
        }
        
        return true;
    }
    
    // Helper function to check if address is a reserved register
    bool isReservedRegister(long address) {
        return (address >= RESERVED_REGISTERS_START && address <= RESERVED_REGISTERS_END);
    }
    
    bool executeInstruction(const std::string& instruction) {
        std::istringstream iss(instruction);
        std::string opcode;
        iss >> opcode;
        
        try {
            if (opcode == "SET") {
                long value, address;
                iss >> value >> address;
                if (!checkMemoryAccess(address, true)) return false;
                memory[address] = value;
                if(address == PC) {
                    memory[PC] = value;
                    return true; // immediate exit so PC won't increment here
                } else {
                    memory[address] = value;
                    memory[PC]++;
                }
                
            } else if (opcode == "CPY") {
                long addr1, addr2;
                iss >> addr1 >> addr2;
                if (!checkMemoryAccess(addr1, false) || !checkMemoryAccess(addr2, true)) return false;
                memory[addr2] = memory[addr1];
                memory[PC]++;
                
            } else if (opcode == "CPYI") {
                long addr1, addr2;
                iss >> addr1 >> addr2;
                if (!checkMemoryAccess(addr1, false)) return false;
                long indirectAddr = memory[addr1];
                if (!checkMemoryAccess(indirectAddr, false) || !checkMemoryAccess(addr2, true)) return false;
                memory[addr2] = memory[indirectAddr];
                memory[PC]++;
                
            } else if (opcode == "CPYI2") {
                long addr1, addr2;
                iss >> addr1 >> addr2;
                if (!checkMemoryAccess(addr1, false) || !checkMemoryAccess(addr2, false)) return false;
                long indirectAddr1 = memory[addr1];
                long indirectAddr2 = memory[addr2];
                if (!checkMemoryAccess(indirectAddr1, false) || !checkMemoryAccess(indirectAddr2, true)) return false;
                memory[indirectAddr2] = memory[indirectAddr1];
                memory[PC]++;
                
            } else if (opcode == "ADD") {
                long address, value;
                iss >> address >> value;
                if (!checkMemoryAccess(address, true)) return false;
                memory[address] += value;
                memory[PC]++;
                
            } else if (opcode == "ADDI") {
                long addr1, addr2;
                iss >> addr1 >> addr2;
                if (!checkMemoryAccess(addr1, true) || !checkMemoryAccess(addr2, false)) return false;
                memory[addr1] += memory[addr2];
                memory[PC]++;
                
            } else if (opcode == "SUBI") {
                long addr1, addr2;
                iss >> addr1 >> addr2;
                if (!checkMemoryAccess(addr1, false) || !checkMemoryAccess(addr2, true)) return false;
                memory[addr2] = memory[addr1] - memory[addr2];
                memory[PC]++;
                
            } else if (opcode == "JIF") {
                long address, jumpTo;
                iss >> address >> jumpTo;
                if (!checkMemoryAccess(address, false)) return false;
                if (memory[address] <= 0) {
                    memory[PC] = jumpTo;
                } else {
                    memory[PC]++;
                }
                
            } else if (opcode == "PUSH") {
                long address;
                iss >> address;
                if (!checkMemoryAccess(address, false)) return false;
                memory[memory[SP]] = memory[address];
                memory[SP]--;
                memory[PC]++;
                
            } else if (opcode == "POP") {
                long address;
                iss >> address;
                if (!checkMemoryAccess(address, true)) return false;
                memory[SP]++;
                memory[address] = memory[memory[SP]];
                memory[memory[SP]] = 0; // Clear popped value
                memory[PC]++;
                
            } else if (opcode == "CALL") {
                long jumpTo;
                iss >> jumpTo;
                // Push return address
                memory[memory[SP]] = memory[PC] + 1;
                memory[SP]--;
                memory[PC] = jumpTo;
                
            } else if (opcode == "RET") {
                memory[SP]++;
                memory[PC] = memory[memory[SP]];
                memory[memory[SP]] = 0; // Clear popped value

            } else if (opcode == "HLT") {
                halted = true;
                return false;
                
            } else if (opcode == "USER") {
                long address;
                iss >> address;
                if (!checkMemoryAccess(address, false)) return false;
                kernelMode = false;

                memory[memory[SP]] = memory[PC] + 1;  // Save return address
                memory[SP]--;   // Decrement stack pointer

                memory[PC] = memory[address];   // Jump to address in user mode
                
            } else if (opcode == "SYSCALL") {
                std::string syscallType;
                iss >> syscallType;
                
                // Switch to kernel mode for system call
                bool wasKernelMode = kernelMode;
                kernelMode = true;
                
                if (syscallType == "PRN") {
                    long address;
                    iss >> address;
                    if (!checkMemoryAccess(address, false)) return false;
                    std::cout << memory[address] << std::endl;
                    // Block thread for 100 instruction executions
                    //blockedUntil = memory[INST_COUNT] + 100;
                    memory[PC]++;
                    
                } else if (syscallType == "HLT") {
                    halted = true;
                    return false;
                    
                } else if (syscallType == "YIELD") {
                    memory[memory[SP]] = memory[PC] + 1;
                    memory[SP]--;
                    memory[PC] = 120; // Jump to yield handler part of the OS
                    std::cout << "-------------------------------------------" <<std::endl;
                    std::cout << "Yielding control to OS from thread " << memory[21] << std::endl;
                    std::cout << "-------------------------------------------" <<std::endl;
                    return true;
                }
                
                // Return to previous mode after system call
                kernelMode = wasKernelMode;
                
            } else {
                std::cerr << "Error: Unknown instruction: " << opcode << std::endl;
                halted = true;
                return false;
            }
            
        } catch (const std::exception& e) {
            std::cerr << "Error executing instruction '" << instruction << "': " << e.what() << std::endl;
            halted = true;
            return false;
        }
        
        return true;
    }
};

// Function to create a sample program file
void createSampleProgram(const std::string& filename) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Cannot create sample file " << filename << std::endl;
        return;
    }
    
    file << "#Program sample - Sum from 1 to 10" << std::endl;
    file << "Begin Data Section" << std::endl;
    file << "0 0     # program counter" << std::endl;
    file << "1 0     # stack pointer" << std::endl;
    file << "2 0" << std::endl;
    file << "3 0" << std::endl;
    file << "4 0" << std::endl;
    file << "5 0" << std::endl;
    
    // Initialize memory locations up to 255
    for (int i = 6; i <= 255; i++) {
        file << i << " 0" << std::endl;
    }
    
    file << "End Data Section" << std::endl;
    file << "Begin Instruction Section" << std::endl;
    file << "0 SET 10 50     # i = 10" << std::endl;
    file << "1 SET 0 51      # sum = 0" << std::endl;
    file << "2 ADDI 51 50    # sum = sum + i (ADDI adds memory[50] to memory[51])" << std::endl;
    file << "3 ADD 50 -1     # i = i - 1" << std::endl;
    file << "4 JIF 50 7      # Go to 7 if i <= 0" << std::endl;
    file << "5 SYSCALL PRN 51 # print the sum so far" << std::endl;
    file << "6 SET 2 0       # Set PC (address 0) to 2 to jump back to instruction 2" << std::endl;
    file << "7 HLT           # end of program, the result is in memory address 51 (sum)" << std::endl;
    file << "End Instruction Section" << std::endl;
    
    file.close();
    std::cout << "Sample program created: " << filename << std::endl;
}

void printUsage(const char* programName) {
    std::cout << "Usage: " << programName << " <filename> [-D <debug_mode>]" << std::endl;
    std::cout << "Debug modes:" << std::endl;
    std::cout << "  0: Run program, print memory after halt (default)" << std::endl;
    std::cout << "  1: Print memory after each instruction" << std::endl;
    std::cout << "  2: Print memory after each instruction, wait for keypress" << std::endl;
    std::cout << "  3: Print thread table after context switches (not implemented in basic CPU)" << std::endl;
    std::cout << std::endl;
    std::cout << "Example: " << programName << " sample.txt -D 1" << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printUsage(argv[0]);
        
        // Create a sample program for testing
        std::string sampleFile = "sample_program.txt";
        createSampleProgram(sampleFile);
        std::cout << "\nTrying to run the sample program..." << std::endl;
        
        // Run the sample program with debug mode 1
        GTUC312CPU cpu;
        if (!cpu.loadProgram(sampleFile)) {
            return 1;
        }
        
        std::cout << "Running sample program with debug mode 1:" << std::endl;
        std::cout << "==========================================" << std::endl;
        
        while (!cpu.isHalted()) {
            std::cerr << "Before instruction " << cpu.getInstructionCount() 
                     << " (PC=" << cpu.getPC() << "):" << std::endl;
            cpu.printState();
            
            bool result = cpu.execute();
            if (!result && !cpu.isHalted()) {
                std::cerr << "Execution error occurred" << std::endl;
                break;
            }
            
            std::cerr << "After instruction:" << std::endl;
            cpu.printMemory();
            std::cerr << "Press Enter to continue..." << std::endl;
            std::cin.get();
        }
        
        std::cout << "\nProgram finished. Final result should be in memory address 51." << std::endl;
        return 0;
    }
    
    std::string filename = argv[1];
    int debugMode = 0;
    
    // Parse command line arguments
    for (int i = 2; i < argc; i++) {
        if (std::string(argv[i]) == "-D" && i + 1 < argc) {
            debugMode = std::atoi(argv[i + 1]);
            i++; // Skip the next argument
        }
    }
    
    // Create and initialize CPU
    GTUC312CPU cpu;
    
    // Load program
    if (!cpu.loadProgram(filename)) {
        std::cerr << "Failed to load program from " << filename << std::endl;
        return 1;
    }
    
    std::cout << "Running program: " << filename << " with debug mode " << debugMode << std::endl;
    std::cout << "================================================================" << std::endl;
    
    // Execute based on debug mode
    switch (debugMode) {
        case 0: // Run program, print memory after halt
            while (!cpu.isHalted()) {
                bool result = cpu.execute();
                if (!result && !cpu.isHalted()) {
                    std::cerr << "Execution error occurred" << std::endl;
                    break;
                }
            }
            std::cerr << "Final memory state:" << std::endl;
            cpu.printMemory();
            break;
            
        case 1: // Print memory after each instruction
            while (!cpu.isHalted()) {
                std::cerr << "Before instruction " << cpu.getInstructionCount() 
                         << " (PC=" << cpu.getPC() << "):" << std::endl;
                cpu.printState();
                
                bool result = cpu.execute();
                if (!result && !cpu.isHalted()) {
                    std::cerr << "Execution error occurred" << std::endl;
                    break;
                }
                
                std::cerr << "Memory after instruction:" << std::endl;
                cpu.printMemory();
            }
            break;
            
        case 2: // Print memory after each instruction, wait for keypress
            while (!cpu.isHalted()) {
                std::cerr << "Before instruction " << cpu.getInstructionCount() 
                         << " (PC=" << cpu.getPC() << "):" << std::endl;
                cpu.printState();
                
                bool result = cpu.execute();
                if (!result && !cpu.isHalted()) {
                    std::cerr << "Execution error occurred" << std::endl;
                    break;
                }
                
                std::cerr << "Memory after instruction:" << std::endl;
                cpu.printMemory();
                std::cerr << "Press Enter to continue..." << std::endl;
                std::cin.get();
            }
            break;
            
        case 3: // Print thread table after context switches
            std::cerr << "Debug mode 3 (thread table) requires OS implementation" << std::endl;
            // Fall back to mode 1
            while (!cpu.isHalted()) {
                std::cerr << "Before instruction " << cpu.getInstructionCount() 
                         << " (PC=" << cpu.getPC() << "):" << std::endl;
                cpu.printState();
                
                bool result = cpu.execute();
                if (!result && !cpu.isHalted()) {
                    std::cerr << "Execution error occurred" << std::endl;
                    break;
                }
                
                std::cerr << "Memory after instruction:" << std::endl;
                cpu.printMemory();
            }
            break;
            
        default:
            std::cerr << "Invalid debug mode: " << debugMode << std::endl;
            return 1;
    }
    
    std::cout << "Program execution completed." << std::endl;
    std::cout << "Total instructions executed: " << cpu.getInstructionCount() << std::endl;
    
    return 0;
}