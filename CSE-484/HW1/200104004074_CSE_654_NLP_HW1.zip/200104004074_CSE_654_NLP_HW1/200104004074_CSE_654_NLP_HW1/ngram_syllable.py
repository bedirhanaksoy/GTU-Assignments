import math
import random
from collections import defaultdict
import re

def split_data_no_shuffle(input_file, test_file):

    with open(input_file, 'r', encoding='utf-8') as infile:
        lines = infile.readlines()

    split_index = int(len(lines) * 0.95)

    train_data = lines[:split_index]
    test_data = lines[split_index:]

    with open(input_file, 'w', encoding='utf-8') as train_outfile:
        train_outfile.writelines(train_data)

    with open(test_file, 'w', encoding='utf-8') as test_outfile:
        test_outfile.writelines(test_data)


vowels = ['a', 'e', 'ı', 'i', 'o', 'ö', 'u', 'ü']
consonants = ['b', 'c', 'ç', 'd', 'f', 'g', 'ğ', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 'ş', 't', 'v', 'y', 'z']

turkish_to_english = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU")

def clean_text(text):
    text = re.sub(r'<[^>]+>', '', text)

    text = text.translate(turkish_to_english).lower()

    text = re.sub(r'\s+', ' ', text).strip()  
    return text

def parse_syllables(word):
    syllable_count = sum(1 for char in word if char in vowels)
    syllables = []
    index = len(word) - 1

    while index >= 0:
        if word[index] in vowels:
            if index == 0:
                syllables.insert(0, word[index:])
            elif index > 0 and word[index - 1] in consonants:
                syllables.insert(0, word[index - 1:])
                word = word[:index - 1]
                index -= 1
            elif index > 0 and word[index - 1] in vowels:
                syllables.insert(0, word[index:])
                word = word[:index]
        index -= 1

    if word and syllable_count == len(syllables) and word[0] in consonants:

        if syllables:
            syllables[0] = word + syllables[0]
        else:
            syllables.append(word)
    
    return syllables

def process_file(input_filename, output_filename):
    with open(input_filename, 'r', encoding='utf-8') as infile, open(output_filename, 'w', encoding='utf-8') as outfile:
        for line in infile:

            if line.strip() == "":
                continue  

            cleaned_line = clean_text(line)
            words = cleaned_line.split()  
            syllable_output = []  
            
            for original_word in words:

                cleaned_word = re.sub(r'[^a-zA-ZğüşıİĞÇÖ]', '', original_word)
                
                if cleaned_word:
                    syllables = parse_syllables(cleaned_word)
                    parsed_syllables = " ".join(syllables)
                    syllable_output.append(parsed_syllables)  
            
            joined_output = "  ".join(syllable_output).strip()
            if joined_output:  
                outfile.write(joined_output + "\n")  


# Load train and test datasets
def load_dataset(train_file, test_file):
    with open(train_file, 'r', encoding='utf-8') as train_f:
        train_data = train_f.readlines()
    
    with open(test_file, 'r', encoding='utf-8') as test_f:
        test_data = test_f.readlines()
    
    return train_data, test_data

# generate N-Grams for given syllable-based data
def generate_ngrams(data, n):
    ngrams = defaultdict(int)
    for line in data:
        tokens = []
        i = 0
        while i < len(line):
            if line[i:i+2] == "  ":  # check for double space
                tokens.append(" ")  
                i += 2  
            elif line[i] == " ":  # skip single spaces
                i += 1
            else:

                syllable = ""
                while i < len(line) and line[i] != " ":
                    syllable += line[i]
                    i += 1
                if syllable:  # add the syllable token if it's not empty
                    tokens.append(syllable)

        # generate n-grams from the tokens list
        for i in range(len(tokens) - n + 1):
            ngram = tuple(tokens[i:i + n])
            ngrams[ngram] += 1

    return ngrams

# good-Turing smoothing
def good_turing_smoothing(ngrams):
    counts = defaultdict(int)
    smoothed_probs = {}
    total_ngrams = sum(ngrams.values())
    
    # count frequency of frequency (N_r)
    for count in ngrams.values():
        counts[count] += 1

    # good-Turing probability
    for ngram, count in ngrams.items():
        if counts[count + 1] > 0:
            smoothed_probs[ngram] = (count + 1) * (counts[count + 1] / counts[count]) / total_ngrams
        else:
            smoothed_probs[ngram] = count / total_ngrams  # default to MLE if no adjustment possible
    
    return smoothed_probs

# Save N-Grams to a file
def save_ngrams_to_file(ngrams, filename):
    
    with open(filename, 'w', encoding='utf-8') as f:
        for ngram, count in ngrams.items():
            f.write(f"{' '.join(ngram)}: {count}\n")

# Calculate perplexity on test data
def calculate_perplexity(test_data, smoothed_probs, n):
    log_prob_sum = 0
    token_count = 0
    
    for line in test_data:
        tokens = line.strip().split()
        for i in range(len(tokens) - n + 1):
            ngram = tuple(tokens[i:i + n])
            probability = smoothed_probs.get(ngram, 1e-10)  # Small probability for unseen n-grams
            log_prob_sum += math.log(probability)
            token_count += 1
    
    # Perplexity calculation
    avg_log_prob = log_prob_sum / token_count
    perplexity = math.exp(-avg_log_prob)
    return perplexity

# generate a random sentence using N-gram probabilities
def generate_random_sentence(smoothed_probs, n, sentence_length=20):
    # start with a random n-gram
    start_ngrams = [ngram for ngram in smoothed_probs if len(ngram) == n]
    
    if not start_ngrams:
        return "No starting n-grams available."
    
    current_ngram = random.choice(start_ngrams)
    sentence = list(current_ngram)
    
    for _ in range(sentence_length - n):
        # find candidates for the next word based on current n-gram
        candidates = [(ngram, prob) for ngram, prob in smoothed_probs.items() if ngram[:n-1] == current_ngram[1:]]
        
        if not candidates:
            break  # no candidates available, stop generating

        # select a random candidate based on their probabilities
        next_ngram = random.choices(
            [ngram for ngram, _ in candidates],
            weights=[prob for _, prob in candidates],
            k=1
        )[0]
        
        # append the last word of the next n-gram to the sentence
        sentence.append(next_ngram[-1])
        
        # move the current n-gram window forward
        current_ngram = next_ngram
    
    return ''.join(sentence)

# Main function to calculate N-grams, apply smoothing, compute perplexity, and generate sentences
def main(dataset_file,train_file, test_file):

    print(f"\nPreparing data...")

    process_file(dataset_file, train_file)

    split_data_no_shuffle(train_file, test_file)
    
    train_data, test_data = load_dataset(train_file, test_file)
    
    for n in range(1, 4):  # 1-gram, 2-gram, 3-gram
        print(f"\nCalculating {n}-grams...")
        
        # generate N-Grams
        ngrams = generate_ngrams(train_data, n)
        
        # save N-Grams to file
        save_ngrams_to_file(ngrams, f"syllable_ngrams_{n}.txt")
        
        # apply Good-Turing Smoothing
        smoothed_probs = good_turing_smoothing(ngrams)
        
        # calculate Perplexity
        perplexity = calculate_perplexity(test_data, smoothed_probs, n)
        print(f"{n}-gram Perplexity: {perplexity}")
        
        # generate Random Sentence
        random_sentence = generate_random_sentence(smoothed_probs, n)
        print(f"{n}-gram Random Sentence: {random_sentence}")

if __name__ == "__main__":
    main('./wiki_00','syllables.txt', 'test_data.txt')
