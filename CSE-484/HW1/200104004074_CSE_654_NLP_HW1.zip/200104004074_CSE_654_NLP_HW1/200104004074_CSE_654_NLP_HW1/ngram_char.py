import math
import random
from collections import defaultdict
import re

vowels = ['a', 'e', 'ı', 'i', 'o', 'ö', 'u', 'ü']
consonants = ['b', 'c', 'ç', 'd', 'f', 'g', 'ğ', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 'ş', 't', 'v', 'y', 'z']


turkish_to_english = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU")

def clean_text(text):

    text = re.sub(r'<[^>]+>', '', text)

    text = text.translate(turkish_to_english).lower()

    text = re.sub(r'\s+', ' ', text).strip()  
    return text

def split_data_no_shuffle(input_file, test_file, train_ratio=0.95):

    with open(input_file, 'r', encoding='utf-8') as infile:
        lines = infile.readlines()

    split_index = int(len(lines) * train_ratio)

    train_data = lines[:split_index]
    test_data = lines[split_index:]

    with open(input_file, 'w', encoding='utf-8') as train_outfile:
        train_outfile.writelines(train_data)

    with open(test_file, 'w', encoding='utf-8') as test_outfile:
        test_outfile.writelines(test_data)

def parse_characters(word):
    characters = []
    index = 0

    while index < len(word):
        char = word[index]
        if char in vowels or char in consonants:
            characters.append(char)
        index += 1

    return characters

def process_file(input_filename, output_filename):
    with open(input_filename, 'r', encoding='utf-8') as infile, open(output_filename, 'w', encoding='utf-8') as outfile:

        previous_line_empty = True
        
        for line in infile:

            cleaned_line = clean_text(line)
            

            if not cleaned_line:
                previous_line_empty = True
                continue
            
            previous_line_empty = False
            
            words = cleaned_line.split()  
            char_output = []  
            
            for original_word in words:

                cleaned_word = re.sub(r'[^a-zA-ZğüşıİĞÇÖ]', '', original_word)
                
                if cleaned_word:
                    characters = parse_characters(cleaned_word)
                    parsed_characters = " ".join(characters)
                    char_output.append(parsed_characters)  
            
            joined_output = "  ".join(char_output).strip()
            if joined_output and not previous_line_empty:  
                outfile.write(joined_output + "\n")  

def load_dataset(train_file, test_file):
    with open(train_file, 'r', encoding='utf-8') as train_f:
        train_data = train_f.readlines()
    
    with open(test_file, 'r', encoding='utf-8') as test_f:
        test_data = test_f.readlines()
    
    return train_data, test_data

def generate_char_ngrams(data, n):
    ngrams = defaultdict(int)
    for line in data:
        tokens = []
        i = 0
        while i < len(line):
            if line[i:i+2] == "  ":  
                tokens.append(" ")  
                i += 2 
            elif line[i] == " ":  
                i += 1
            else:
                tokens.append(line[i])
                i += 1

        for i in range(len(tokens) - n + 1):
            ngram = tuple(tokens[i:i + n])
            ngrams[ngram] += 1

    return ngrams

def good_turing_smoothing(ngrams):
    counts = defaultdict(int)
    smoothed_probs = {}
    total_ngrams = sum(ngrams.values())
    
    # count frequency of frequency (N_r)
    for count in ngrams.values():
        counts[count] += 1

    # good-Turing probability
    for ngram, count in ngrams.items():
        if counts[count + 1] > 0:
            smoothed_probs[ngram] = (count + 1) * (counts[count + 1] / counts[count]) / total_ngrams
        else:
            smoothed_probs[ngram] = count / total_ngrams  
    
    return smoothed_probs

def calculate_perplexity(test_data, smoothed_probs, n):
    log_prob_sum = 0
    token_count = 0
    
    for line in test_data:
        chars = line.strip().replace(" ", "") 
        for i in range(len(chars) - n + 1):
            ngram = tuple(chars[i:i + n])

            log_probability = math.log(smoothed_probs.get(ngram, 1e-10))
            log_prob_sum += log_probability
            token_count += 1
    
    avg_log_prob = log_prob_sum / token_count
    perplexity = math.exp(-avg_log_prob)
    return perplexity

def generate_random_sentence(smoothed_probs, n, sentence_length=20):
    sentence = []
    
    start_ngrams = [ngram for ngram in smoothed_probs if len(ngram) == n]
    
    if not start_ngrams:
        return ''  

    current_ngram = random.choice(start_ngrams)
    sentence.extend(current_ngram)  

    for _ in range(sentence_length - n):  

        next_candidates = []

        for ngram, prob in smoothed_probs.items():
            if ngram[:n-1] == current_ngram[1:]:
                next_candidates.append((ngram, prob))  

        # sort candidates by their probabilities in descending order and take the top 5
        top_candidates = sorted(next_candidates, key=lambda x: x[1], reverse=True)[:5]

        # if we have candidates, randomly select one based on their probabilities
        if top_candidates:
            # prepare lists for random choice based on weights
            candidate_ngrams = [ngram for ngram, _ in top_candidates]
            candidate_probs = [prob for _, prob in top_candidates]

            # randomly choose one n-gram weighted by its probability
            next_ngram = random.choices(candidate_ngrams, weights=candidate_probs, k=1)[0]
            sentence.append(next_ngram[-1])  # append the last character of the selected n-gram
            current_ngram = next_ngram  # update the current n-gram to the newly chosen one
        else:
            break  # if no candidates are available, stop generating the sentence

    # join the list of characters into a single string and return it
    return ''.join(sentence)
# save N-grams to a file
def save_ngrams_to_file(ngram_counts, filename):
    with open(filename, 'w', encoding='utf-8') as file:
        for ngram, count in ngram_counts.items():
            ngram_str = ' '.join(ngram)
            file.write(f"{ngram_str}: {count}\n")

def main(dataset_file, train_file, test_file, output_file_prefix):
    
    print(f"\nPreparing data...")

    process_file(dataset_file, train_file)

    split_data_no_shuffle(train_file, test_file)

    train_data, test_data = load_dataset(train_file, test_file)
    
    ngram_results = {}

    for n in range(1, 4):  # 1-gram, 2-gram, 3-gram
        print(f"\nCalculating {n}-grams...")
        
        # generate N-Grams
        ngrams = generate_char_ngrams(train_data, n)
        
        # save N-grams with counts to file
        save_ngrams_to_file(ngrams, f"{output_file_prefix}_{n}grams.txt")
        
        # apply Good-Turing Smoothing
        smoothed_probs = good_turing_smoothing(ngrams)
        
        # store results
        ngram_results[n] = smoothed_probs
        
        # calculate Perplexity
        perplexity = calculate_perplexity(test_data, smoothed_probs, n)
        print(f"{n}-gram Perplexity: {perplexity}")
        
        # generate Random Sentence
        print(f"{n}-gram Random Sentence: {generate_random_sentence(smoothed_probs, n)}")

# run the main function with specified files
if __name__ == "__main__":
    main('./wiki_00','chars.txt', 'test_data_chars.txt', 'ngram_output')
