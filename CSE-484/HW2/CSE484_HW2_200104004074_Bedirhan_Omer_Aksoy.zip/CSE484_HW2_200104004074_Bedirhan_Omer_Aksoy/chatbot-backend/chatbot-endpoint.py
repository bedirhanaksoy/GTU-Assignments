import torch
import json
import numpy as np
from transformers import AutoTokenizer, AutoModelForQuestionAnswering
from sentence_transformers import SentenceTransformer, util
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# ==========================
# STEP 1: Load Model and Tokenizer
# ==========================
MODEL_PATH = "./berturk_qa_finetuned"
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForQuestionAnswering.from_pretrained(MODEL_PATH).to('cuda' if torch.cuda.is_available() else 'cpu')
model.eval()

# Load Retriever Model
retriever = SentenceTransformer("paraphrase-multilingual-mpnet-base-v2")

# Load Contexts
with open("context_mapping.json", "r", encoding="utf-8") as f:
    dataset = json.load(f)

# Ensure dataset is a list of contexts
if isinstance(dataset, list) and all(isinstance(item, str) for item in dataset):
    contexts = dataset
else:
    raise ValueError("The dataset must be a list of context strings.")

# Precompute Embeddings for Contexts
context_embeddings = retriever.encode(contexts, normalize_embeddings=True)

# ==========================
# STEP 2: Context Retrieval
# ==========================
def retrieve_context(question: str, top_k=1):
    """Retrieve the most relevant context using cosine similarity."""
    question_embedding = retriever.encode(question, normalize_embeddings=True)
    similarities = util.cos_sim(question_embedding, context_embeddings)
    best_idx = similarities.argmax().item()
    return contexts[best_idx] if similarities[0, best_idx] > 0 else "No relevant context found."


# ==========================
# STEP 3: QA Inference Function
# ==========================
def ask_question(question: str) -> str:
    """Get an answer from the fine-tuned QA model given only a question."""
    context = retrieve_context(question)
    
    if context == "No relevant context found.":
        context = "Bu soruya doğrudan bir cevap verilemiyor, ancak elimden geleni yapacağım."
    
    inputs = tokenizer(
        question,
        context,
        return_tensors="pt",
        max_length=384,
        truncation="only_second",
        padding="max_length"
    ).to('cuda' if torch.cuda.is_available() else 'cpu')
    
    with torch.no_grad():
        outputs = model(**inputs)
    
    start_idx = torch.argmax(outputs.start_logits)
    end_idx = torch.argmax(outputs.end_logits) + 1
    
    input_ids = inputs["input_ids"][0]
    answer = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(input_ids[start_idx:end_idx])
    )
    
    return answer.strip()


# ==========================
# STEP 4: FastAPI for Frontend Integration
# ==========================
app = FastAPI()

# Enable CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

class QuestionRequest(BaseModel):
    question: str

@app.post('/ask')
def handle_question(request: QuestionRequest):
    if not request.question:
        raise HTTPException(status_code=400, detail='No question provided')
    
    answer = ask_question(request.question)
    return {"answer": answer}


if __name__ == "__main__":
    import uvicorn
    print("Starting QA System API (FastAPI) with Uvicorn for Frontend Integration...\n")
    uvicorn.run("test_model:app", host="0.0.0.0", port=5000, reload=True)
