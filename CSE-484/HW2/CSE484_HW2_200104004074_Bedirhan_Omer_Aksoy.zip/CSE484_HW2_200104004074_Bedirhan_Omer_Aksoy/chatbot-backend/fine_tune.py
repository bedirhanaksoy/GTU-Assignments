import json
import torch
import numpy as np
import os
import gc
import faiss
from sentence_transformers import SentenceTransformer
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from transformers import (
    AutoTokenizer,
    AutoModelForQuestionAnswering,
    TrainingArguments,
    Trainer,
    DataCollatorWithPadding
)
import evaluate


# ==========================
# STEP 1: Dataset Cleaning
# ==========================
def clean_and_fix_dataset(dataset):
    fixed_count = 0
    removed_count = 0
    cleaned_dataset = []
    
    for item in dataset:
        context = item['context']
        valid_qa_pairs = []
        
        for qa in item['qa_pairs']:
            answer = qa['answer']
            current_start = qa.get('answer_start', -1)
            true_start = context.find(answer)
            
            if true_start != -1:  # Answer found in context
                if true_start != current_start:
                    qa['answer_start'] = true_start
                    fixed_count += 1
                valid_qa_pairs.append(qa)
            else:
                removed_count += 1
                print(f"\nRemoving QA pair because answer not found in context:")
                print(f"Question: {qa['question']}")
                print(f"Answer: {answer}")
                print(f"Context: {context[:100]}...")
        
        if valid_qa_pairs:
            item['qa_pairs'] = valid_qa_pairs
            cleaned_dataset.append(item)
    
    print(f"\nSummary:")
    print(f"- Fixed {fixed_count} answer_start values")
    print(f"- Removed {removed_count} QA pairs where answer wasn't found in context")
    print(f"- Original dataset size: {len(dataset)} contexts")
    print(f"- Cleaned dataset size: {len(cleaned_dataset)} contexts")
    
    return cleaned_dataset


# ==========================
# STEP 2: Custom Dataset
# ==========================
class QADataset(Dataset):
    def __init__(self, data, tokenizer, max_length=384):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.samples = [
            (item['context'], qa['question'], qa['answer'], qa['answer_start'])
            for item in self.data for qa in item['qa_pairs']
        ]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        context, question, answer, answer_start = self.samples[idx]
        answer_end = answer_start + len(answer)
        
        encoding = self.tokenizer(
            question,
            context,
            max_length=self.max_length,
            truncation="only_second",
            padding="max_length",
            return_tensors='pt',
            return_offsets_mapping=True
        )
        
        offsets = encoding['offset_mapping'][0]
        start_token, end_token = None, None
        
        for token_idx, (start, end) in enumerate(offsets):
            if start <= answer_start < end:
                start_token = token_idx
            if start < answer_end <= end:
                end_token = token_idx
                break
        
        # Default to 0 if start or end token is not found
        start_token = start_token if start_token is not None else 0
        end_token = end_token if end_token is not None else 0

        return {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'start_positions': torch.tensor(start_token, dtype=torch.long),
            'end_positions': torch.tensor(end_token, dtype=torch.long)
        }


# ==========================
# STEP 3: Load and Clean Dataset
# ==========================
with open('formatted_dataset.json', 'r', encoding='utf-8') as f:
    raw_data = json.load(f)

cleaned_data = clean_and_fix_dataset(raw_data)

def build_faiss_index(dataset):
    """Embed contexts and build a FAISS index for retrieval."""
    print("Building FAISS index...")

    # Use a sentence transformer for embeddings
    embedder = SentenceTransformer('all-MiniLM-L6-v2')
    contexts = [item['context'] for item in dataset]
    
    # Embed contexts in batches
    context_embeddings = []
    batch_size = 128
    for i in range(0, len(contexts), batch_size):
        batch_contexts = contexts[i:i + batch_size]
        batch_embeddings = embedder.encode(batch_contexts, convert_to_tensor=True, normalize_embeddings=True)
        context_embeddings.append(batch_embeddings.cpu().numpy())
    
    context_embeddings = np.vstack(context_embeddings)
    
    # Create FAISS index
    index = faiss.IndexFlatIP(context_embeddings.shape[1])
    index.add(context_embeddings)
    
    # Save index and contexts
    faiss.write_index(index, "context_index.faiss")
    with open('context_mapping.json', 'w', encoding='utf-8') as f:
        json.dump(contexts, f, ensure_ascii=False, indent=4)
    
    print("FAISS index built and saved successfully.")

build_faiss_index(cleaned_data)

# Split into train and validation sets
train_data, val_data = train_test_split(cleaned_data, test_size=0.2, random_state=42)

# ==========================
# STEP 4: Initialize Model and Tokenizer
# ==========================
model_name = "dbmdz/bert-base-turkish-cased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForQuestionAnswering.from_pretrained(model_name)

# Create Dataset Objects
train_dataset = QADataset(train_data, tokenizer)
val_dataset = QADataset(val_data, tokenizer)

# ==========================
# STEP 5: Training Arguments
# ==========================
training_args = TrainingArguments(
    output_dir="./berturk_qa_results",
    evaluation_strategy="epoch",  # Evaluate at the end of each epoch
    save_strategy="epoch",  # Save checkpoints at each epoch
    load_best_model_at_end=True,  # Load the best model at the end of training
    learning_rate=2e-5,
    per_device_train_batch_size=16,  # Increased batch size for efficiency
    per_device_eval_batch_size=16,
    gradient_accumulation_steps=1,  # No accumulation needed with larger batch size
    num_train_epochs=3,
    weight_decay=0.01,
    logging_dir="./logs",
    logging_steps=50,
    save_total_limit=2,
    fp16=True,  # Mixed precision for faster training
    optim="adamw_torch",  # Use PyTorch-native AdamW optimizer
    dataloader_num_workers=8,  # Increase data loading workers
    report_to="none",
    logging_first_step=True
)

# ==========================
# STEP 6: Initialize Trainer
# ==========================
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:512"

data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    tokenizer=tokenizer,
    data_collator=data_collator
)
torch.cuda.empty_cache()
gc.collect()

# ==========================
# STEP 8: Train the Model
# ==========================
trainer.train()

# ==========================
# STEP 9: Evaluate the Model
# ==========================
metric = evaluate.load("squad")

# Get predictions from the model
predictions = trainer.predict(val_dataset)
start_preds = predictions.predictions[0].argmax(axis=-1)
end_preds = predictions.predictions[1].argmax(axis=-1)

formatted_predictions = []

for i, (sample, start, end) in enumerate(zip(val_dataset.samples, start_preds, end_preds)):
    context, question, answer, answer_start = sample
    
    # Tokenize again for offset mapping
    encoding = tokenizer(
        question,
        context,
        max_length=384,
        truncation="only_second",
        padding="max_length",
        return_offsets_mapping=True
    )
    offsets = encoding['offset_mapping']

    # Handle edge cases for token indices
    if start < len(offsets) and end < len(offsets):
        start_char = offsets[start][0]
        end_char = offsets[end][1]

        # Map back to original context
        prediction_text = context[start_char:end_char]
    else:
        print(f"Invalid indices for example {i}: start={start}, end={end}, len(offsets)={len(offsets)}")
        prediction_text = ""

    formatted_predictions.append({
        "id": f"qa_{i}",
        "prediction_text": prediction_text
    })

# Prepare references
references = [
    {
        "id": f"qa_{i}",
        "answers": [{"text": sample[2], "answer_start": sample[3]}]
    }
    for i, sample in enumerate(val_dataset.samples)
]

# Compute metrics
results = metric.compute(predictions=formatted_predictions, references=references)
print("Evaluation Results:", results)

# ==========================
# STEP 10: Save the Model
# ==========================
model.save_pretrained("./berturk_qa_finetuned")
tokenizer.save_pretrained("./berturk_qa_finetuned")
build_faiss_index(cleaned_data)
