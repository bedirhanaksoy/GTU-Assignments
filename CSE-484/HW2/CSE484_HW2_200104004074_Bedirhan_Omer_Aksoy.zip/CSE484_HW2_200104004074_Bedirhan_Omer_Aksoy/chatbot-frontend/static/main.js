/**
 * Returns the current datetime for the message creation.
 */
function getCurrentTimestamp() {
	return new Date();
}

/**
 * Renders a message on the chat screen based on the given arguments.
 * This is called from the `showUserMessage` and `showBotMessage`.
 */
function renderMessageToScreen(args) {
	// local variables
	let displayDate = (args.time || getCurrentTimestamp()).toLocaleString('en-IN', {
		month: 'short',
		day: 'numeric',
		hour: 'numeric',
		minute: 'numeric',
	});
	let messagesContainer = $('.messages');

	// init element
	let message = $(`
	<li class="message ${args.message_side}">
		<div class="avatar"></div>
		<div class="text_wrapper">
			<div class="text">${args.text}</div>
			<div class="timestamp">${displayDate}</div>
		</div>
	</li>
	`);

	// add to parent
	messagesContainer.append(message);

	// animations
	setTimeout(function () {
		message.addClass('appeared');
	}, 0);
	messagesContainer.animate({ scrollTop: messagesContainer.prop('scrollHeight') }, 300);
}

/* Sends a message when the 'Enter' key is pressed.
 */
$(document).ready(function() {
    $('#msg_input').keydown(function(e) {
        // Check for 'Enter' key
        if (e.key === 'Enter') {
            // Prevent default behaviour of enter key
            e.preventDefault();
			// Trigger send button click event
            $('#send_button').click();
        }
    });
});

/**
 * Displays the user message on the chat screen. This is the right side message.
 */
function showUserMessage(message, datetime) {
	renderMessageToScreen({
		text: message,
		time: datetime,
		message_side: 'right',
	});
}

/**
 * Displays the chatbot message on the chat screen. This is the left side message.
 */
function showBotMessage(message, datetime) {
	renderMessageToScreen({
		text: message,
		time: datetime,
		message_side: 'left',
	});
}

/**
 * Fetch an answer from the backend API.
 */
async function fetchAnswer(question) {
    try {
        let response = await fetch('http://127.0.0.1:5000/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question: question })
        });

        if (!response.ok) {
            throw new Error('Failed to fetch response from server');
        }

        let data = await response.json();
        return data.answer;
    } catch (error) {
        console.error('Error:', error);
        return 'Oops! Something went wrong. Please try again.';
    }
}

/**
 * Handles sending a user question and displaying the chatbot's response.
 */
$('#send_button').on('click', async function () {
    let userMessage = $('#msg_input').val().trim();

    if (userMessage === '') {
        return; // Ignore empty messages
    }

    // Display user's message
    showUserMessage(userMessage);
    $('#msg_input').val('');

    // Fetch chatbot's response from backend
    showBotMessage('Thinking...'); // Temporary message while waiting for response

    let botResponse = await fetchAnswer(userMessage);

    // Replace temporary message with actual bot response
    $('.messages').find('.message:last .text').text(botResponse);
});

/**
 * Handles 'Enter' key to send message.
 */
$(document).ready(function () {
    $('#msg_input').keydown(function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            $('#send_button').click();
        }
    });
});

/**
 * Set initial bot message to the screen for the user.
 */

message = "Selam! GTÜ Lisans Yönetmeliği ile ilgili sorularını cevaplamaya hazırım..."
$(window).on('load', function () {
	showBotMessage(message);
});