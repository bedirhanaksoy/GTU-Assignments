import os
import hashlib
import json
from romulus import romulus_encrypt, romulus_decrypt, pad_block, xor_blocks, BLOCK_SIZE, TAG_SIZE, NONCE_SIZE

# -------------------------
# 1. Encryption & Decryption Modes
# -------------------------

# CBC (Cipher Block Chaining) Mode
def cbc_encrypt(plaintext: str, key: bytes, iv: bytes, nonce: bytes) -> tuple:
    """
    Encrypt plaintext using CBC mode with Romulus as the underlying cipher.
    Returns:
        tuple: (ciphertext, tag)
    """
    plaintext_bytes = plaintext.encode()
    plaintext_bytes = pkcs7_pad(plaintext_bytes, BLOCK_SIZE)

    blocks = [plaintext_bytes[i:i + 16] for i in range(0, len(plaintext_bytes), 16)]
    previous_block = iv
    ciphertext = b''

    state = pad_block(nonce + b'\x00' * (BLOCK_SIZE - NONCE_SIZE))
    state = xor_blocks(state, key)

    for block in blocks:
        xored = xor_blocks(block, previous_block)
        state = romulus_encrypt(xored, key, nonce, b'')[0]
        previous_block = state
        ciphertext += state

    tag = state[:TAG_SIZE]
    return ciphertext, tag

def cbc_decrypt(ciphertext: bytes, key: bytes, iv: bytes, nonce: bytes, tag: bytes) -> str:
    """
    Decrypt ciphertext using CBC mode with Romulus as the underlying cipher.
    """
    blocks = [ciphertext[i:i + 16] for i in range(0, len(ciphertext), 16)]
    previous_block = iv
    plaintext = b''

    state = pad_block(nonce + b'\x00' * (BLOCK_SIZE - NONCE_SIZE))
    state = xor_blocks(state, key)

    for block in blocks:
        decrypted_block = romulus_decrypt(block, key, nonce, b'', b'')
        xored = xor_blocks(decrypted_block, previous_block)
        previous_block = block
        plaintext += xored

    calculated_tag = previous_block[:TAG_SIZE]

    if calculated_tag != tag:
        raise ValueError("Authentication failed: Invalid tag!")

    plaintext = pkcs7_unpad(plaintext)
    return plaintext.decode('utf-8')

# OFB (Output Feedback) Mode
def ofb_encrypt(plaintext: str, key: bytes, iv: bytes, nonce: bytes) -> tuple:
    """
    Encrypt plaintext using OFB mode with Romulus as the underlying cipher.
    Returns:
        tuple: (ciphertext, tag)
    """
    output = iv
    ciphertext = b''

    for byte in plaintext.encode():
        output, tag = romulus_encrypt(output, key, nonce, b'')
        ciphertext += bytes([byte ^ output[0]])

    return ciphertext, tag


def ofb_decrypt(ciphertext: bytes, key: bytes, iv: bytes, nonce: bytes, tag: bytes) -> str:
    output = iv
    plaintext = b''

    for byte in ciphertext:
        output, _ = romulus_encrypt(output, key, nonce, b'')
        plaintext += bytes([byte ^ output[0]])

    # Verify tag after all blocks are processed
    calculated_tag = output[:TAG_SIZE]
    if calculated_tag != tag:
        raise ValueError("Authentication failed: Invalid tag!")

    return plaintext.decode()


# -------------------------
# 2. File Metadata Extraction
# -------------------------

def extract_metadata(file_path: str, user_key: bytes):
    """
    Append encrypted metadata to the file.
    """
    metadata = {
        'author': 'User123',
        'created_at': '2024-06-10',
        'modified_at': '2024-06-12'
    }
    metadata_str = json.dumps(metadata)
    encrypted_metadata, tag = romulus_encrypt(
        metadata_str.encode(), user_key, os.urandom(12), b''
    )
    with open(file_path, 'ab') as file:
        file.write(b'--METADATA--' + encrypted_metadata)
    print('Metadata extracted and encrypted successfully.')


# -------------------------
# 3. File Integrity Check
# -------------------------

def calculate_file_hash(file_path: str) -> str:
    """
    Calculate the MD5 hash of a file, excluding metadata.
    """
    hash_md5 = hashlib.md5()
    with open(file_path, 'rb') as f:
        content = f.read()
        if b'--METADATA--' in content:
            content = content.split(b'--METADATA--')[0]  # Ignore metadata
        hash_md5.update(content)
    return hash_md5.hexdigest()


def verify_integrity(file_path: str, original_hash: str):
    """
    Verify the integrity of a file by comparing hashes.
    """
    current_hash = calculate_file_hash(file_path)
    if current_hash == original_hash:
        print("File Integrity: Intact")
    else:
        print("File Integrity: Compromised")

def pkcs7_pad(data: bytes, block_size: int) -> bytes:
    """
    Apply PKCS#7 padding to the given data.
    """
    padding_len = block_size - (len(data) % block_size)
    return data + bytes([padding_len] * padding_len)

def pkcs7_unpad(data: bytes) -> bytes:
    """
    Remove PKCS#7 padding from decrypted plaintext.
    """
    if not data:
        raise ValueError("Data to unpad cannot be empty")
    padding_len = data[-1]
    if padding_len > BLOCK_SIZE or padding_len == 0:
        raise ValueError("Invalid padding detected")
    if data[-padding_len:] != bytes([padding_len] * padding_len):
        raise ValueError("Invalid padding detected")
    return data[:-padding_len]

# -------------------------
# 4. Test Example
# -------------------------

if __name__ == '__main__':
    key = os.urandom(16)
    nonce = os.urandom(12)
    iv = os.urandom(16)

    plaintext = 'Hello, this is a test encryption.'
    print('Original Text:', plaintext)

    # ✅ CBC Mode
    encrypted_cbc, cbc_tag = cbc_encrypt(plaintext, key, iv, nonce)
    print('CBC Encrypted:', encrypted_cbc.hex())
    print('CBC Tag:', cbc_tag.hex())

    try:
        decrypted_cbc = cbc_decrypt(encrypted_cbc, key, iv, nonce, cbc_tag)
        print('CBC Decrypted:', decrypted_cbc)
    except ValueError as e:
        print('CBC Decryption Error:', e)

    # ✅ OFB Mode
    encrypted_ofb, ofb_tag = ofb_encrypt(plaintext, key, iv, nonce)
    print('OFB Encrypted:', encrypted_ofb.hex())
    print('OFB Tag:', ofb_tag.hex())

    try:
        decrypted_ofb = ofb_decrypt(encrypted_ofb, key, iv, nonce, ofb_tag)
        print('OFB Decrypted:', decrypted_ofb)
    except ValueError as e:
        print('OFB Decryption Error:', e)

    # ✅ File Operations
    file_path = 'test_file.txt'
    with open(file_path, 'w') as f:
        f.write(plaintext)

    original_hash = calculate_file_hash(file_path)
    extract_metadata(file_path, key)
    verify_integrity(file_path, original_hash)
