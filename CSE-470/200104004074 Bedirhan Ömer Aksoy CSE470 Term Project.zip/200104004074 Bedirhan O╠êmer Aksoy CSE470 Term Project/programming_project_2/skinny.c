#include <stdint.h>
#include <string.h>
#include <stdio.h>

#define NUM_ROUNDS 10
#define BLOCK_SIZE 16  // 128 bits
#define KEY_SIZE 16    // 128 bits

// Rotate a byte left
#define ROTL8(x, shift) ((uint8_t)((x) << (shift)) | ((x) >> (8 - (shift))))
// Rotate a byte right
#define ROTR8(x, shift) ((uint8_t)((x) >> (shift)) | ((x) << (8 - (shift))))

// Simple Substitution Box (S-Box)
static const uint8_t SBOX[16] = {
    0xC, 0x5, 0x6, 0xB, 0x9, 0x0, 0xA, 0xD,
    0x3, 0xE, 0xF, 0x8, 0x4, 0x7, 0x1, 0x2
};

// Inverse S-Box for decryption
static const uint8_t INV_SBOX[16] = {
    0x5, 0xE, 0xF, 0x8, 0xC, 0x1, 0x2, 0xD,
    0xB, 0x4, 0x6, 0x3, 0x0, 0x7, 0x9, 0xA
};

// Add Round Key
void add_round_key(uint8_t state[BLOCK_SIZE], uint8_t round_key[BLOCK_SIZE]) {
    for (int i = 0; i < BLOCK_SIZE; i++) {
        state[i] ^= round_key[i];
    }
}

// Substitution Step
void sub_cells(uint8_t state[BLOCK_SIZE]) {
    for (int i = 0; i < BLOCK_SIZE; i++) {
        state[i] = SBOX[state[i] & 0x0F];
    }
}

// Inverse Substitution Step
void inv_sub_cells(uint8_t state[BLOCK_SIZE]) {
    for (int i = 0; i < BLOCK_SIZE; i++) {
        state[i] = INV_SBOX[state[i] & 0x0F];
    }
}

// Shift Rows Step
void shift_rows(uint8_t state[BLOCK_SIZE]) {
    state[1] = ROTL8(state[1], 1);
    state[2] = ROTL8(state[2], 2);
    state[3] = ROTL8(state[3], 3);
}

// Inverse Shift Rows Step
void inv_shift_rows(uint8_t state[BLOCK_SIZE]) {
    state[1] = ROTR8(state[1], 1);
    state[2] = ROTR8(state[2], 2);
    state[3] = ROTR8(state[3], 3);
}

// Encryption Function
void skinny_encrypt(uint8_t plaintext[BLOCK_SIZE], uint8_t key[KEY_SIZE], uint8_t ciphertext[BLOCK_SIZE]) {
    uint8_t state[BLOCK_SIZE];
    uint8_t round_key[BLOCK_SIZE];
    memcpy(state, plaintext, BLOCK_SIZE);
    memcpy(round_key, key, BLOCK_SIZE);

    for (int round = 0; round < NUM_ROUNDS; round++) {
        add_round_key(state, round_key);
        sub_cells(state);
        shift_rows(state);

        // Rotate Key (Simplified key schedule)
        for (int i = 0; i < BLOCK_SIZE; i++) {
            round_key[i] = ROTL8(round_key[i], 1);
        }
    }

    memcpy(ciphertext, state, BLOCK_SIZE);
}

// Decryption Function
void skinny_decrypt(uint8_t ciphertext[BLOCK_SIZE], uint8_t key[KEY_SIZE], uint8_t plaintext[BLOCK_SIZE]) {
    uint8_t state[BLOCK_SIZE];
    uint8_t round_key[BLOCK_SIZE];
    memcpy(state, ciphertext, BLOCK_SIZE);
    memcpy(round_key, key, BLOCK_SIZE);

    // Reverse key schedule for decryption
    for (int round = 0; round < NUM_ROUNDS; round++) {
        for (int i = 0; i < BLOCK_SIZE; i++) {
            round_key[i] = ROTR8(round_key[i], 1);
        }
    }

    for (int round = 0; round < NUM_ROUNDS; round++) {
        inv_shift_rows(state);
        inv_sub_cells(state);
        add_round_key(state, round_key);

        // Rotate Key back
        for (int i = 0; i < BLOCK_SIZE; i++) {
            round_key[i] = ROTR8(round_key[i], 1);
        }
    }

    memcpy(plaintext, state, BLOCK_SIZE);
}

// Test Functions
void print_hex(uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        printf("%02X ", data[i]);
    }
    printf("\n");
}

// Entry Points for Python
void skinny_encrypt_wrapper(uint8_t *plaintext, uint8_t *key, uint8_t *ciphertext) {
    skinny_encrypt(plaintext, key, ciphertext);
}

void skinny_decrypt_wrapper(uint8_t *ciphertext, uint8_t *key, uint8_t *plaintext) {
    skinny_decrypt(ciphertext, key, plaintext);
}
