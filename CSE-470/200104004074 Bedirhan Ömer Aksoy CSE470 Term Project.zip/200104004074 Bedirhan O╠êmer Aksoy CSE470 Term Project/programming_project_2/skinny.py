import ctypes
import os

# Load the shared library
lib_path = os.path.join(os.path.dirname(__file__), 'libskinny.so')
skinny_lib = ctypes.CDLL(lib_path)

# Define function prototypes
skinny_lib.skinny_encrypt_wrapper.argtypes = [
    ctypes.POINTER(ctypes.c_ubyte), ctypes.POINTER(ctypes.c_ubyte), ctypes.POINTER(ctypes.c_ubyte)
]
skinny_lib.skinny_decrypt_wrapper.argtypes = [
    ctypes.POINTER(ctypes.c_ubyte), ctypes.POINTER(ctypes.c_ubyte), ctypes.POINTER(ctypes.c_ubyte)
]

def skinny_encrypt(plaintext: bytes, key: bytes) -> bytes:
    """
    Encrypt a 16-byte plaintext block using SKINNY.
    """
    if len(plaintext) != 16 or len(key) != 16:
        raise ValueError("Plaintext and key must both be 16 bytes.")

    ciphertext = (ctypes.c_ubyte * 16)()
    skinny_lib.skinny_encrypt_wrapper(
        (ctypes.c_ubyte * 16)(*plaintext),
        (ctypes.c_ubyte * 16)(*key),
        ciphertext
    )
    return bytes(ciphertext)

def skinny_decrypt(ciphertext: bytes, key: bytes) -> bytes:
    """
    Decrypt a 16-byte ciphertext block using SKINNY.
    """
    if len(ciphertext) != 16 or len(key) != 16:
        raise ValueError("Ciphertext and key must both be 16 bytes.")

    plaintext = (ctypes.c_ubyte * 16)()
    skinny_lib.skinny_decrypt_wrapper(
        (ctypes.c_ubyte * 16)(*ciphertext),
        (ctypes.c_ubyte * 16)(*key),
        plaintext
    )
    return bytes(plaintext)
