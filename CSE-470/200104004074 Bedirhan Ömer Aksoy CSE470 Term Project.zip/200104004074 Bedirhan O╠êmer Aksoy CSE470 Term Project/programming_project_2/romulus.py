import os
from skinny import skinny_encrypt, skinny_decrypt  # Import SKINNY functions from your implementation

BLOCK_SIZE = 16  # 128 bits
TAG_SIZE = 16    # 128 bits
NONCE_SIZE = 12  # 96 bits

# XOR utility
def xor_blocks(block1: bytes, block2: bytes) -> bytes:
    """XOR two byte blocks."""
    return bytes(a ^ b for a, b in zip(block1, block2))

# Padding function
def pad_block(block: bytes) -> bytes:
    """Pad a block to BLOCK_SIZE."""
    return block.ljust(BLOCK_SIZE, b'\x00')

# Romulus Encryption
def romulus_encrypt(plaintext: bytes, key: bytes, nonce: bytes, associated_data: bytes) -> tuple:
    """
    Encrypt plaintext using Romulus-N1 AEAD.
    
    Args:
        plaintext (bytes): The plaintext to encrypt.
        key (bytes): 128-bit encryption key.
        nonce (bytes): 96-bit nonce.
        associated_data (bytes): Associated data for authentication.

    Returns:
        tuple: (ciphertext, tag)
    """
    state = pad_block(nonce + b'\x00' * (BLOCK_SIZE - NONCE_SIZE))
    state = xor_blocks(state, key)

    for i in range(0, len(associated_data), BLOCK_SIZE):
        ad_block = pad_block(associated_data[i:i + BLOCK_SIZE])
        state = xor_blocks(state, ad_block)
        state = skinny_encrypt(state, key)

    ciphertext = b''
    for i in range(0, len(plaintext), BLOCK_SIZE):
        plaintext_block = pad_block(plaintext[i:i + BLOCK_SIZE])
        state = xor_blocks(state, plaintext_block)
        state = skinny_encrypt(state, key)
        ciphertext += state[:len(plaintext_block)]

    tag = state[:TAG_SIZE]
    return ciphertext, tag

# Romulus Decryption
def romulus_decrypt(ciphertext: bytes, key: bytes, nonce: bytes, associated_data: bytes, expected_tag: bytes) -> bytes:
    """
    Decrypt ciphertext using Romulus-N1 AEAD.
    
    Args:
        ciphertext (bytes): The ciphertext to decrypt.
        key (bytes): 128-bit encryption key.
        nonce (bytes): 96-bit nonce.
        associated_data (bytes): Associated data for authentication.
        expected_tag (bytes): Expected authentication tag.

    Returns:
        bytes: The decrypted plaintext.
    """

    state = pad_block(nonce + b'\x00' * (BLOCK_SIZE - NONCE_SIZE))
    state = xor_blocks(state, key)

    plaintext = b''
    for i in range(0, len(ciphertext), BLOCK_SIZE):
        ciphertext_block = pad_block(ciphertext[i:i + BLOCK_SIZE])
        state = skinny_encrypt(state, key)
        plaintext_block = xor_blocks(state, ciphertext_block)
        plaintext += plaintext_block[:len(ciphertext_block)]

    calculated_tag = state[:TAG_SIZE]

    if expected_tag and calculated_tag != expected_tag:
        raise ValueError("Authentication failed: Invalid tag!")

    return plaintext.rstrip(b'\x00')
