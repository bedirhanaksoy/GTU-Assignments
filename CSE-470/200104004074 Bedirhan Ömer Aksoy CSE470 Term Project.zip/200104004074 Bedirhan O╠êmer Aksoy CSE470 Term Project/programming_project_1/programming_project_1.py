import random
import time
from math import gcd, sqrt, log2

# -------------------------
# Miller-Rabin Primality Test (Probabilistic)
# -------------------------

def miller_rabin(n, k=5):
    """
    Miller-Rabin Primality Test
    Args:
        n (int): Number to test for primality.
        k (int): Number of iterations for accuracy.
    Returns:
        bool: True if probably prime, False if composite.
    """
    # Step 1: Handle edge cases
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False
    
    # Step 2: Write n - 1 as 2^s * d
    s = 0
    d = n - 1
    while d % 2 == 0:
        d //= 2
        s += 1
    
    # Step 3: Perform the test k times
    for _ in range(k):
        a = random.randint(2, n - 2)
        x = pow(a, d, n)
        
        if x == 1 or x == n - 1:
            continue
        
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    
    return True


# -------------------------
# Sieve of Eratosthenes (Deterministic)
# -------------------------

def sieve_of_eratosthenes(limit):
    """
    Sieve of Eratosthenes
    Args:
        limit (int): Upper limit for generating primes.
    Returns:
        list: List of prime numbers up to 'limit'.
    """
    if limit < 2:
        return []
    
    # Step 1: Create a list of boolean values
    primes = [True] * (limit + 1)
    primes[0], primes[1] = False, False  # 0 and 1 are not prime
    
    # Step 2: Start marking multiples
    for i in range(2, int(sqrt(limit)) + 1):
        if primes[i]:
            for j in range(i * i, limit + 1, i):
                primes[j] = False
    
    # Step 3: Collect all prime numbers
    return [x for x in range(limit + 1) if primes[x]]


# -------------------------
# Sieve of Atkin (Deterministic)
# -------------------------

def atkin_sieve(limit):
    """
    Sieve of Atkin
    Args:
        limit (int): Upper limit for generating primes.
    Returns:
        list: List of prime numbers up to 'limit'.
    """
    if limit < 2:
        return []
    
    primes = [False] * (limit + 1)
    primes[2], primes[3] = True, True
    
    # Step 1: Apply modular rules
    for x in range(1, int(sqrt(limit)) + 1):
        for y in range(1, int(sqrt(limit)) + 1):
            n = (4 * x ** 2) + (y ** 2)
            if n <= limit and (n % 12 == 1 or n % 12 == 5):
                primes[n] = not primes[n]
            
            n = (3 * x ** 2) + (y ** 2)
            if n <= limit and n % 12 == 7:
                primes[n] = not primes[n]
            
            n = (3 * x ** 2) - (y ** 2)
            if x > y and n <= limit and n % 12 == 11:
                primes[n] = not primes[n]
    
    # Step 2: Eliminate squares of primes
    for n in range(5, int(sqrt(limit)) + 1):
        if primes[n]:
            for k in range(n ** 2, limit + 1, n ** 2):
                primes[k] = False
    
    # Step 3: Collect all prime numbers
    return [x for x in range(limit + 1) if primes[x]]


# -------------------------
# Comparative Testing Function
# -------------------------

def compare_algorithms(limit, test_number):
    print(f"Comparing algorithms for range: 0-{limit}")
    print(f"Testing Miller-Rabin on single number: {test_number}\n")
    
    # Miller-Rabin Single Number Test
    start_time = time.time()
    is_prime = miller_rabin(test_number)
    miller_rabin_time = time.time() - start_time
    print(f"Miller-Rabin: {test_number} is {'Prime' if is_prime else 'Composite'} | Time: {miller_rabin_time:.6f} seconds")
    
    # Sieve of Eratosthenes
    start_time = time.time()
    eratosthenes_primes = sieve_of_eratosthenes(limit)
    eratosthenes_time = time.time() - start_time
    print(f"Sieve of Eratosthenes: Found {len(eratosthenes_primes)} primes | Time: {eratosthenes_time:.6f} seconds")
    
    # Sieve of Atkin
    start_time = time.time()
    atkin_primes = atkin_sieve(limit)
    atkin_time = time.time() - start_time
    print(f"Sieve of Atkin: Found {len(atkin_primes)} primes | Time: {atkin_time:.6f} seconds")
    
    # Validate Results
    if eratosthenes_primes == atkin_primes:
        print("\n Eratosthenes and Atkin produced identical prime lists!")
    else:
        print("\n Eratosthenes and Atkin produced different results!")
    
    print("\n--- Performance Summary ---")
    print(f"Miller-Rabin (Single Number): {miller_rabin_time:.6f} sec")
    print(f"Sieve of Eratosthenes: {eratosthenes_time:.6f} sec")
    print(f"Sieve of Atkin: {atkin_time:.6f} sec")


if __name__ == "__main__":
    compare_algorithms(100000, 99991)
